# mfk5_eic_dataanalytics

## Description
This repository contains notebooks, dashboards, and other scripts for data analysis in databricks

## Author
volker.kippelt@cariad.technology

## Usage
Check out the respective subfolders for more information



