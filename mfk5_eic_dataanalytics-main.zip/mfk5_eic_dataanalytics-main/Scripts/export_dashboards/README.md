# Export notebook dashboards
## Description
The script export_dashboards.py exports notebook dashboards from a databricks notebook to the local machine. 

## Author
volker.kippelt@cariad.technology

## Setup:
- Generate databricks access token and store it as environment variable
- Create databricks job that can run the notebook and note the job_id
- Set databricks instance url, name of the enviroment variable of the token and the job_id in the config.ini

## Usage:
- Create a file that contains all containerIds of the events, that should be exported. One line for each containerId.
- Execute the script (or use the provided batch file): 
    python export_dashboards.py  --container_id_file PARAM_CONTAINER_ID_FILE --output_path PARAM_OUTPUT_PATH




