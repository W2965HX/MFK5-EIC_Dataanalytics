import requests
import time
import os
import argparse
from pathlib import Path
import configparser

config = configparser.ConfigParser()
config_file = os.path.join(Path(__file__).resolve().parent, "config.ini")
config.read(config_file)

DATABRICKS_INSTANCE = config["databricks"]["instance"]
TOKEN = os.getenv(config["databricks"]["environment_token"])
JOB_ID = config["databricks"]["job_id"]

HEADERS = {"Authorization": f"Bearer {TOKEN}",
           "Content-Type": "application/json"}


def start_job(param: str) -> int:
    run_payload = {"job_id": JOB_ID, "notebook_params": param}
    response = requests.post(
        f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now",
        headers=HEADERS,
        json=run_payload
    )
    response.raise_for_status()
    run_id = response.json().get("run_id")
    print(f"Job started with run_id: {run_id}")
    return run_id


def wait_for_done(run_id: int) -> str:
    state = "INIT"
    while True:
        status_response = requests.get(
            f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get",
            headers=HEADERS,
            params={"run_id": run_id},
        )
        status_response.raise_for_status()
        state = status_response.json().get("state", {}).get("life_cycle_state")
        print(f"Status: {state}")
        if state in ["TERMINATED", "SKIPPED", "INTERNAL_ERROR"]:
            break
        time.sleep(10)
    return state


def get_export_data(run_id: int) -> str:
    export_response = requests.get(
        f"{DATABRICKS_INSTANCE}/api/2.2/jobs/runs/export",
        headers=HEADERS,
        params={"run_id": run_id, "views_to_export": "DASHBOARDS"},
    )
    export_response.raise_for_status()
    export_data = export_response.json()
    return export_data


def extract_html_data(export_data: str) -> str:
    if "views" in export_data and len(export_data["views"]) > 0:
        html_content = export_data["views"][0].get("content", "")
        return html_content
    return ""


def store_html_data(html_data: str, filename: str) -> None:
    filepath = Path(filename)
    folder = filepath.parent

    if not folder.exists():
        folder.mkdir(parents=True, exist_ok=True)

    if len(html_data) > 0:
        with open(filename, "w", encoding="utf-8") as f:
            f.write(html_data)
        print("Notebook dashboard stored als HTML: " + filename)
    else:
        print("No export content found.")


def execute_notebook(param: str) -> int:
    run_id = start_job(param)
    state = wait_for_done(run_id)
    if state != "TERMINATED":
        raise RuntimeError(f"Notebook could not be executed with parameter: {param}")
    return run_id


def extract_and_store_html_dashboard(run_id: int, filename: str) -> None:
    data = get_export_data(run_id)
    html_data = extract_html_data(data)
    store_html_data(html_data, filename)


def run_jobs_and_export_from_containerId_list(container_id_list: list, output_path: str) -> None:
    for container_id in container_id_list:
        params = {"param_containerId": container_id}
        try:
            run_id = execute_notebook(params)
            extract_and_store_html_dashboard(run_id, os.path.join(output_path, f"Analyse_event_cont_id_{container_id}.html"))
        except RuntimeError as err:
            print(err)


def run_jobs_and_export_from_containerId_file(container_id_file: str, output_path: str) -> None:
    with open(container_id_file, 'r', encoding='utf-8') as f:
        for row_number, container_id in enumerate(f):
            container_id = container_id.strip()
            print(f"Row number {row_number}: {container_id}")
            params = {"param_containerId": container_id}
            try:
                run_id = execute_notebook(params)
                extract_and_store_html_dashboard(run_id, os.path.join(output_path, f"Analyse_Event_cont_id_{container_id}.html"))
            except RuntimeError as err:
                print(err)


def main(args):
    run_jobs_and_export_from_containerId_file(args.container_id_file, args.output_path)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Export dashboards for a given list of containerIds")
    parser.add_argument('--container_id_file', type=str, required=True, help='File that contains containerIds that should be exportet')
    parser.add_argument('--output_path', type=str,  default='./', help='Output path where exported files should be stored')

    args = parser.parse_args()
    main(args)
