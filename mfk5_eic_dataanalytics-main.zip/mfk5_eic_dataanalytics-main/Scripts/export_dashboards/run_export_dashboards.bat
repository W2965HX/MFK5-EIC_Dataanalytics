@echo off
REM Batch skript to execute dashboard export with predefined parameter
REM General connection parameter need to be set in the config.ini
REM databricks token needs to be set as environment variabel: e.g. DATABRICKS_UDE_APPR

REM Set parameter
set PARAM_CONTAINER_ID_FILE="./containerIds_OD_UDE_Appr.txt"
set PARAM_OUTPUT_PATH="./"

python export_dashboards.py  --container_id_file %PARAM_CONTAINER_ID_FILE% --output_path %PARAM_OUTPUT_PATH%