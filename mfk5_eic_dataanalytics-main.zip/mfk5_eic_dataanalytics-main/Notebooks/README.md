# Notebooks
## Description
This folder contains different notebooks used for data analytics on databricks



## Author
volker.kippelt@cariad.technology





