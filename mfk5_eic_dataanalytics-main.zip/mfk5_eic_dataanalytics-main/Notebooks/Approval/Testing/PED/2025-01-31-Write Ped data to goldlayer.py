# Databricks notebook source
# MAGIC %md
# MAGIC ## Install Protobuf (needed for decoding Highlevel signals)

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType

import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------
import sys

# Set repo root path
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
from EICModules.decodeSomeIP.linux import someIPpythonlib
from EICModules.EICPED import EIC_PED_module
from EICModules.plots import EIC_PED_Plots
from EICModules.decodeHighlevelData import decodeBHE
importlib.reload(decodeBHE)
importlib.reload(someIPpythonlib)
importlib.reload(EIC_PED_module)
importlib.reload(EIC_PED_Plots)

#from extractBHEData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)
# ---------- end ----------


# COMMAND ----------

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`usecase-75c7e965-b657-4d94-92a4-e026e9119cd6`")

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

# Filter for last X days
lastDays = 160

df = (df_read        
        .filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        #.filter(col("name")!= "PedestrianDetection pedestrians Event")
        #.filter(col("name")!= "Event Image Collector - Response")
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        #.select("userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", timestamp_unix", "name", "value")     
        .cache()
)

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pivot and decode data

# COMMAND ----------

df_data = EIC_PED_module.pivot_eic_ped_data(df, spark).cache()
display(df_data)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Get data overview

# COMMAND ----------

df_data_summary = EIC_PED_module.eic_ped_event_summary(df_data)

display(df_data_summary)


# COMMAND ----------

# MAGIC %md
# MAGIC # todo: delete

# COMMAND ----------

df_data_summary_with_timefromTimestamp = df_data_summary.withColumn("timefromTimestamp", F.from_unixtime(col("unix_time_at_activation")/1000))

display(df_data_summary_with_timefromTimestamp)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store event summary

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "PedEventSummary"

df_data_summary.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store pivoted and decoded data

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"  
my_project_name = "eicmfk"                        
my_gold_layer_table_name = "PedEventsDecoded"

df_data.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete Tables

# COMMAND ----------

'''
my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "PedEventSummary"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)

my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "PedEventsDecoded"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''