# Databricks notebook source
# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

from pyspark.sql.functions import col, radians, year, when, lit
from pyspark.sql import functions as F
import plotly.graph_objects as go
from pyspark.sql.window import Window

import numpy as np
import pandas as pd

import base64

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter use case data

# COMMAND ----------

df = spark.read.format("delta").table("default.deltalakesilver")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df = (df
        .filter(F.array_contains(df.useCaseIds,"UseCase-75c7e965-b657-4d94-92a4-e026e9119cd6"))  # PED
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .orderBy("timestamp", ascending=False)
        .cache()
)

display(df)
df.count()


# COMMAND ----------

# MAGIC %md
# MAGIC ## Store PED Data in gold layer

# COMMAND ----------

gold_layer_location = "dbfs:/mnt/deltalakegold" # THIS IS IMPORTANT! The table has to be stored in this exact location, otherwise it will not be stored in the correct storage account and might be lost when we have to make changes to Databricks.
table_name = "eic_mfk5_perception_ped_confbit"
df.write.mode("overwrite").format("delta").saveAsTable(table_name, path=f"{gold_layer_location}/{table_name}") # The path becomes "dbfs:/mnt/deltalakegold/eic_mfk5_perception_bhe_on_Startup"