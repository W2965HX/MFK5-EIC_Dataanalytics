# Databricks notebook source
# MAGIC %md
# MAGIC ## Install Protobuf (needed for decoding Highlevel signals)

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType

import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------
import sys

# Set repo root path
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/EICModules"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
from decodeSomeIP.linux import someIPpythonlib
from EICPED import EIC_PED_module
from plots import EIC_PED_Plots
from decodeCSOData import cso_vehicle_pb2, decodeCSOData
importlib.reload(cso_vehicle_pb2)
importlib.reload(decodeCSOData)
importlib.reload(someIPpythonlib)
importlib.reload(EIC_PED_module)
importlib.reload(EIC_PED_Plots)

#from extractBHEData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)
# ---------- end ----------


# COMMAND ----------

# MAGIC %md
# MAGIC ## Read data + Filter for last X days

# COMMAND ----------

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`usecase-75c7e965-b657-4d94-92a4-e026e9119cd6`")

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

# Filter for last X days
lastDays = 10

df = (df_read        
        .filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        #.select("userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", timestamp_unix", "name", "value")     
        .cache()
)

display(df)
df.count()


# COMMAND ----------

# Eindeutige Werte und ihre Anzahl anzeigen
unique_values_count = df.groupBy("name").count()

display(unique_values_count)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pivot and decode data

# COMMAND ----------

df_data = EIC_PED_module.pivot_eic_ped_data(df, spark).cache()
display(df_data)



# COMMAND ----------

# MAGIC %md
# MAGIC ## Get data overview

# COMMAND ----------

df_data_summary = EIC_PED_module.eic_ped_event_summary(df_data)

display(df_data_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract image data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option1: Select images by usermessageIds

# COMMAND ----------

dbutils.widgets.text("parameter_name", "default_value", "Parameter Label")

# COMMAND ----------

# userMessageIds of Images
#userMessageIds = ["fc4828a6-2a25-4470-bea8-3724d9aa1a2a","4a94a60b-44da-4541-ae11-cc6c7d689250","f4e82b7a-49cc-4802-a314-2e438e09b8bd"]
#userMessageIds = ["fbf2f29c-8ad8-4fc8-9dd6-fbf81fce5439","36006c51-5c42-4721-9893-6c09f58d92b6","2ff2f9b6-c9a2-4839-9803-236306eb9342"] # crossing bikes
userMessageIds = ["1c7e4778-34a3-4c92-a05e-4a20ad38019c",
"6800ec52-0aee-429a-8b9c-47646dd5e05f",
"fe153878-f677-46e7-abd7-56dd177fc2ee"]


EIC_Images = (df_data
            .filter(col("EIC_Response").isNotNull())
            .filter(col("userMessageId").isin(userMessageIds))
            .select("containerId", "userMessageId", "timestamp_unix", "EIC_Response")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("EIC_Response", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("Event Image Collector - Response").isNotNull())

display(EIC_Images)

eic_images_pd = EIC_Images.toPandas()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 2: Select images by timestamp 

# COMMAND ----------

eventTime = 1733567095638
start = eventTime - 30000
end = eventTime + 30000

timefiltered_images = (df_data
                    .filter(col("EIC_Response").isNotNull())
                    .filter((col("timestamp_unix") >= start) & (col("timestamp_unix") <= end))
                    # get image string right of "image:"
                    .withColumn("image_string", F.substring_index(col("EIC_Response"), "image\":", -1))
                    # get image string left of "," --> only base64 image string remains
                    .withColumn("image_string", F.substring_index("image_string", ",\"", 1))           
)
display(timefiltered_images)

eic_images_pd = timefiltered_images.toPandas()



# COMMAND ----------

# MAGIC %md
# MAGIC ## Display filtered images

# COMMAND ----------

# Iterate over each row in the DataFrame
for row in range(0, len(eic_images_pd)):
    # Extract the base64 image string
    single_image = eic_images_pd['image_string'].iloc[row]

    try:
        # Decode the base64 image string
        decoded_value = base64.b64decode(single_image)
        # Convert the decoded bytes to a numpy array
        image = np.frombuffer(decoded_value, np.uint8)
        # Re-encode the image to base64
        encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
        # Define the image prefix
        prefix = "data:image/jpg;base64,"
        # Create a Plotly figure with the image
        fig = go.Figure(go.Image(source=prefix+encoded_image))
        # Update the layout of the figure
        fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
        fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
        # Convert the figure to JSON
        plotly_obj = fig.to_json()
        # Create a DataFrame with the JSON object
        result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
        # Display the figure
        fig.show()
    except Exception as e:
        print(f"Error decoding in containerId: {eic_images_pd.iloc[row]["containerId"]} Error: {e}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter meta data of one event 

# COMMAND ----------

#userMessageId = "cbb60645-9f2d-441f-a594-f630ac6b594d"
#userMessageId = "e4b62900-5366-4383-b69a-4b4fbfc724ff"
#userMessageId = "9c803f4e-1938-4ccb-8d3d-754a1a78b092"
#userMessageId = "01951abe-4638-421a-af86-b117dd2f3fae"
#userMessageId = "cfe1031d-e8be-4d77-a023-63a4bf296b8a"
#userMessageId = "3fbdc22b-c9b9-4935-9a3f-71bcf949b2e2"
#userMessageId = "383dbd7e-c194-43cc-89b5-bb540fad3e8f"
#userMessageId = "a7e797b8-516d-451f-8b91-83f2666c6404" # crossing bikes
userMessageId = "2d06a4be-e314-428d-9b88-0b8be7ad5c6f"

# Filter the dataframe for the specific userMessageId
plot_data = (df_data
            .filter(col("userMessageId")==userMessageId)
)
display(plot_data)

# Convert the filtered Spark DataFrame to a Pandas DataFrame
plot_data_pd = plot_data.toPandas()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Plot Metadata

# COMMAND ----------

timebase = "timestamp"

display(plot_data.select(timebase, "DW_Kilometerstand").dropna().tail(2))
EIC_PED_Plots.map_plot(plot_data_pd, timebase)

EIC_PED_Plots.velocity_plot(plot_data_pd, timebase)
EIC_PED_Plots.confbit_plot(plot_data_pd, timebase, 'ConfBitL1')
EIC_PED_Plots.confbit_plot(plot_data_pd, timebase, 'ConfBitL2')
EIC_PED_Plots.confbit_plot(plot_data_pd, timebase, 'ConfBitL3')

EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "WBA_Warnung", "markers")

#EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "Wischer1_Wischgeschwindigkeit", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "LWI_AgStgWhl", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "DPM_StTarDrvPosn")
#EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_FlgWhlMoveDet_XIX_VDSO_03_XIX_HCP5_CANFD05", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_Vx3dGNSS", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_AgvYawRateOfsCmp", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_AgReWhlStgAxl", "markers")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "API_PrctDrvPed", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VMM_BrkPed_ItDmdNorm", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_ALgtOfsCmp", "lines")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "VDSO_ALatOfsCmp", "lines")

EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "high_beam_state", "markers")
EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "low_beam_state", "markers")
#EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "Outdoor_temp_C", "lines")
#EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "weather_cond_status", "lines")
#EIC_PED_Plots.generic_time_plot(plot_data_pd, timebase, "weather_cond_clearWeather", "markers")

# Weather
display(plot_data.select(timebase, "outside_temp", "outside_hum", "outside_hum_temp_status" ).dropna())
display(plot_data.select(timebase, "Outdoor_temp_C").dropna().tail(2))
display(plot_data.select(timebase, "weather_cond_status", "weather_cond_clearWeather", "weather_cond_fog", "weather_cond_fogHeavy", "weather_cond_rain", "weather_cond_rainHeavy", "weather_cond_snow", "weather_cond_snowHeavy").dropna().tail(2))



#display(plot_data.select(timebase, "outside_hum_temp_status", "outside_temp", "outside_hum").dropna().tail(2))
