# Databricks notebook source
# MAGIC %md
# MAGIC #Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType

import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------

# Importieren der Funktion aus der Datei
import sys

# Fügen Sie den Pfad zum Repository-Root hinzu, falls noch nicht geschehen
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
import EIC_PED_module
from decodeSomeIP.linux import someIPpythonlib
#import cso_vehicle_pb2
#import extractBHEData
#importlib.reload(cso_vehicle_pb2)
#importlib.reload(extractBHEData)
importlib.reload(EIC_PED_module)
importlib.reload(someIPpythonlib)

#from extractBHEData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)
# ---------- end ----------

# COMMAND ----------

# MAGIC %md
# MAGIC ## UDF für SomeIP Decoding

# COMMAND ----------

def decodePedValue(ped_b64_string):
    byte_array      = base64.b64decode(ped_b64_string)
    ped = someIPpythonlib.pedestrians()
    dec = someIPpythonlib.decoder.decoderCreate(byte_array) 

    ped.parse_from(dec)
    return ped.value

def getConfBitL1(ped_b64_string):
    ped_value = decodePedValue(ped_b64_string)
    return str(ped_value.confirmationBits.confBitL1)

def getConfBitL2(ped_b64_string):
    ped_value = decodePedValue(ped_b64_string)
    return str(ped_value.confirmationBits.confBitL2)

def getConfBitL3(ped_b64_string):
    ped_value = decodePedValue(ped_b64_string)
    return str(ped_value.confirmationBits.confBitL3)

def mapConfBitStringToNumber(confbitString):
    mapping = {
        "ConfirmationBit.notSet" : 0,
        "ConfirmationBit.set" : 1,
        "ConfirmationBit.init" : 2,
        "ConfirmationBit.error" : 3                        
    }
    return mapping.get(confbitString, -1)

getConfBitL1_udf = udf(getConfBitL1, StringType())
mapConfBitStringToNumber_udf = udf(mapConfBitStringToNumber, IntegerType())

#todo: serialize ped object
#def pedestrianObject_serialized(value):
#    return json.dumps(decodePedValue(value))
#pedSerialize_udf = udf(pedestrianObject_serialized, StringType())


# COMMAND ----------

# MAGIC %md
# MAGIC # Read data + Filter for last X days

# COMMAND ----------

df_read = spark.read.table("default.eic_mfk5_perception_ped_confbit")

df = (df_read
        # .filter(array_contains(df.useCaseIds,"UseCase-665e11af-e77a-4535-b1fa-43663c56622c"))        
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        #.select("userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", timestamp_unix", "name", "value")     
        .cache()
)

df = df.filter(col("timestamp") > F.date_sub(F.current_date(), 7))  # filter for data of last X days


display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Pivot and decode data

# COMMAND ----------

df_data = EIC_PED_module.pivot_eic_ped_data(df, spark).cache()

#df_data = df_data.filter(col("userMessageId") == "0067643d-7a3f-47da-bafb-be4a952f14a8")
display(df_data)



# COMMAND ----------

# MAGIC %md
# MAGIC ## Get data overview

# COMMAND ----------

df_data_summary = EIC_PED_module.eic_ped_event_summary(df_data)

display(df_data_summary)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract EIC Images

# COMMAND ----------

df_images = df.filter(col("name") == "Event Image Collector - Response")
display(df_images)
df_images.count()

#df_images_small = df_images.filter(F.length(col("value")) < 500)
#display(df_images_small)
#df_images_small.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter Pedestrian data

# COMMAND ----------


# einzelnes Event (Fahrzeug und Zeitraum filtern)
eventTime = 1732618255824
start = eventTime - 30000
end = eventTime + 30000

filteredPedEvent = (df.filter(
                    (col("timestamp_unix") >= start) 
                    & (col("timestamp_unix") <= end)      
                    & (col("name") == "PedestrianDetection pedestrians Event"))   
                    .withColumn("ConfBitL1", getConfBitL1_udf(df["value"]))
)
filteredPedEvent = filteredPedEvent.withColumn("ConfBitL1_Int", mapConfBitStringToNumber_udf(filteredPedEvent["ConfBitL1"]))

#filteredPedEvent =  df.filter(col("name") == "PedestrianDetection pedestrians Event")
display(filteredPedEvent)#filteredPedEvent.select("timestamp", "timestamp_unix", "name", "value", "ConfBitL1", "userMessageId"))
filteredPedEvent.count()

# Konvertiere zu Pandas DataFrame
pdf = filteredPedEvent.toPandas()

# Plotten
plt.figure(figsize=(10, 6))
plt.plot(pd.to_datetime(pdf["timestamp"]), pdf["ConfBitL1"], marker='o')
plt.xlabel("Timestamp")
plt.ylabel("ConfBitL1")
plt.title("ConfBitL1 over Time")
plt.grid(True)
plt.show()

# COMMAND ----------

df_images_reduced = df_images.withColumn("size", F.length(col("value")))

display(df_images_reduced.select("timestamp", "timestamp_unix", "name", "userMessageId", "size"))

# COMMAND ----------

pivot_df_images = (df_images
            .groupBy("timestamp_unix", "name", "value","userMessageId")
            .pivot("name")
            .agg(F.first("value"))
            .drop(col("name"), col("value"))            
        )
display(pivot_df_images)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Extract image data

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option1: Select images by usermessageIds

# COMMAND ----------

# userMessageIds of Images
#userMessageIds = ['29660695-620e-4930-a822-e9f8a1b4f8f4', '90fae251-244f-46bb-8791-7e606d259df3', '7f336b0a-cd14-48ab-846b-5909ce684f50', 'd66a9db0-35e9-4760-b361-dfaa5ec52b91', '28ec9ea0-c0b9-43dd-9687-36f8e0b86584', 'a6b4c9e9-8274-4e62-ac6b-b3f32bd5286c']

#userMessageIds = ['78632f34-4231-4406-b821-9f0135b1f980',
#'e0a99d84-323b-4293-a9fd-b8ab7ccc7e6c',
#'ce97edc9-169b-4cbf-becd-b996d3ab04f1',
#'484385df-edcc-4e53-9ad4-de963e8d2bf3',
#'e71413f0-7827-41ab-a9dd-5ad9e5a6362b']

#userMessageIds = ['d4e96180-1695-4406-9b8c-7a5ea9b64f54',
#'9f9da13b-93d1-4f1d-91f9-3e6eebb5cc58',
#'2cac2b47-1c40-47a4-a2de-e402e12249b7',
#'7165ed76-e0a3-48bf-9f04-f4721a3df6fd',
#'9add3940-b1d6-437b-8775-c92cdc520fe6']

userMessageIds = ["c844ac66-f197-4bdf-88c8-cb824add7215",
"5446a98c-70e6-461f-beff-04133acaebe4",
"3daf9961-f3c4-44eb-b86d-f5bda064a548",
"f9397f72-078f-4394-b867-8904e4a65cb9",
"893570c8-fa17-4e51-a161-6bde521a2a0d",
"309b67fb-80dc-4bf9-90d4-72fb5aaced09"]

EIC_Images = (pivot_df_images
            .filter(col("userMessageId").isin(userMessageIds))
            .select("userMessageId", "timestamp_unix", "Event Image Collector - Response")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("Event Image Collector - Response", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("Event Image Collector - Response").isNotNull())

display(EIC_Images)

eic_images_pd = EIC_Images.toPandas()


# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 2: Select images by timestamp range

# COMMAND ----------

eventTime = 1732601967829
start = eventTime - 30000
end = eventTime + 30000

timefiltered_images = (pivot_df_images.filter(
                    (col("timestamp_unix") >= start) 
                    & (col("timestamp_unix") <= end))
                    # get image string right of "image:"
                    .withColumn("image_string", F.substring_index("Event Image Collector - Response", "image\":", -1))
                    # get image string left of "," --> only base64 image string remains
                    .withColumn("image_string", F.substring_index("image_string", ",\"", 1))           
                    #.collect()[0][0]
)
display(timefiltered_images)

eic_images_pd = timefiltered_images.toPandas()



# COMMAND ----------



for row in range(0, len(eic_images_pd)):
    single_image = eic_images_pd['image_string'].iloc[row]

    decoded_value = base64.b64decode(single_image)
    image = np.frombuffer(decoded_value, np.uint8)#[9:]
    encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
    prefix = "data:image/jpg;base64,"
    fig = go.Figure(go.Image(source=prefix+encoded_image))
    fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
    fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
    plotly_obj = fig.to_json()
    result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
    fig.show()