# Databricks notebook source
from pyspark.sql.functions import col, radians, year, when, lit
from pyspark.sql import functions as F
import plotly.graph_objects as go
from pyspark.sql.window import Window

import numpy as np
import pandas as pd

import base64

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter all useCase data

# COMMAND ----------

df = spark.read.format("delta").table("default.deltalakesilver")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df = (df
         .filter(F.array_contains(df.useCaseIds,"UseCase-e1cf8455-c41d-47e4-9df1-4a76f02c4177") | F.array_contains(df.useCaseIds,"UseCase-ff712c38-8b44-4012-8a8c-83305696389e"))  # Locktrigger
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .orderBy("timestamp", ascending=False)
        .cache()
)

display(df)
df.count()


# COMMAND ----------

# MAGIC %md
# MAGIC # Extract image data

# COMMAND ----------


EIC_Images = (df
            .filter(col("name") == "Event Image Collector - Response")
            #.filter(col("userMessageId").isin(userMessageIds))
            .select("userMessageId", "vehicleId","timestamp", "name", "value")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("value", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("Event Image Collector - Response").isNotNull())

display(EIC_Images.select("userMessageId", "vehicleId","timestamp", "name"))
display("Number of Images: ", EIC_Images.count())



# COMMAND ----------

# MAGIC %md
# MAGIC # Optional: Filter for specific vehicle

# COMMAND ----------

vehicleID = "6d427826702749f1b2dbd29bca2d6d33"

EIC_Images = (EIC_Images
            .filter(col("vehicleId") == vehicleID)
            )
display("Number of Images: ", EIC_Images.count())

# COMMAND ----------

# MAGIC %md
# MAGIC # Choose one of the following Options

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 1: Filter for last X images
# MAGIC

# COMMAND ----------

numImages = 3
EIC_Images_filtered = (EIC_Images
                       .orderBy("timestamp", ascending=False)
                       .limit(numImages)
                       )

display(EIC_Images_filtered)

# COMMAND ----------

# MAGIC %md
# MAGIC ### Option 2: Select images from time frame

# COMMAND ----------

start_time = "2024-12-12 16:35:00"
end_time = "2024-12-12 16:38:00"

EIC_Images_filtered = EIC_Images.filter((col("timestamp") >= start_time) & (col("timestamp") <= end_time))
display(EIC_Images_filtered.select("userMessageId", "vehicleId", "timestamp", "name"))

# COMMAND ----------

# MAGIC %md
# MAGIC # Display images

# COMMAND ----------


eic_images_pd = EIC_Images_filtered.toPandas()

# Iterate over each row in the DataFrame
for row in range(0, len(eic_images_pd)):
    # Extract the base64 image string
    single_image = eic_images_pd['image_string'].iloc[row]

    # Decode the base64 image string
    decoded_value = base64.b64decode(single_image)
    # Convert the decoded bytes to a numpy array
    image = np.frombuffer(decoded_value, np.uint8)
    # Re-encode the image to base64
    encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
    # Define the image prefix
    prefix = "data:image/jpg;base64,"
    # Create a Plotly figure with the image
    fig = go.Figure(go.Image(source=prefix+encoded_image))
    # Update the layout of the figure
    fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
    fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
    # Convert the figure to JSON
    plotly_obj = fig.to_json()
    # Create a DataFrame with the JSON object
    result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
    # Display the figure
    fig.show()