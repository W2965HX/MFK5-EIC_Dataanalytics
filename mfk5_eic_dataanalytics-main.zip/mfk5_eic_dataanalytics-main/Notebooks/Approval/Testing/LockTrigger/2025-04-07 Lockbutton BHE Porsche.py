# Databricks notebook source
from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode_outer, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

import numpy as np
import pandas as pd
import base64

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

# COMMAND ----------

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-ff712c38-8b44-4012-8a8c-83305696389e`") # Lockbutton BHE Porsche

df = (df_read      
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)        
        .cache()
)

df = df.filter(col("timestamp") > F.date_sub(F.current_date(), 120))  # filter for data of last X days

display(df)
df.count()

# COMMAND ----------

df_images = (df_read
             .filter(col("name") == "Event Image Collector - Response")
             .select("timestamp", "containerId")
)

print("Number of images: "+ str(df_images.count()))
display(df_images)



# COMMAND ----------

imageContainerIds = ["2d884bc6-88d4-44b9-97bd-327234bf3039", "ad3a1080-89e0-48db-bf4e-44a6cc561dfb"]
EIC_Images = (df_read
            .filter(col("containerId").isin(imageContainerIds))
            .select("containerId", "timestamp", "name", "value")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("value", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("EIC_Response").isNotNull())

display(EIC_Images)

eic_images_pd = EIC_Images.toPandas()


# COMMAND ----------

for row in range(0, len(eic_images_pd)):
    single_image = eic_images_pd['image_string'].iloc[row] + '=='

    decoded_value = base64.b64decode(single_image)
    image = np.frombuffer(decoded_value, np.uint8)#[9:]
    encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
    prefix = "data:image/jpg;base64,"
    fig = go.Figure(go.Image(source=prefix+encoded_image))
    fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
    fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
    plotly_obj = fig.to_json()
    result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
    fig.show()