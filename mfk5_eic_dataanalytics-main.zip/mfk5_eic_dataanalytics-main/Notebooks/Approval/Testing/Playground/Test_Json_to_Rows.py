# Databricks notebook source
from pyspark.sql.functions import get_json_object

data = [("1", '{"name":"Max","age":25,"city":"Bielefeld"}')]
df = spark.createDataFrame(data, ["id", "dict_data"])
display(df)

df = df.withColumn("age", get_json_object(df.dict_data, '$.age'))
display(df)
