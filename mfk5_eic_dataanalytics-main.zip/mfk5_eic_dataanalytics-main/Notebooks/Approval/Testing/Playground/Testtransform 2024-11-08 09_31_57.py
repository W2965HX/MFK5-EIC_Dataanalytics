# Databricks notebook source
# MAGIC %md
# MAGIC # Beispiel: Arraydaten auf mehrere Zeilen aufteilen und Pivot "Name

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import posexplode, col, first

# Spark Session erstellen
spark = SparkSession.builder.appName("ExpandArrayColumns").getOrCreate()

# Beispiel-Daten mit zusätzlicher Spalte X
data = [
    (["A", "B"], [1, 2], [88, 99], "Konstant"),
    (None, None, None, "Other")
]

# DataFrame erstellen
df = spark.createDataFrame(data, ["Name", "Value", "Timestamp", "X"])
display(df)


# explode arrays to multiple rows
expanded_df = df.select(posexplode(col("Name")).alias("pos", "Name"),
                        col("Value")[col("pos")].alias("Value"),
                        col("Timestamp")[col("pos")].alias("Timestamp"),
                        col("X")
                        ).drop("pos")
display(expanded_df)

# filter for rows without array data . Cast Columntypes from Array<string> to string
notKonstant_df = (df.filter(df.X != "Konstant")
                 .withColumn("Name", df["Name"].cast("string"))   
                 .withColumn("Value", df["Value"].cast("string"))
                 .withColumn("Timestamp", df["Timestamp"].cast("string"))
)
display(notKonstant_df)

# join exploded arrays with other data
joined = expanded_df.union(notKonstant_df)
display(joined)

# Pivot daten
pivot_expanded_df = (joined.groupBy("Timestamp", "X")
                    .pivot("Name")
                    .agg(first("Value"))
)

display(pivot_expanded_df)




# COMMAND ----------

# MAGIC %md
# MAGIC # Beispiel: Transformation Daten

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType
from pyspark.sql.window import Window

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------

# Importieren der Funktion aus der Datei
import sys

# Fügen Sie den Pfad zum Repository-Root hinzu, falls noch nicht geschehen
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/decodeBHEData"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
import cso_vehicle_pb2
import extractBHEData
importlib.reload(cso_vehicle_pb2)
importlib.reload(extractBHEData)
from extractBHEData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)
# ---------- end ----------

# COMMAND ----------

# Pfad zur CSV-Datei
csv_file_path = "file:/Workspace/Users/volker.kippelt@cariad.technology/Playground/Sample_BHE_Image_data.csv"

# CSV-Datei lesen
df = spark.read.csv(csv_file_path, header=True, inferSchema=True)

#df = df.select(col("timestamp_unix"), col("name"), col("value"), col("userMessageId"))
df = df.where(col("name") != "TimeDiffLess30min_OnChangeToTrue")

display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Extend table with decoded BHE Data

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, PandasUDFType
from pyspark.sql.types import StructType, StructField, StringType, LongType, FloatType
import pandas as pd
import json

# Define User defined functions
decodeBHEData_udf = udf(convertBHEDataToDataFrame, ArrayType(StringType()))

@pandas_udf("struct<BHE_signal_name:array<string>, BHE_timestamp:array<long>, BHE_value:array<float>>", PandasUDFType.SCALAR)
def decode_udf(encoded_series: pd.Series) -> pd.DataFrame:
    def decode_and_flatten(encoded_value):
        try:
            decoded_df = convertBHEDataToDataFrame(encoded_value)        
            return pd.Series({
                'BHE_signal_name': decoded_df['Signalname'].tolist(),
                'BHE_timestamp': decoded_df['Timestamp'].tolist(),
                'BHE_value': decoded_df['Value'].tolist()
            })  
        except Exception as e:
            return pd.Series({
                'BHE_signal_name': [],
                'BHE_timestamp': [],
                'BHE_value': []
            })    
    return encoded_series.apply(decode_and_flatten)


decoded_BHE_Data = (df                                       
                    .withColumn("mfk5bhedatadecoded", when(col("name") != "mfk5bhedata", lit(None)).otherwise(decode_udf(df["value"])))
                    .withColumn("BHE_signal_names", col("mfk5bhedatadecoded.BHE_signal_name"))
                    .withColumn("BHE_timestamps", col("mfk5bhedatadecoded.BHE_timestamp"))
                    .withColumn("BHE_values", col("mfk5bhedatadecoded.BHE_value"))
)
#decoded_BHE_Data = decoded_BHE_Data.select("mfk5bhedatadecoded.BHE_signal_name")
display(decoded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Explode BHE values - Result is dataframe with only BHE data

# COMMAND ----------

exploded_BHE_Data = decoded_BHE_Data.select(
                        col("orderId"),
                        col("mdc_id"),
                        col("g_id"),
                        col("name"),
                        col("value"),
                        col("unit"),
                        col("timestamp"),
                        col("ingest_timestamp"),
                        col("orderVersion"),
                        col("correlationId"),
                        col("containerId"),
                        col("containerMsgCount"),
                        col("containerMsgId"),
                        col("schemaId"),
                        col("vehicleId"),
                        col("useCaseIds"),
                        col("userMessageId"),
                        col("time"),
                        col("userId"),
                        col("payloadUrl"),
                        col("image_processing_batch_id"),
                        col("consumption_timestamp"),
                        col("ingest_date"),
                        col("date"),
                        col("timestamp_unix"),
                        col("ingestDate_wo_ms"),
                        col("mfk5bhedatadecoded"),
                        posexplode(col("BHE_signal_names")).alias("pos", "BHE_signal_names"),
                        col("BHE_values")[col("pos")].alias("BHE_values"),
                        col("BHE_timestamps")[col("pos")].alias("BHE_timestamps"),
                        ).drop("pos")

# Set BHE timestamp as timestamp_unix
#exploded_BHE_Data = exploded_BHE_Data.withColumn("timestamp_unix", col("BHE_timestamps"))

display(exploded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter original dataframe for data without BHE data

# COMMAND ----------


# Cast Columntypes from Array<*> to *, to be able to union dataframe afterwards
nonBHE_df = (decoded_BHE_Data.filter(decoded_BHE_Data.name != "mfk5bhedata")
                .withColumn("BHE_signal_names", decoded_BHE_Data["BHE_signal_names"].cast("string"))   
                .withColumn("BHE_values",     element_at(col("BHE_values"), 1).cast("float")) 
                .withColumn("BHE_timestamps", element_at(col("BHE_timestamps"), 1).cast("bigint"))                
)
display(nonBHE_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Union exploded BHE Data with other data

# COMMAND ----------

# Make sure that column order and colum names match 
exploded_BHE_Data = exploded_BHE_Data.select(nonBHE_df.columns)

union_df = exploded_BHE_Data.union(nonBHE_df)

print("Unioned Dataframe has %d rows" % union_df.count())
display(union_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot data

# COMMAND ----------

window_events  = Window.partitionBy("userMessageId")

pivot_df_name = (union_df
            .groupBy("timestamp_unix", "vehicleId", "containerMsgCount", "name", "value","userMessageId", "BHE_signal_names", "BHE_timestamps", "BHE_values")
            .pivot("name")
            .agg(F.first("value"))
            .drop(col("name"), col("value"))            
        )
display(pivot_df_name)

pivot_df_BHE_name = (pivot_df_name
            .groupBy("timestamp_unix", "vehicleId", "containerMsgCount", "userMessageId", "EIC_ID", "Event Image Collector - Response", "Outdoor temperature", "TimeDiffClamp15VelocityGreater5", "longitude", "latitude", "BHE_timestamps", "BHE_signal_names", "BHE_values")
            .pivot("BHE_signal_names")
            .agg(F.first("BHE_values"))
            .drop(col("BHE_signal_names"), col("BHE_values"), col("null"), col("mfk5bhedata"))
            .withColumn("event_time", (col("timestamp_unix") - F.min(col("timestamp_unix")).over(window_events))/1000)
            .sort(col("timestamp_unix").asc())
)
display(pivot_df_BHE_name)

# COMMAND ----------

# MAGIC %md
# MAGIC # Plot BHE Values

# COMMAND ----------

pivot_df_BHE_name_pd = (pivot_df_BHE_name                        
                        .select('BHE_timestamps', 'sig_BHE_FC1_Freesight')
                        .dropna()
                        .toPandas()
)
pivot_df_BHE_name_pd['BHE_timestamps'] = pd.to_datetime(pivot_df_BHE_name_pd['BHE_timestamps'], unit='ms'); 
pivot_df_BHE_name_pd = pivot_df_BHE_name_pd.sort_values('BHE_timestamps')

display(pivot_df_BHE_name_pd)

plt.figure()
plt.plot(pivot_df_BHE_name_pd['BHE_timestamps'], pivot_df_BHE_name_pd['sig_BHE_FC1_Freesight'])
plt.xlabel('Timestamp')
plt.ylabel('Value')
plt.xticks(rotation=45)  # Drehung der x-Achse-Beschriftungen, um Überlappungen zu vermeiden
# plt.tight_layout()  # Layout anpassen, um Überlappungen zu vermeiden
plt.show()  

# COMMAND ----------

# MAGIC %md
# MAGIC # Event summary

# COMMAND ----------

# Define windows
window_events = Window.partitionBy("userMessageId")

# define window for extracting all EIC images for one event
window_EIC = (Window.partitionBy("vehicleId")
                    .orderBy("mean_timestamp_unix")
                    .rangeBetween(-10000, 10000)
)
time_signal = "timestamp_unix"

# todo: remove
pivot_df_BHE_name = pivot_df_BHE_name.filter(col("containerMsgCount").isNotNull())

output_df = (
    pivot_df_BHE_name
    # calculate activation time --> t_0 = 0 at first WBA action
    #.withColumn("time_after_activation", when((col("WBA_Warnung_Level") >=2) & (col("WBA_Warnung_Level") <=4), col(time_signal)))
    #.withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)

    # calc gps position at activation time
    #.withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("activation_time")))
    #.withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("activation_time")))
    #.withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_events), col("latitude")))
    #.withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_events), col("longitude")))
    .groupBy("userMessageId", "vehicleId", "containerMsgCount")
    .agg(
            #F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),
            #F.min("time_after_activation").alias("unix_time_at_activation"),
            #F.first(time_signal).alias("first_unix_timestamp"),
            #F.max("cycle_time_adaption").alias("cycle_time_adaption"),
            #F.min("t_shift").alias("t_shift"),
            #F.min("WBA_Warnung_Level").alias("min_wba_warnung"),
            #F.max("WBA_Warnung_Level").alias("max_wba_warnung"),
            #F.max("event_time").alias("max_event_time"),
            #F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),
            #F.count("VDSO_Vx3dFrq50").alias("count_VDSO_Vx3dFrq50"),
            #F.count("WBA_Warnung").alias("count_WBA_Warnung"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            #F.count("brakePedalIntensity").alias("count_brakePedalIntensity"),
            F.count("Event Image Collector - Response").alias("count_EIC_Response"),
            F.max("sig_BHE_FC1_Freesight").alias("max_sig_BHE_FC1_Freesight"),
            F.min("sig_BHE_FC1_Freesight").alias("min_sig_BHE_FC1_Freesight"),
            #F.first("act_lat", ignorenulls=True).alias("act_lat"),
            #F.first("act_long", ignorenulls=True).alias("act_long")
            F.mean("timestamp_unix").alias("mean_timestamp_unix")
        )
        # set activation time of eic images to their unix timestamp
        #.withColumn("unix_time_at_activation",
        #            when(col("unix_time_at_activation").isNotNull(), col("unix_time_at_activation"))
        #            .otherwise(col("first_unix_timestamp")))
        .select(
            #"ingestDate_wo_ms",
            "userMessageId",
            "vehicleId",
            "containerMsgCount",
            #"unix_time_at_activation",
            #"max_event_time",
            #"max_wba_warnung",
            #"min_wba_warnung",
            #"cycle_time_adaption",
            #"t_shift",
            #"act_lat",
            #"act_long",
            #"count_DW_Kilometerstand",
            "count_EIC_Response",
            #"count_VDSO_Vx3dFrq50",
            #"count_WBA_Warnung",
            "count_latitude",
            "count_longitude",
            "max_sig_BHE_FC1_Freesight",
            "min_sig_BHE_FC1_Freesight",
            "mean_timestamp_unix"
            #"count_brakePedalIntensity",
        )
        .withColumn("EICMessageId",
                    when(col("containerMsgCount") > 1, F.collect_set(col("userMessageId")).over(window_EIC))
                   .otherwise(F.array()))
        #.withColumn("EICMessageId", F.expr("filter(EICMessageId, x -> x != userMessageId)"))
        #.orderBy("ingestDate_wo_ms", ascending=False)
    )
display(output_df)