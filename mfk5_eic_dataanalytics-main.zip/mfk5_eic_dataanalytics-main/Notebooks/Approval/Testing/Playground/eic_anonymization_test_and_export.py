# Databricks notebook source
# MAGIC %md
# MAGIC Sucht euch hier einen Dateinamen aus und setzt ihn oben im Widget "filename" ein. Ihr könnt über das Widget "table" aus den Tabellen "license_plates_false_negatives" und "pedestrians_critical" wählen.

# COMMAND ----------

import pyspark.sql.functions as f
import base64
from io import BytesIO
from PIL import Image
import matplotlib.pyplot as plt
import os.path
import numpy as np

df_results = spark.read.table(f"ude_int_euno_fhum_adas_cariad.eicmfk_gold.{dbutils.widgets.get("table")}").cache()
df_results.select("filename").drop_duplicates().display()



# COMMAND ----------

# MAGIC %md
# MAGIC Führt die Zelle aus, um euch das vergrößerte Bild im Vergleich zum Original anzuschauen. Probiert über das Widget "threshold" die verschiedenen Schwellenwerte aus.

# COMMAND ----------

def display_image(image):
    image_dec = base64.b64decode(image)
    img = BytesIO(image_dec)
    img = Image.open(img)
    display(img)

#image = df_results.where(f.col("filename") == dbutils.widgets.get("filename"))
#display(image)

filename = dbutils.widgets.get("filename")

image = df_results.where(f.col("lp_threshold") == dbutils.widgets.get("threshold")).where(f.col("filename") == filename).where(f.col("resized") == True).collect()[0]["image"]

display_image(image)
image_small = df_results.where(f.col("lp_threshold") == dbutils.widgets.get("threshold")).where(f.col("filename") == filename).where(f.col("resized") == False).collect()[0]["image"]
display_image(image_small)

# COMMAND ----------

# MAGIC %md
# MAGIC Speichere alle großen Bilder mit dem aktuellen Schwellwert ab

# COMMAND ----------



df_filenames = df_results.select("filename").drop_duplicates()
display(df_filenames)

#filename = dbutils.widgets.get("filename") 
threshold = dbutils.widgets.get("threshold")

for row in df_filenames.select("filename").collect():
    filename = row["filename"]
    image = df_results.where(f.col("lp_threshold") == threshold).where(f.col("filename") == filename).where(f.col("resized") == True).collect()[0]["image"]

    # Decode the base64 image to a numpy array
    image_dec = base64.b64decode(image)
    img = BytesIO(image_dec)
    img = Image.open(img)
    image_array = np.array(img)

    image_path = f"/Workspace/Users/volker.kippelt@cariad.technology/ExportedImages/IndicatorAndVelocityLess5kmh_Resim/LicensePlates/{threshold}/{filename}"

    if not os.path.exists(image_path):
        os.makedirs(os.path.dirname(image_path), exist_ok=True)

    plt.imsave(image_path, image_array,  cmap='gray', vmin=0, vmax=255)
