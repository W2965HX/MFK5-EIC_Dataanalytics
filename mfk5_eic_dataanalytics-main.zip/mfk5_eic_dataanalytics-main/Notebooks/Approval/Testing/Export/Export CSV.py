# Databricks notebook source
#lastDays = 3
#usecaseString = "UseCase-e1cf8455-c41d-47e4-9df1-4a76f02c4177"
#foldername = "LocktriggerImages"

#lastDays = 30
#usecaseString = "useCase-fb976897-c4df-4782-a244-1bbd4be81496"
#foldername = "IndicatorAndVelocityLess5kmh"

lastDays = 5
usecaseString = "useCase-25277b96-c15e-43f4-987d-23883270490f"
foldername = "EIC_MFK5_Perception_OD_ConfBit_Cl6_V0_1"

# COMMAND ----------

from pyspark.sql.functions import col, radians, year, when, lit, date_format
from pyspark.sql import functions as F
import plotly.graph_objects as go
from pyspark.sql.window import Window

from datetime import datetime
import numpy as np
import pandas as pd

import base64
import re
import array
import io
import os.path
from PIL import Image
import matplotlib.pyplot as plt

# COMMAND ----------

'''
def extractStringData(start, end, string):
    pattern = f"{start}(.*?){end}"
    match = re.search(pattern, string)
    extractedString = match.group(1).strip()
    return extractedString

def extract_substring(long_string, start_string, end_string):
    try:
        start_index = long_string.index(start_string) + len(start_string)
        end_index = long_string.index(end_string, start_index)
        return long_string[start_index:end_index]
    except ValueError:
        return "start or end string not found"

def extractImageDataFromADASValue(adasValue):
    extracted_imageb64 = extract_substring("image\":\"", "\",\"metadata\":", adasValue)
    return extracted_imageb64

def extractMetadataFromADASValue(adasValue):
    extracted_eventID = extract_substring("event_id\":", ",\"timestamp", adasValue)
    extracted_timestamp = extract_substring("timestamp\":", "}}]", adasValue)
    return extracted_eventID, extracted_timestamp
'''
def base64ToIntArray(encoded_array):
    decoded_array = base64.b64decode(encoded_array)
    int_array = array.array('B')
    int_array.frombytes(decoded_array)
    return int_array


# COMMAND ----------

df = spark.read.table(f"ude_int_euno_fhum_adas_cariad.eicmfk_silver.`{usecaseString}`")

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")


df = (df.filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        .filter(col("name")=="Event Image Collector - Response")
        # get image string right of "image:"
        #.withColumn("image_string", F.substring_index("value", "image\":", -1))
        # get image string left of "," --> only base64 image string remains
        #.withColumn("image_string", F.substring_index("image_string", ",", 1))    
        #.withColumn("image_string", F.substring_index("image_string", " ,\"", 1))    
        #.withColumn("image_string", F.substring_index("image_string", ",\"", 1))          
        # get event id
        #.withColumn("eventId_string", F.substring_index("value", "event_id\": ", -1))
        #.withColumn("eventId_string", F.substring_index("eventId_string", ",", 1))    
        # get requested timestamp      
        #.withColumn("reqTimestamp_string", F.substring_index("value", "timestamp\": ", -1))
        #.withColumn("reqTimestamp_string", F.substring_index("reqTimestamp_string", "}", 1))   
)

display(df)
df.count()

# COMMAND ----------

exportTime = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

csv_path = f"/Workspace/Users/volker.kippelt@cariad.technology/ExportedTables/{foldername}/{exportTime}_{foldername}_.csv"

directory = os.path.dirname(csv_path)

if not os.path.exists(directory):
    os.makedirs(directory)

pdf = df.toPandas()
pdf.to_csv(csv_path, index=False)



# COMMAND ----------

'''
exportTime = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")

# Counter, that increases every 100th row. Will be used as Foldername (Folders need to be small - otherwise download is not possible)
counter = 0

for idx, row in enumerate(df.collect(), start=1):
    
    if idx % 100 == 1:
        counter += 1
    raw_data = row['image_string'] + '==' 
    
    try:
        eicResponseIntArray = base64ToIntArray(raw_data)  
        image = Image.open(io.BytesIO(eicResponseIntArray))
        image = np.array(image)      
        image = image.reshape(540,960)   

        formatted_date = row['timestamp'].strftime("%Y-%m-%d_%H-%M-%S-%f")   

        image_path = f"/Workspace/Users/volker.kippelt@cariad.technology/ExportedImages/{foldername}/{exportTime}/{counter}/{formatted_date}_vehId_{row['vehicleId']}_contId_{row['containerId']}_eventId_{row['eventId_string']}.png"
        #image_path = f"/dbfs/FileStore/EIC/{row['timestamp']}_{row['vehicleId']}_{row['containerId']}.png"
        if not os.path.exists(image_path):
            os.makedirs(os.path.dirname(image_path), exist_ok=True)

        plt.imsave(image_path, image,  cmap='gray', vmin=0, vmax=255)
    except Exception as e:
        print(f"Error decoding in containerId: {row["containerId"]} Error: {e}")

'''    
