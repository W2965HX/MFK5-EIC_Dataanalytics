# Databricks notebook source
# MAGIC %md
# MAGIC # Install protobuf + restart Python

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode_outer, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------
import sys

repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
from EICModules.decoding.decodeHighlevelData import decodeBHE
importlib.reload(decodeBHE)
# ---------- end ----------

# Define User defined functions
#decodeBHEData_udf = udf(decodeBHE.convertBHEDataToDataFrame, ArrayType(StringType()))

# COMMAND ----------

# MAGIC %md
# MAGIC # Read data + Filter for last X days

# COMMAND ----------

#df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-1da2c68a-5bca-4e8c-9c17-b987e8d58d1b`") # On startup
df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-bd1715ac-e9d4-40ee-8921-465abe1ab838`") # Camera and radar blindness

df = (df_read      
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)        
        .cache()
)

df = df.filter(col("timestamp") > F.date_sub(F.current_date(), 250))  # filter for data of last X days

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot table

# COMMAND ----------

pivot_df_name = (df
            .groupBy("timestamp", "vehicleId", "timestamp_unix", "name", "value", "userMessageId", "containerId", "containerMsgCount")
            .pivot("name")
            .agg(F.first("value"))            
            .drop(col("name"), col("value"))            
        )
display(pivot_df_name)
pivot_df_name.count()

# COMMAND ----------

# MAGIC %md
# MAGIC #Rename columns

# COMMAND ----------


pivot_df_name = (pivot_df_name
                 .withColumnRenamed("Event Image Collector - Response", "EIC_Response")
                 .withColumnRenamed("Outdoor temperature", "Outdoor_temp")
                 .withColumnRenamed("WarnBrakeEvadeEventData functionStatus Event", "WBA_func_status")
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Extend columns
# MAGIC

# COMMAND ----------

pivot_df_name = (pivot_df_name                 
                 .withColumn("Outdoor_temp_C", col("Outdoor_temp")-273.15)
                 
)

# COMMAND ----------

# MAGIC %md
# MAGIC # Extend table with decoded BHE Data

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, PandasUDFType
from pyspark.sql.types import StructType, StructField, StringType, LongType, FloatType, ArrayType, IntegerType

import pandas as pd
import json


@pandas_udf("struct<BHE_signal_name:array<string>, BHE_timestamp:array<long>, BHE_value:array<float>>", PandasUDFType.SCALAR)
def decode_udf(encoded_series: pd.Series) -> pd.DataFrame:
    def decode_and_flatten(encoded_value):
        try:
            decoded_df = decodeBHE.convertBHEDataToDataFrame(encoded_value)        
            return pd.Series({
                'BHE_signal_name': decoded_df['Signalname'].tolist(),
                'BHE_timestamp': decoded_df['Timestamp'].tolist(),
                'BHE_value': decoded_df['Value'].tolist()
            })  
        except Exception as e:
            return pd.Series({
                'BHE_signal_name': [],
                'BHE_timestamp': [],
                'BHE_value': []
            })    
    return encoded_series.apply(decode_and_flatten)


decoded_BHE_Data = (pivot_df_name                                       
                    .withColumn("mfk5bhedatadecoded", when(col("mfk5bhedata").isNull(), lit(None)).otherwise(decode_udf(pivot_df_name["mfk5bhedata"])))
                    .withColumn("BHE_signal_names", col("mfk5bhedatadecoded.BHE_signal_name"))
                    .withColumn("BHE_timestamps_unix", col("mfk5bhedatadecoded.BHE_timestamp"))
                    .withColumn("BHE_values", col("mfk5bhedatadecoded.BHE_value"))
)
display(decoded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Explode BHE values 
# MAGIC ## to get separate rows for each BHE event

# COMMAND ----------


#see: https://medium.com/@basavarajd119/pyspark-explode-posexplode-and-outer-explode-with-an-examples-c7453a797523
# explode: This function takes a column that contains arrays and creates a new row for each element in the array, duplicating the rest of the columns’ values.
# posexplode: Similar to explode, but it also adds a new column that indicates the position of the element in the array.
# https://spark.apache.org/docs/latest/api/python/reference/pyspark.sql/api/pyspark.sql.functions.posexplode_outer.html

exploded_BHE_Data = decoded_BHE_Data.select(
                        #col("orderId"),
                        #col("mdc_id"),
                        #col("g_id"),
                        #col("name"),
                        #col("value"),
                        #col("unit"),
                        col("timestamp"),
                        #col("ingest_timestamp"),
                        #col("orderVersion"),
                        #col("correlationId"),
                        col("containerId"),
                        col("containerMsgCount"),
                        #col("containerMsgId"),
                        #col("schemaId"),
                        col("vehicleId"),
                        #col("useCaseIds"),
                        col("userMessageId"),
                        #col("time"),
                        #col("userId"),
                        #col("payloadUrl"),
                        #col("image_processing_batch_id"),
                        #col("consumption_timestamp"),
                        #col("ingest_date"),
                        #col("date"),
                        col("timestamp_unix"),
                        col("DW_Kilometerstand"),
                        col("EIC_ID"),
                        col("EIC_Response"),
                        col("Outdoor_temp"),
                        col("Outdoor_temp_C"),
                        col("VDSO_Vx3dGNSS"),
                        col("WBA_func_status"),
                        col("latitude"),
                        col("longitude"),
                        #col("ingestDate_wo_ms"),
                        col("mfk5bhedatadecoded"),
                        posexplode_outer(col("BHE_signal_names")).alias("pos", "BHE_signal_names"),
                        col("BHE_values")[col("pos")].alias("BHE_values"),
                        col("BHE_timestamps_unix")[col("pos")].alias("BHE_timestamps_unix"),
                        ).drop("pos")

display(exploded_BHE_Data)
exploded_BHE_Data.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot BHE-Values

# COMMAND ----------

pivot_all = (exploded_BHE_Data
            .groupBy("timestamp", "vehicleId", "timestamp_unix", "userMessageId", "containerId", "containerMsgCount", "DW_Kilometerstand", "EIC_ID", "EIC_Response", "Outdoor_temp_C", "VDSO_Vx3dGNSS", "WBA_func_status", "latitude", "longitude", "BHE_timestamps_unix")
            .pivot("BHE_signal_names")
            .agg(F.first("BHE_values"))
            .drop(col("BHE_signal_names"), col("BHE_values"))            
        )
display(pivot_all)
pivot_all.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Decode WBA functionStatus

# COMMAND ----------

# UDF decode WBA function status and return bytes as a list
def decode_as_list(value):
    if value is None or value == '':
        return []
    decoded_bytes = base64.b64decode(value)    
    extracted_value = list(struct.unpack(f'{len(decoded_bytes)}B', decoded_bytes))
    return extracted_value

decode_as_list_udf = udf(decode_as_list, ArrayType(IntegerType()))


pivot_all = (pivot_all
                    # Decode all bytes as a list
                    .withColumn("WBA_decoded", when(col("WBA_func_status").isNotNull(),decode_as_list_udf(col("WBA_func_status"))))
                    .withColumn("WBA_systemStatus", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[0]).otherwise(lit(None)))
                    .withColumn("WBA_hasErrorCamera", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[5]).otherwise(lit(None)))
                    .withColumn("WBA_isCameraBlind", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[6]).otherwise(lit(None)))
                    .withColumn("WBA_isNanoRadarRightBlind", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[8]).otherwise(lit(None)))
                    .withColumn("WBA_isNanoRadarLeftBlind", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[10]).otherwise(lit(None)))
                    .withColumn("WBA_isFrontRadarBlind", when(col("WBA_decoded").isNotNull(), col("WBA_decoded")[12]).otherwise(lit(None)))
)

display(pivot_all)

                                                                              

# COMMAND ----------

# MAGIC %md
# MAGIC # Add triggertime to meta data report and images

# COMMAND ----------

pivot_all = (pivot_all
                .withColumn("triggertime_unix", when((col("EIC_ID").isNotNull() | col("EIC_Response").isNotNull()), col("timestamp_unix")).otherwise(None))
                
)

display(pivot_all)

# COMMAND ----------

# MAGIC %md
# MAGIC # Event overview

# COMMAND ----------


overview_df = (
        pivot_all
        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            #F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),
            #F.first("triggertime").alias("first_triggertime"),
            F.max("triggertime_unix").alias("triggertime_unix"),
            F.first("timestamp").alias("first_timestamp"),
            F.first("timestamp_unix").alias("first_timestamp_unix"),
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_Response").alias("count_EIC_Response"),
            F.first("latitude", ignorenulls=True).alias("latitude"),
            F.first("longitude", ignorenulls=True).alias("logitude"),
            F.first("VDSO_Vx3dGNSS", ignorenulls=True).alias("first_VDSO_Vx3dGNSS"),
            F.first("Outdoor_temp_C", ignorenulls=True).alias("first_Outdoor_temp_C"),
            F.collect_set("sig_BHE_FC1_FSFrozenWindshield").alias("FSFrozenWindshield_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentLightAssist").alias("ImpairmentLightAssist_Values"),
            F.collect_set("sig_BHE_FC1_SelfGlareIntensity").alias("SelfGlareIntensity_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentSHPS").alias("ImpairmentSHPS_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentOD").alias("ImpairmentOD_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentLDA").alias("ImpairmentLDA_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentPED").alias("ImpairmentPED_Values"),
            F.collect_set("sig_BHE_FC1_Freesight").alias("Freesight_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentTSR").alias("ImpairmentTSR_Values"),
            F.collect_set("sig_BHE_FC1_ImpairmentODACC").alias("ImpairmentODACC_Values"),
            F.collect_set("sig_BHE_FC1_FSRain").alias("FSRain_Values"),
            F.collect_set("sig_BHE_FC1_FSBlur").alias("FSBlur_Values"),
            F.collect_set("sig_BHE_FC1_FSLowSun").alias("FSLowSun_Values"),
            F.collect_set("sig_BHE_FC1_FSBlockage").alias("FSBlockage_Values"),
            F.collect_set("sig_BHE_FC1_FSPartialBlockage").alias("FSPartialBlockage_Values"),
            F.collect_set("sig_BHE_FC1_FSFog").alias("FSFog_Values"),
            F.collect_set("sig_BHE_FC1_FSSplashes").alias("FSSplashes_Values"),
            F.collect_set("sig_BHE_FC1_HeatingRequest").alias("HeatingRequest_Values"),
            F.collect_set("WBA_systemStatus").alias("WBA_systemStatus_Values"),
            F.collect_set("WBA_hasErrorCamera").alias("WBA_hasErrorCamera_Values"),
            F.collect_set("WBA_isCameraBlind").alias("WBA_isCameraBlind_Values"),
            F.collect_set("WBA_isNanoRadarRightBlind").alias("WBA_isNanoRadarRightBlind_Values"),
            F.collect_set("WBA_isNanoRadarLeftBlind").alias("WBA_isNanoRadarLeftBlind_Values"),
            F.collect_set("WBA_isFrontRadarBlind").alias("WBA_isFrontRadarBlind_Values")
        )
    )
display(overview_df)
   
   

# COMMAND ----------

# MAGIC %md
# MAGIC # Add image references to event overview

# COMMAND ----------

from pyspark.sql.window import Window
from pyspark.sql.functions import collect_list, expr
                
window_EIC = (Window.partitionBy("vehicleId")
                    .orderBy("triggertime_unix")
                    .rangeBetween(-10000, 10000)
)
overview_df_with_images = (overview_df 
        #.filter(col("containerMsgCount") > 1)       
        # collect all containerIds in the window
        .withColumn("containerIds_EIC_Images", F.collect_set(col("containerId")).over(window_EIC))
        # remove own containerId from list  of containerIds_EIC_Images
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))
        #.select("containerId", "vehicleId", "containerMsgCount", "triggertime_unix", "containerIds_EIC_Images")
        )
display(overview_df_with_images)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter for only meta data reports (images are linked)

# COMMAND ----------

overview_df_only_metadata = overview_df_with_images.filter(col("containerMsgCount") > 1)   

display(overview_df_only_metadata)

# COMMAND ----------

# MAGIC %md
# MAGIC # Write full data to goldlayer

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"  
my_project_name = "eicmfk"                        
my_gold_layer_table_name = "BHEEventsDecoded"

pivot_all.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Write overview to goldlayer

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"  
my_project_name = "eicmfk"                        
my_gold_layer_table_name = "BHEEventsOverview"

overview_df_only_metadata.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC # Optional: Delete Tables

# COMMAND ----------


'''
my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "BHEEventsDecoded"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)

my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "BHEEventsOverview"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''
