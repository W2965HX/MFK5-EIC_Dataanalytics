# Databricks notebook source
# MAGIC %md
# MAGIC # Install protobuf + restart Python

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------
import sys

repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
from EICModules.decodeHighlevelData import decodeBHE
importlib.reload(decodeBHE)
# ---------- end ----------

# Define User defined functions
#decodeBHEData_udf = udf(decodeBHE.convertBHEDataToDataFrame, ArrayType(StringType()))

# COMMAND ----------

# MAGIC %md
# MAGIC # Read data + Filter for last X days

# COMMAND ----------

#df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-1da2c68a-5bca-4e8c-9c17-b987e8d58d1b`") # On startup
df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-bd1715ac-e9d4-40ee-8921-465abe1ab838`") # Camera and radar blindness

df = (df_read      
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)        
        .cache()
)

df = df.filter(col("timestamp") > F.date_sub(F.current_date(), 30))  # filter for data of last 30 days

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Extend table with decoded BHE Data

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, PandasUDFType
from pyspark.sql.types import StructType, StructField, StringType, LongType, FloatType
import pandas as pd
import json

# Define User defined functions
#decodeBHEData_udf = udf(decodeBHE.convertBHEDataToDataFrame, ArrayType(StringType()))

@pandas_udf("struct<BHE_signal_name:array<string>, BHE_timestamp:array<long>, BHE_value:array<float>>", PandasUDFType.SCALAR)
def decode_udf(encoded_series: pd.Series) -> pd.DataFrame:
    def decode_and_flatten(encoded_value):
        try:
            decoded_df = decodeBHE.convertBHEDataToDataFrame(encoded_value)        
            return pd.Series({
                'BHE_signal_name': decoded_df['Signalname'].tolist(),
                'BHE_timestamp': decoded_df['Timestamp'].tolist(),
                'BHE_value': decoded_df['Value'].tolist()
            })  
        except Exception as e:
            return pd.Series({
                'BHE_signal_name': [],
                'BHE_timestamp': [],
                'BHE_value': []
            })    
    return encoded_series.apply(decode_and_flatten)


decoded_BHE_Data = (df                                       
                    .withColumn("mfk5bhedatadecoded", when(col("name") != "mfk5bhedata", lit(None)).otherwise(decode_udf(df["value"])))
                    .withColumn("BHE_signal_names", col("mfk5bhedatadecoded.BHE_signal_name"))
                    .withColumn("BHE_timestamps", col("mfk5bhedatadecoded.BHE_timestamp"))
                    .withColumn("BHE_values", col("mfk5bhedatadecoded.BHE_value"))
)
#decoded_BHE_Data = decoded_BHE_Data.select("mfk5bhedatadecoded.BHE_signal_name")
display(decoded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Explode BHE values - Result is dataframe with only BHE data
# MAGIC ## Other data needs to be filtered separately and then unioned mit BHE data

# COMMAND ----------


#see: https://medium.com/@basavarajd119/pyspark-explode-posexplode-and-outer-explode-with-an-examples-c7453a797523
# explode: This function takes a column that contains arrays and creates a new row for each element in the array, duplicating the rest of the columns’ values.
# posexplode: Similar to explode, but it also adds a new column that indicates the position of the element in the array.

exploded_BHE_Data = decoded_BHE_Data.select(
                        col("orderId"),
                        col("mdc_id"),
                        col("g_id"),
                        col("name"),
                        col("value"),
                        col("unit"),
                        col("timestamp"),
                        col("ingest_timestamp"),
                        col("orderVersion"),
                        col("correlationId"),
                        col("containerId"),
                        col("containerMsgCount"),
                        col("containerMsgId"),
                        col("schemaId"),
                        col("vehicleId"),
                        col("useCaseIds"),
                        col("userMessageId"),
                        col("time"),
                        col("userId"),
                        col("payloadUrl"),
                        col("image_processing_batch_id"),
                        col("consumption_timestamp"),
                        col("ingest_date"),
                        #col("date"),
                        col("timestamp_unix"),
                        col("ingestDate_wo_ms"),
                        col("mfk5bhedatadecoded"),
                        posexplode(col("BHE_signal_names")).alias("pos", "BHE_signal_names"),
                        col("BHE_values")[col("pos")].alias("BHE_values"),
                        col("BHE_timestamps")[col("pos")].alias("BHE_timestamps"),
                        ).drop("pos")

display(exploded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter original dataframe for data without BHE data and add additional column as preparation for union
# MAGIC

# COMMAND ----------


# Cast Columntypes from Array<*> to *, to be able to union dataframe afterwards
nonBHE_df = (decoded_BHE_Data.filter(decoded_BHE_Data.name != "mfk5bhedata")
                .withColumn("BHE_signal_names", decoded_BHE_Data["BHE_signal_names"].cast("string"))   
                .withColumn("BHE_values",     element_at(col("BHE_values"), 1).cast("float")) 
                .withColumn("BHE_timestamps", element_at(col("BHE_timestamps"), 1).cast("bigint"))
)
display(nonBHE_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Union exploded BHE Data with other data

# COMMAND ----------

# Make sure that column order and colum names match 
exploded_BHE_Data = exploded_BHE_Data.select(nonBHE_df.columns)

union_df = exploded_BHE_Data.union(nonBHE_df)
display(union_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot data

# COMMAND ----------

# MAGIC %md
# MAGIC ## 1. Pivot: Create additional columns for data that in non BHE
# MAGIC

# COMMAND ----------

pivot_df_name = (union_df
            .groupBy("timestamp_unix", "name", "value","userMessageId", "BHE_signal_names", "BHE_timestamps", "BHE_values")
            .pivot("name")
            .agg(F.first("value"))
            .drop(col("name"), col("value"))            
        )
display(pivot_df_name)

# COMMAND ----------

# MAGIC %md
# MAGIC ## 2. Pivot: Create additional columns for BHE data 
# MAGIC

# COMMAND ----------



'''
pivot_df_BHE_name = (pivot_df_name
            .groupBy("timestamp_unix", "userMessageId", "EIC_ID", "Event Image Collector - Response", "Outdoor temperature", "TimeDiffClamp15VelocityGreater5", "longitude", "latitude", "BHE_timestamps", "BHE_signal_names", "BHE_values")
            .pivot("BHE_signal_names")
            .agg(F.first("BHE_values"))
            .drop(col("BHE_signal_names"), col("BHE_values"), col("null"), col("mfk5bhedata"))
            .sort(col("timestamp_unix").asc())
)'''
pivot_df_BHE_name = (pivot_df_name
            .groupBy("timestamp_unix", "userMessageId", "EIC_ID", "Event Image Collector - Response", "Outdoor temperature", "longitude", "latitude", "BHE_timestamps", "BHE_signal_names", "BHE_values")
            .pivot("BHE_signal_names")
            .agg(F.first("BHE_values"))
            .drop(col("BHE_signal_names"), col("BHE_values"), col("null"), col("mfk5bhedata"))
            .sort(col("timestamp_unix").asc())
)
display(pivot_df_BHE_name)

# COMMAND ----------

# MAGIC %md
# MAGIC # todo: Create Event overview

# COMMAND ----------

'''

from pyspark.sql.window import Window

def eic_bhe_event_summary(input_df):
    # Define windows
    window_events = Window.partitionBy("userMessageId")
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")
                        .orderBy("unix_time_at_activation")
                        .rangeBetween(-10000, 10000)
    )
    time_signal = "timestamp_unix"

    output_df = (
        input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Ped_event to EIC_ID
        .withColumn("time_after_activation", when(col("Ped_event").isNotNull(), col(time_signal)))
        .withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)

        # calc gps position at activation time
        .withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("activation_time")))
        .withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("activation_time")))
        .withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_events), col("latitude")))
        .withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_events), col("longitude")))
        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),
            F.min("time_after_activation").alias("unix_time_at_activation"),
            F.first(time_signal).alias("first_unix_timestamp"),
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_Response").alias("count_EIC_Response"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Ped_event").alias("count_Ped_event"),
            F.count("RG_RA_CountryCode").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            F.count("weather_cond_json").alias("count_weather_cond_json"),
            F.count("env_brightness").alias("count_env_brightness"),
            F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            F.count("low_beam_state").alias("count_low_beam_state"),
            F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).alias("act_lat"),
            F.first("act_long", ignorenulls=True).alias("act_long"),
            F.collect_set("ConfBitL1").alias("ConfBit1_Values"),
            F.collect_set("ConfBitL2").alias("ConfBit2_Values"),
            F.collect_set("ConfBitL3").alias("ConfBit3_Values")
        )
        # set activation time of eic images to their unix timestamp
        .withColumn("unix_time_at_activation",
                    when(col("unix_time_at_activation").isNotNull(), col("unix_time_at_activation"))
                    .otherwise(col("first_unix_timestamp")))
        .select(
            "containerId",
            "userMessageId",
            "vehicleId",
            "containerMsgCount",
            "ingestDate_wo_ms",
            "unix_time_at_activation",
            "first_unix_timestamp",
            "count_DW_Kilometerstand",
            "count_EIC_ID",
            "count_EIC_Response",
            "count_LWI_AgStgWhl",
            "count_Ped_event",
            "count_RG_RA_CountryCode",
            "count_Streetclass",
            "count_VDSO_AgvYawRateOfsCmp",
            "count_VDSO_Vx3dGNSS",
            "count_high_beam_state",
            "count_latitude",
            "count_longitude",  
            "act_lat",
            "act_long",
            "ConfBit1_Values",
            "ConfBit2_Values",
            "ConfBit3_Values",  
            "count_Outdoor_temp_C",
            "count_outside_temp_hum_json",
            "count_outside_dewpoint",             
            "count_weather_cond_json",
            "count_env_brightness",
            "count_env_field_and_forward_brightness"      
        )
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))
        .orderBy("ingestDate_wo_ms", ascending=False)
    )
    return output_df
    '''

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter for one BHE event

# COMMAND ----------

# einzelnes Event (Fahrzeug und Zeitraum filtern)
#eventTime = 1729235856718
#start = eventTime - 30000
#end = eventTime + 30000

#filteredEvent = pivot_expanded_decoded_BHE_Data.filter(
#                    (col("timestamp_unix") >= start) 
#                    & (col("timestamp_unix") <= end)
#)

# filter nach usermessageID
userMessageIds = "675d2d19-26d9-4c16-ae0d-ddc01cdb640f"
filteredEvent = pivot_df_BHE_name.filter(
                    (col("userMessageId") == userMessageIds)
)

display(filteredEvent)




# COMMAND ----------

# MAGIC %md
# MAGIC # Plot BHE Values

# COMMAND ----------

def plotBHEValue(filteredEvent_df, signalname):
    signal_pd = (filteredEvent                        
                        .select('BHE_timestamps', signalname)
                        .dropna()
                        .toPandas()
    )  

    signal_pd['BHE_timestamps'] = pd.to_datetime(signal_pd['BHE_timestamps'], unit='ms'); 
    signal_pd = signal_pd.sort_values('BHE_timestamps')

    plt.figure()
    plt.plot(signal_pd['BHE_timestamps'], signal_pd[signalname])
    plt.xlabel('Timestamp')
    plt.ylabel('Value')
    plt.title(signalname)
    plt.xticks(rotation=45)  # Drehung der x-Achse-Beschriftungen, um Überlappungen zu vermeiden
    # plt.tight_layout()  # Layout anpassen, um Überlappungen zu vermeiden
    plt.show()  


# COMMAND ----------

plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSFrozenWindshield')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentLightAssist')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_SelfGlareIntensity')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentSHPS')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentOD')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentLDA')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentPED')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_Freesight')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentTSR')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_ImpairmentODACC')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSRain')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSBlur')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSLowSun')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSBlockage')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSPartialBlockage')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSFog')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_FSSplashes')
plotBHEValue(filteredEvent, 'sig_BHE_FC1_HeatingRequest')



# COMMAND ----------

# MAGIC %md
# MAGIC # Filter all userMessageIds with images

# COMMAND ----------

useMessageIdsImages = (pivot_df_BHE_name.filter(col("Event Image Collector - Response").isNotNull())
                       .select("userMessageId")
                       .rdd.flatMap(lambda x: x).collect()
)

print(useMessageIdsImages)


# COMMAND ----------

# MAGIC %md
# MAGIC # Get Eic images and extract image string

# COMMAND ----------

# userMessageIds of Images
userMessageIds = ['0ab76afe-a366-4834-81c1-db16fc4423fc', '63600338-9b2a-41d8-bfd1-a86aa799fc19', 'b5252e3e-ac75-4242-b8cb-c52d547fb371', 'f4d8947e-6ab2-4735-a57b-7932d20dfbbb']

EIC_Images = (pivot_df_BHE_name
            .filter(col("userMessageId").isin(userMessageIds))
            .select("userMessageId", "timestamp_unix", "Event Image Collector - Response")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("Event Image Collector - Response", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("Event Image Collector - Response").isNotNull())

display(EIC_Images)

eic_images_pd = EIC_Images.toPandas()


# COMMAND ----------

# MAGIC %md
# MAGIC # Plot EIC Images

# COMMAND ----------


for row in range(0, len(eic_images_pd)):
    single_image = eic_images_pd['image_string'].iloc[row] + '=='

    decoded_value = base64.b64decode(single_image)
    image = np.frombuffer(decoded_value, np.uint8)#[9:]
    encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
    prefix = "data:image/jpg;base64,"
    fig = go.Figure(go.Image(source=prefix+encoded_image))
    fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
    fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
    plotly_obj = fig.to_json()
    result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
    fig.show()