import base64
from enum import Enum
from VLAN_FAS import cso_vehicle_pb2 as cso_vehicle

class SignalType_BHE(Enum):
    sig_BHE_FC1_FSFrozenWindshield = 1;
    sig_BHE_FC1_ImpairmentLightAssist = 2;
    sig_BHE_FC1_SelfGlareIntensity = 3;
    sig_BHE_FC1_ImpairmentSHPS = 4;
    sig_BHE_FC1_ImpairmentOD = 5;
    sig_BHE_FC1_ImpairmentLDA = 6;
    sig_BHE_FC1_ImpairmentPED = 7;
    sig_BHE_FC1_Freesight = 8;
    sig_BHE_FC1_ImpairmentTSR = 9;
    sig_BHE_FC1_ImpairmentODACC = 10;
    sig_BHE_FC1_FSRain = 11;
    sig_BHE_FC1_FSBlur = 12;
    sig_BHE_FC1_FSLowSun = 13;
    sig_BHE_FC1_FSBlockage = 14;
    sig_BHE_FC1_FSPartialBlockage = 15;
    sig_BHE_FC1_FSFog = 16;
    sig_BHE_FC1_FSSplashes = 17;
    sig_BHE_FC1_HeatingRequest = 18;

class ProtobufSignal():
    def __init__(self, timestamp, value) -> None:
        self.timestamp = timestamp
        self.value = value

class ExtractedTimeseriesBHE():
    def __init__(self) -> None: 
        self.sig_BHE_FC1_FSFrozenWindshield = []
        self.sig_BHE_FC1_ImpairmentLightAssist = []
        self.sig_BHE_FC1_SelfGlareIntensity = []
        self.sig_BHE_FC1_ImpairmentSHPS = []
        self.sig_BHE_FC1_ImpairmentOD = []
        self.sig_BHE_FC1_ImpairmentLDA = []
        self.sig_BHE_FC1_ImpairmentPED = []
        self.sig_BHE_FC1_Freesight = []
        self.sig_BHE_FC1_ImpairmentTSR = []
        self.sig_BHE_FC1_ImpairmentODACC = []
        self.sig_BHE_FC1_FSRain = []
        self.sig_BHE_FC1_FSBlur = []
        self.sig_BHE_FC1_FSLowSun = []
        self.sig_BHE_FC1_FSBlockage = []
        self.sig_BHE_FC1_FSPartialBlockage = []
        self.sig_BHE_FC1_FSFog = []
        self.sig_BHE_FC1_FSSplashes = []
        self.sig_BHE_FC1_HeatingRequest = []

    def appendSignal(self, sigType: SignalType_BHE, signal: ProtobufSignal) -> None:
        sigNameStr = str(sigType.name)
        signalList = getattr(self, sigNameStr)
        signalList.append(signal)

    def getSignalList(self, sigType: SignalType_BHE) -> list[ProtobufSignal]:
        sigNameStr = str(sigType.name)
        return getattr(self, sigNameStr)
    
    def getSignalTimestamps(self, sigType: SignalType_BHE) -> list[int]:
        sigNameStr = str(sigType.name)
        signallist = getattr(self, sigNameStr)        
        timestamps = [signal.timestamp for signal in signallist]
        return timestamps
    
    def getSignalValues(self, sigType: SignalType_BHE) -> list[int]:
        sigNameStr = str(sigType.name)
        signallist = getattr(self, sigNameStr)        
        values = [signal.value for signal in signallist]
        return values


def extractTimeSeriesFromProtoBuf(ProtobufMessage: cso_vehicle.MFK5ClustersBHE) -> ExtractedTimeseriesBHE:
    extractedTimeSeries = ExtractedTimeseriesBHE()

    for bheMessage in ProtobufMessage.mfk5ClustersBHE: 
        # Check which signal types are included in message 
        for sigType in SignalType_BHE:
            sigNameStr = str(sigType.name)
            if bheMessage.HasField(sigNameStr):                
                #get timestamp / value pair from message
                mfk5_val = cso_vehicle.MFK5_Value_Timestamp() 
                mfk5_val = getattr(bheMessage, sigNameStr)                                
                timestamp = mfk5_val.timestamp
                value = mfk5_val.value
                # Append signal to the corresponding list
                signal = ProtobufSignal(timestamp,value)
                extractedTimeSeries.appendSignal(sigType, signal)
    return extractedTimeSeries

def printProtobufData(bheMessageClusters : cso_vehicle.MFK5ClustersBHE) -> None:
    #print full message
    print("Full Message: \n" + str(bheMessageClusters))

    #Number of elements
    print("Number of elements: " + str(len(bheMessageClusters.mfk5ClustersBHE)))

    #print each element
    for bheMessage in bheMessageClusters.mfk5ClustersBHE:  # Loops and print
        print(bheMessage)