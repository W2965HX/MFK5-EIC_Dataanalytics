# Databricks notebook source
# MAGIC %md
# MAGIC # Install protobuf + restart Python

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC #Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at
from pyspark.sql.types import StructType, StructField, StringType, ArrayType

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------

# Importieren der Funktion aus der Datei
import sys

# Fügen Sie den Pfad zum Repository-Root hinzu, falls noch nicht geschehen
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/EICModules"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
import importlib
#import cso_vehicle_pb2
#import extractBHEData
from decodeCSOData import decodeCSOData
from decodeCSOData import cso_vehicle_pb2
importlib.reload(cso_vehicle_pb2)
importlib.reload(decodeCSOData)
#from decodeCSOData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)

# ---------- end ----------

# COMMAND ----------

# Define User defined functions
decodeBHEData_udf = udf(decodeCSOData.convertBHEDataToDataFrame, ArrayType(StringType()))


# COMMAND ----------

# MAGIC %md
# MAGIC # Read data + Filter for last X days

# COMMAND ----------

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-1da2c68a-5bca-4e8c-9c17-b987e8d58d1b`")

df = (df_read
        # .filter(array_contains(df.useCaseIds,"UseCase-665e11af-e77a-4535-b1fa-43663c56622c"))        
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        #.select("userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", timestamp_unix", "name", "value")
        .cache()
)

df = df.filter(col("timestamp") > F.date_sub(F.current_date(), 10))  # filter for data of last 10 days

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Extend table with decoded BHE Data

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, PandasUDFType
from pyspark.sql.types import StructType, StructField, StringType, LongType, FloatType
import pandas as pd
import json

# Define User defined functions
decodeBHEData_udf = udf(decodeCSOData.convertBHEDataToDataFrame, ArrayType(StringType()))

@pandas_udf("struct<BHE_signal_name:array<string>, BHE_timestamp:array<long>, BHE_value:array<float>>", PandasUDFType.SCALAR)
def decode_udf(encoded_series: pd.Series) -> pd.DataFrame:
    def decode_and_flatten(encoded_value):
        try:
            decoded_df = decodeCSOData.convertBHEDataToDataFrame(encoded_value)        
            return pd.Series({
                'BHE_signal_name': decoded_df['Signalname'].tolist(),
                'BHE_timestamp': decoded_df['Timestamp'].tolist(),
                'BHE_value': decoded_df['Value'].tolist()
            })  
        except Exception as e:
            return pd.Series({
                'BHE_signal_name': [],
                'BHE_timestamp': [],
                'BHE_value': []
            })    
    return encoded_series.apply(decode_and_flatten)


decoded_BHE_Data = (df                                       
                    .withColumn("mfk5bhedatadecoded", when(col("name") != "mfk5bhedata", lit(None)).otherwise(decode_udf(df["value"])))
                    .withColumn("BHE_signal_names", col("mfk5bhedatadecoded.BHE_signal_name"))
                    .withColumn("BHE_timestamps", col("mfk5bhedatadecoded.BHE_timestamp"))
                    .withColumn("BHE_values", col("mfk5bhedatadecoded.BHE_value"))
)
#decoded_BHE_Data = decoded_BHE_Data.select("mfk5bhedatadecoded.BHE_signal_name")
display(decoded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Explode BHE values - Result is dataframe with only BHE data

# COMMAND ----------

exploded_BHE_Data = decoded_BHE_Data.select(
                        col("orderId"),
                        col("mdc_id"),
                        col("g_id"),
                        col("name"),
                        col("value"),
                        col("unit"),
                        col("timestamp"),
                        col("ingest_timestamp"),
                        col("orderVersion"),
                        col("correlationId"),
                        col("containerId"),
                        col("containerMsgCount"),
                        col("containerMsgId"),
                        col("schemaId"),
                        col("vehicleId"),
                        col("useCaseIds"),
                        col("userMessageId"),
                        col("time"),
                        col("userId"),
                        col("payloadUrl"),
                        col("image_processing_batch_id"),
                        col("consumption_timestamp"),
                        col("ingest_date"),
                        #col("date"),
                        col("timestamp_unix"),
                        col("ingestDate_wo_ms"),
                        col("mfk5bhedatadecoded"),
                        posexplode(col("BHE_signal_names")).alias("pos", "BHE_signal_names"),
                        col("BHE_values")[col("pos")].alias("BHE_values"),
                        col("BHE_timestamps")[col("pos")].alias("BHE_timestamps"),
                        ).drop("pos")

display(exploded_BHE_Data)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter original dataframe for data without BHE data

# COMMAND ----------


# Cast Columntypes from Array<*> to *, to be able to union dataframe afterwards
nonBHE_df = (decoded_BHE_Data.filter(decoded_BHE_Data.name != "mfk5bhedata")
                .withColumn("BHE_signal_names", decoded_BHE_Data["BHE_signal_names"].cast("string"))   
                .withColumn("BHE_values",     element_at(col("BHE_values"), 1).cast("float")) 
                .withColumn("BHE_timestamps", element_at(col("BHE_timestamps"), 1).cast("bigint"))
)
display(nonBHE_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Union exploded BHE Data with other data

# COMMAND ----------

# Make sure that column order and colum names match 
exploded_BHE_Data = exploded_BHE_Data.select(nonBHE_df.columns)

union_df = exploded_BHE_Data.union(nonBHE_df)
display(union_df)

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot data

# COMMAND ----------

pivot_df_name = (union_df
            .groupBy("timestamp_unix", "name", "value","userMessageId", "BHE_signal_names", "BHE_timestamps", "BHE_values")
            .pivot("name")
            .agg(F.first("value"))
            .drop(col("name"), col("value"))            
        )
display(pivot_df_name)

pivot_df_BHE_name = (pivot_df_name
            .groupBy("timestamp_unix", "userMessageId", "EIC_ID", "Event Image Collector - Response", "Outdoor temperature", "TimeDiffClamp15VelocityGreater5", "longitude", "latitude", "BHE_timestamps", "BHE_signal_names", "BHE_values")
            .pivot("BHE_signal_names")
            .agg(F.first("BHE_values"))
            .drop(col("BHE_signal_names"), col("BHE_values"), col("null"), col("mfk5bhedata"))
            .sort(col("timestamp_unix").asc())
)
display(pivot_df_BHE_name)

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter for one BHE event

# COMMAND ----------

# einzelnes Event (Fahrzeug und Zeitraum filtern)
#eventTime = 1729235856718
#start = eventTime - 30000
#end = eventTime + 30000

#filteredEvent = pivot_expanded_decoded_BHE_Data.filter(
#                    (col("timestamp_unix") >= start) 
#                    & (col("timestamp_unix") <= end)
#)

# filter nach usermessageID
userMessageIds = "43c2158e-8ad8-41c0-ad37-2303e361be13"
filteredEvent = pivot_df_BHE_name.filter(
                    (col("userMessageId") == userMessageIds)
)

display(filteredEvent)




# COMMAND ----------

# MAGIC %md
# MAGIC # Plot BHE Values

# COMMAND ----------

pivot_df_BHE_name_pd = (filteredEvent                        
                        .select('BHE_timestamps', 'sig_BHE_FC1_Freesight')
                        .dropna()
                        .toPandas()
)
pivot_df_BHE_name_pd['BHE_timestamps'] = pd.to_datetime(pivot_df_BHE_name_pd['BHE_timestamps'], unit='ms'); 
pivot_df_BHE_name_pd = pivot_df_BHE_name_pd.sort_values('BHE_timestamps')

display(pivot_df_BHE_name_pd)

plt.figure()
plt.plot(pivot_df_BHE_name_pd['BHE_timestamps'], pivot_df_BHE_name_pd['sig_BHE_FC1_Freesight'])
plt.xlabel('Timestamp')
plt.ylabel('Value')
plt.xticks(rotation=45)  # Drehung der x-Achse-Beschriftungen, um Überlappungen zu vermeiden
# plt.tight_layout()  # Layout anpassen, um Überlappungen zu vermeiden
plt.show()  

# COMMAND ----------

# MAGIC %md
# MAGIC # Filter all userMessageIds with images

# COMMAND ----------

useMessageIdsImages = (pivot_df_BHE_name.filter(col("Event Image Collector - Response").isNotNull())
                       .select("userMessageId")
                       .rdd.flatMap(lambda x: x).collect()
)

print(useMessageIdsImages)


# COMMAND ----------

# MAGIC %md
# MAGIC # Get Eic images and extract image string

# COMMAND ----------

# userMessageIds of Images
userMessageIds = ['e528c152-e86d-4597-ac30-a53fc90e43fb', '2ebcfd8a-0767-4c7f-932e-d537b21da254', '39ef07ac-89ee-45d0-8d0e-4cc02a98a141', '3df45fbd-31e6-427a-94b3-6222a067d5b9', 'dcb4ce3f-07bb-4ad6-a1ce-a467196781aa', 'ea579afe-0482-470e-8c54-b799b3f244f3', 'c684e18a-9620-4386-b590-93159767013b', '1411b46b-8165-4de5-ac19-cc51065668f8', '0706fc85-015d-4d78-b505-54735c8a9ac8', '0e7001ba-e6c0-4434-8222-f294f60f9efb', '444b328e-955c-4a4f-afda-7829e4226b65', '284248ce-6226-4cd9-81a3-b833246e4d32', 'a1822951-b958-4984-a69f-44dea18abdde', '402ba1c4-10e9-46c4-b34f-54750882ee1a', '099f23d0-52e6-4454-b539-394d2e136d49', '3a2e1d75-5160-4591-b462-e73901d188a7', 'b42c69ab-6f49-4f87-a0e5-c871c9be2ec4', '8802f479-0792-4455-96ee-f40662bd2dda', '61eee36f-2202-4a38-a02d-c8573390fbca', 'a7e3cc8d-2372-4dff-88ba-2fc78fd864a7', 'e8846111-ed0a-412b-b3c7-6cc2e31b9d6e']

EIC_Images = (pivot_df_BHE_name
            .filter(col("userMessageId").isin(userMessageIds))
            .select("userMessageId", "timestamp_unix", "Event Image Collector - Response")
            # get image string right of "image:"
            .withColumn("image_string", F.substring_index("Event Image Collector - Response", "image\":", -1))
            # get image string left of "," --> only base64 image string remains
            .withColumn("image_string", F.substring_index("image_string", ",\"", 1))            
            #.collect()[0][0]
)
# Todo: Remove, there should be no empty rows
#EIC_Images = EIC_Images.filter(col("Event Image Collector - Response").isNotNull())

display(EIC_Images)

eic_images_pd = EIC_Images.toPandas()


# COMMAND ----------

# MAGIC %md
# MAGIC # Plot EIC Images

# COMMAND ----------



for row in range(0, len(eic_images_pd)):
    single_image = eic_images_pd['image_string'].iloc[row] + '=='

    decoded_value = base64.b64decode(single_image)
    image = np.frombuffer(decoded_value, np.uint8)#[9:]
    encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
    prefix = "data:image/jpg;base64,"
    fig = go.Figure(go.Image(source=prefix+encoded_image))
    fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
    fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
    plotly_obj = fig.to_json()
    result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
    fig.show()