# Databricks notebook source
# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

from pyspark.sql.functions import col, radians, year, when, lit
from pyspark.sql import functions as F
from pyspark.sql.window import Window

import numpy as np
import pandas as pd

import base64

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter use case data

# COMMAND ----------

df = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`useCase-1da2c68a-5bca-4e8c-9c17-b987e8d58d1b`")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df = (df
        #.filter(F.array_contains(df.useCaseIds,"UseCase-665e11af-e77a-4535-b1fa-43663c56622c")) # WBA_ME_Ausloese_V0_1
        #.filter(F.array_contains(df.useCaseIds,"UseCase-665e11af-e77a-4535-b1fa-43663c56622c"))
        .filter(F.array_contains(df.useCaseIds,"UseCase-1da2c68a-5bca-4e8c-9c17-b987e8d58d1b")) # EIC_MFK5_Perception_BHE_Blindness_OnStartup
        #.filter(F.array_contains(df.useCaseIds,"UseCase-4d807fe5-93eb-4c53-a0f8-e446f151ba48")) # WBA_Indicator_Perception_ADAS WB
        #.filter(F.array_contains(df.useCaseIds,"UseCase-8c3edad6-83a0-448a-bb4f-3bf7b203c42e")) # EIC_MFK5_Perception_BHE_Blindness_Test
        #.filter(F.array_contains(df.useCaseIds,"UseCase-01554d10-2ce7-47b8-a97b-15e062f4028a"))  # Regular Ping

        # .withColumn("date", F.from_unixtime((col("timestamp")/1000)))
        .withColumn("date", col("timestamp"))
        # .withColumn("ingestDate", F.from_unixtime((col("ingest_timestamp")/1000)))
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        # .select("userMessageId", "ingest_timestamp", "timestamp", "timestamp_unix", "name", "value", "unit", "vehicleId", "containerMsgCount")
        .orderBy("timestamp", ascending=False)
        .cache()
)

# df.printSchema()
# display(df.sort(col("ingestDate").desc(), col("timestamp").desc()))
display(df)

# COMMAND ----------

df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Store BHE Data in gold layer

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"  
my_project_name = "eicmfk"                        
my_gold_layer_table_name = "BHEOnStartup"

df.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")