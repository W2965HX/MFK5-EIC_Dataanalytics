from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType
from pyspark.sql.functions import col, when, lit, udf

import sys

# Set repo root path
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

import EICModules.decoding.decodingFunctions as decodingFunctions


'''
def mapConfBitStringToNumber(confbitString):
    mapping = {
        "ConfirmationBit.notSet" : 0,
        "ConfirmationBit.set" : 1,
        "ConfirmationBit.init" : 2,
        "ConfirmationBit.error" : 3                        
    }
    return mapping.get(confbitString, -1)


# Confbit mapping
mapConfBitStringToNumber_udf = udf(mapConfBitStringToNumber, IntegerType())
'''

def pivot_eic_od_data(input_df, spark):
        """
        Pivoting and cleaning EIC_Od data.
        input_df: standard gdc dataframe (each row is one data point)
        output_df: pivoted dataframe  
        """
        # Pivot table
        output_df = (input_df
            .groupBy("containerId", "userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", 
                    "timestamp_unix", "timestamp", "timestamp_date")
            .pivot("name")
            .agg(F.first("value"))
        )

        # If no EIC_ID in data, create empty column -> needed for further processing
        if "EIC_ID" in output_df.columns:
            output_df = output_df.withColumn("EIC_ID", col("EIC_ID").cast("int"))
        else:
            output_df = output_df.withColumn("EIC_ID", lit(None))
            
        return output_df

def convert_and_rename_od_data(input_df, spark):
        """
        Convert and rename Od data.
        input_df: pivoted dataframe
        output_df: pivoted dataframe with converted signals
        """
        output_df = (input_df
                     
            # convert data types 
            .withColumn("DW_Kilometerstand", col("DW_Kilometerstand").cast("int"))
            .withColumn("EIC_ID", col("EIC_ID").cast("int"))
            .withColumn("timestamp_unix", col("timestamp_unix").cast("double"))        
            .withColumn("VDSO_Vx3dGNSS", col("VDSO_Vx3dGNSS").cast("double"))    
            .withColumn("VDSO_ALgtOfsCmp", col("VDSO_ALgtOfsCmp").cast("double"))    
            .withColumn("VDSO_ALatOfsCmp", col("VDSO_ALatOfsCmp").cast("double"))    
            .withColumn("VDSO_AgReWhlStgAxl", col("VDSO_AgReWhlStgAxl").cast("double"))    
            .withColumn("VDSO_AgvYawRateOfsCmp", col("VDSO_AgvYawRateOfsCmp").cast("double"))    
            .withColumn("VMM_BrkPed_ItDmdNorm", col("VMM_BrkPed_ItDmdNorm").cast("double"))    
            .withColumn("Wischer1_Wischgeschwindigkeit", col("Wischer1_Wischgeschwindigkeit").cast("double"))   
            .withColumn("LWI_AgStgWhl", col("LWI_AgStgWhl").cast("double"))
            .withColumn("API_PrctDrvPed", col("API_PrctDrvPed").cast("double")) 
            #.withColumn("latitude", col("latitude").cast("float"))
            #.withColumn("longitude", col("longitude").cast("float"))
            
            # convert outdoor temp_kelvin to celsius
            .withColumn("Outdoor_temp_C", (col("Outdoor temperature").cast("double") - 273.15))   

            # rename cols 
            .withColumnRenamed("Event Image Collector - Response", "EIC_Response")
            .withColumnRenamed("environmental brightness", "env_brightness")
            .withColumnRenamed("environmental field and forward brightness", "env_field_and_forward_brightness")
            .withColumnRenamed("high beam light state", "high_beam_state")
            .withColumnRenamed("low beam light state", "low_beam_state")
            .withColumnRenamed("outside dewpoint", "outside_dewpoint")
            .withColumnRenamed("Weather condition", "Weather_condition")
            
            # Todo: change
            .withColumnRenamed("ObjectDetection objects Event", "Od_event")
        )
        return output_df
    
def decode_eic_od_data(input_df, spark):
        """
        Decode EIC_Od data.
        input_df: pivoted dataframe
        output_df: pivoted dataframe with decoded signals 
        """
        # define time signal
        time_signal = "timestamp_unix"
        
        # define windows
        window_container_relTime  = Window.partitionBy("containerId")            
        # for getting km driven
        window_vehicle_km = Window.partitionBy("vehicleId").orderBy("timestamp_unix").rowsBetween(Window.unboundedPreceding, Window.currentRow-1)
        # for getting last SW-Version
        window_vehicle_SW = Window.partitionBy("vehicleId").orderBy("timestamp_unix").rowsBetween(Window.unboundedPreceding, Window.currentRow)

        
        output_df = (input_df
            # add unix time at activation
            .withColumn("unix_time_at_activation", when((col("EIC_ID").isNotNull()), col(time_signal)))
            
            # add relative timestamp
            .withColumn("event_time_s", (col("timestamp_unix") - F.min(col("timestamp_unix")).over(window_container_relTime))/1000)

            # calc gps position at activation time (first timestamp)
            .withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("event_time_s")))
            .withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("event_time_s")))
            .withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_container_relTime), col("latitude")))
            .withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_container_relTime), col("longitude")))

            # add driven kilometer
            .withColumn("driven_km", (col("DW_Kilometerstand") - F.last(col("DW_Kilometerstand"), ignorenulls=True).over(window_vehicle_km)))

            # decode CSO Data to json 
            .withColumn("outside_temp_hum_json", when((col("outside humidity and temperature").isNotNull()), decodingFunctions.decodeHumidity_udf(col("outside humidity and temperature"))).otherwise(lit(None)))
            .withColumn("weather_cond_json", when((col("Weather_condition").isNotNull()), decodingFunctions.decodeWeather_udf(col("Weather_condition"))).otherwise(lit(None)))
            # Todo: decode dewpoint, brightness, brightness forward
            #.withColumn("outside dewpoint_json", when((col("outside dewpoint").isNotNull()), decodeWeather_udf(col("outside dewpoint"))).otherwise(lit(None)))
            
            # extract json fields
            .withColumn("outside_temp", when((col("outside_temp_hum_json").isNotNull()), F.get_json_object(col("outside_temp_hum_json"), '$.temperature')).otherwise(lit(None)))
            .withColumn("outside_hum", when((col("outside_temp_hum_json").isNotNull()), F.get_json_object(col("outside_temp_hum_json"), '$.humidity')).otherwise(lit(None)))            
            .withColumn("outside_hum_temp_status", when((col("outside_temp_hum_json").isNotNull()), F.get_json_object(col("outside_temp_hum_json"), '$.status')).otherwise(lit(None)))
            .withColumn("weather_cond_clearWeather", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.clearWeather')).otherwise(lit(None)))
            .withColumn("weather_cond_fog", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.fog')).otherwise(lit(None)))
            .withColumn("weather_cond_fogHeavy", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.fogHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_rain", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.rain')).otherwise(lit(None)))
            .withColumn("weather_cond_rainHeavy", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.rainHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_snow", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.snow')).otherwise(lit(None)))
            .withColumn("weather_cond_snowHeavy", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.snowHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_status", when((col("weather_cond_json").isNotNull()), F.get_json_object(col("weather_cond_json"), '$.status')).otherwise(lit(None)))
            
            # decode SomeIP Pedestrian Detection
            #.withColumn("ConfBitL1", when(col("Od_event").isNotNull(), getConfBitL1_udf(col("Od_event"))).otherwise(lit(None)))
            #.withColumn("ConfBitL2", when(col("Ped_event").isNotNull(), getConfBitL2_udf(col("Ped_event"))).otherwise(lit(None)))
            #.withColumn("ConfBitL3", when(col("Ped_event").isNotNull(), getConfBitL3_udf(col("Ped_event"))).otherwise(lit(None)))
            
            # decode SomeIP Object Detection
            .withColumn("confBitPrecedingL1", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL1_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitPrecedingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitPrecedingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitOncomingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitOncomingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitOncomingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitOncomingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitCrossingL1", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL1_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitCrossingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitCrossingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitEgoTurningL3", when(col("Od_event").isNotNull(), decodingFunctions.confBitEgoTurningL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("MFK5_SW_Version_decoded", 
                        when((col("MFK5_SW_Version")).isNotNull(), decodingFunctions.decodeBase64_udf(col("MFK5_SW_Version")))
                        .otherwise(lit(None)))
            .withColumn("MFK5_SW_Version_extract",
                        when((col("MFK5_SW_Version_decoded")).isNotNull(), decodingFunctions.extractMFK5Version_udf(col("MFK5_SW_Version_decoded")))
                        .otherwise(lit(None)))
            
            # add last reported MFK5-SW
            .withColumn("Last_MFK5_SW", (F.last(col("MFK5_SW_Version_extract"), ignorenulls=True).over(window_vehicle_SW)))
                        
            # order results
            .orderBy("timestamp_unix", ascending=True)

            # drop unneeded columns
            .drop("", "value", "outside humidity and temperature", "Outdoor temperature", "MFK5_SW_Version_decoded") # "Weather condition"
        )
        return output_df
