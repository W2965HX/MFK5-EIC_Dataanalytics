# Databricks notebook source
# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at, date_sub, current_date, unix_millis, date_format, min as min_, max as max_, get_json_object, last

from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType

from EICModules.decoding.decodeHighlevelData import decodeHumidityAndTemperature, decodeWeatherCondition


import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# Import self written package
# ---------- start ----------
#import sys

# Set repo root path
#repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
#if repo_root_path not in sys.path:
#    sys.path.append(repo_root_path)

# reload own modules to get the latest version (otherwise you have to restart the kernel)
#import importlib
#from EICModules.decodeSomeIP.linux import someIPpythonlib
#from EICModules.EICPED import EIC_PED_module
#from EICModules.plots import EIC_PED_Plots
#from EICModules.decodeHighlevelData import decodeBHE
#from EICModules.decodeDiagnostics import decodeSWVersions
#importlib.reload(decodeSWVersions)
#importlib.reload(decodeBHE)
#importlib.reload(someIPpythonlib)
#importlib.reload(EIC_PED_module)
#importlib.reload(EIC_PED_Plots)

#from extractBHEData import (convertBHEDataToDataFrame, convertBHEDataListToDataFrame)
# ---------- end ----------

# COMMAND ----------

# MAGIC %md
# MAGIC # Read decoded data from gold layer

# COMMAND ----------


my_catalog_name = "ude_int_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "ODEventsDecodedCl6"

df = spark.read.table(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}").cache()

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

min_max_df = df.agg(min_("timestamp").alias("min_timestamp"), max_("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC ## Remove separate kilometer + MFK5-SW reports (otherwise they are listed as referenced EIC Images)

# COMMAND ----------

df_wo_km_report = (df
                    .filter(~((df.containerMsgCount == 1) & (df.DW_Kilometerstand.isNotNull()) ))
                    .filter(~((df.containerMsgCount == 1) & (df.MFK5_SW_Version.isNotNull()) ))
)

display(df_wo_km_report)
df_wo_km_report.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Define functions for od event summary

# COMMAND ----------

def eic_od_event_summary(input_df):
    
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")                        
                        .orderBy("unix_time_at_activation")
                        .rangeBetween(-10000, 10000)
    )
    time_signal = "timestamp_unix"

    output_df = (
        input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Od to EIC_ID
        #.withColumn("time_after_activation", when(col("EIC_ID").isNotNull(), col(time_signal)))
        #.withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)


        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),
            F.min("unix_time_at_activation").alias("unix_time_at_activation"),
            F.min("VDSO_ALgtOfsCmp").alias("min_VDSO_ALgtOfsCmp"),
            F.first(time_signal).alias("first_unix_timestamp"),
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_Response").alias("count_EIC_Response"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Od_event").alias("count_Od_event"),
            F.count("RG_RA_CountryCode").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            F.count("weather_cond_json").alias("count_weather_cond_json"),
            F.count("env_brightness").alias("count_env_brightness"),
            F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            F.count("low_beam_state").alias("count_low_beam_state"),
            F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).alias("act_lat"),
            F.first("act_long", ignorenulls=True).alias("act_long"),

            F.first("MFK5_SW_Version_extract", ignorenulls=True).alias("MFK5_SW_Version_extract"),
            F.first("Last_MFK5_SW", ignorenulls=True).alias("Last_MFK5_SW"),


            F.collect_set("WBA_Warnung").alias("WBA_Warnung_Values"),

            F.collect_set("confBitPrecedingL1").alias("confBitPrecedingL1_Values"),
            F.collect_set("confBitPrecedingL2").alias("confBitPrecedingL2_Values"),
            F.collect_set("confBitPrecedingL3").alias("confBitPrecedingL3_Values"),

            F.collect_set("confBitOncomingL2").alias("confBitOncomingL2_Values"),
            F.collect_set("confBitOncomingL3").alias("confBitOncomingL3_Values"),

            F.collect_set("confBitCrossingL1").alias("confBitCrossingL1_Values"),
            F.collect_set("confBitCrossingL2").alias("confBitCrossingL2_Values"),
            F.collect_set("confBitCrossingL3").alias("confBitCrossingL3_Values"),
            F.collect_set("confBitEgoTurningL3").alias("confBitEgoTurningL3_Values")
        )
        # set activation time of eic images to their unix timestamp
        .withColumn("unix_time_at_activation",
                    when(col("unix_time_at_activation").isNotNull(), col("unix_time_at_activation"))
                    .otherwise(col("first_unix_timestamp")))
        .select(
            "containerId",
            "userMessageId",
            "vehicleId",
            "containerMsgCount",
            "ingestDate_wo_ms",
            "unix_time_at_activation",
            "first_unix_timestamp",
            "min_VDSO_ALgtOfsCmp",
            "count_DW_Kilometerstand",
            "count_EIC_ID",
            "count_EIC_Response",
            "count_LWI_AgStgWhl",
            "count_Od_event",
            "count_RG_RA_CountryCode",
            "count_Streetclass",
            "count_VDSO_AgvYawRateOfsCmp",
            "count_VDSO_Vx3dGNSS",
            "count_high_beam_state",
            "count_latitude",
            "count_longitude",  
            "act_lat",
            "act_long",
            "MFK5_SW_Version_extract",
            "Last_MFK5_SW",
            "WBA_Warnung_Values",
            "confBitPrecedingL1_Values",
            "confBitPrecedingL2_Values",
            "confBitPrecedingL3_Values",                        
            "confBitOncomingL2_Values",
            "confBitOncomingL3_Values", 
            "confBitCrossingL1_Values",
            "confBitCrossingL2_Values",
            "confBitCrossingL3_Values", 
            "confBitEgoTurningL3_Values", 
            "count_Outdoor_temp_C",
            "count_outside_temp_hum_json",
            "count_outside_dewpoint",             
            "count_weather_cond_json",
            "count_env_brightness",
            "count_env_field_and_forward_brightness"      
        )
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))
        .orderBy("ingestDate_wo_ms", ascending=False)
    )
    return output_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Event summary

# COMMAND ----------

df_data_summary = eic_od_event_summary(df_wo_km_report)

df_data_summary_wo_eicImages = df_data_summary.filter(~(col("count_EIC_Response") == 1))

display(df_data_summary_wo_eicImages)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store event summary

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "ODEventSummaryCl6"

df_data_summary_wo_eicImages.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "ODEventSummaryCl6"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''
