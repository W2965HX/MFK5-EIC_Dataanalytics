# Databricks notebook source
# MAGIC %md
# MAGIC # Install packages

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col
import importlib

import pivotAndDecodeOD
importlib.reload(pivotAndDecodeOD)

# COMMAND ----------

# MAGIC %md
# MAGIC # Read raw data from silver layer

# COMMAND ----------


spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_silver.`usecase-25277b96-c15e-43f4-987d-23883270490f`")

# Filter for last X days
lastDays = 90

df_silver = (df_read        
        .filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        #.filter(col("name")!= "PedestrianDetection pedestrians Event")
        #filter(col("name") == "Event Image Collector - Response")
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("timestamp_date", F.date_format(col("timestamp"),"yyyy-MM-dd"))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        .cache()
)

min_max_df = df_silver.agg(F.min("timestamp").alias("min_timestamp"), F.max("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df_silver)
df_silver.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Clean data

# COMMAND ----------

df_silver_cleaned = (df_silver
        .filter(col("value") != "Init")
        .filter(col("value") != "Fehler")
)
display(df_silver_cleaned)
'''
__dw_df_0 = df_silver_cleaned.filter("(name in ('DW_Kilometerstand'))")

display(__dw_df_0)
'''

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot and decode data

# COMMAND ----------

df_pivot = pivotAndDecodeOD.pivot_eic_od_data(df_silver_cleaned, spark).cache()
#display(df_pivot)
#df_pivot.count()

df_pivot_renamed = pivotAndDecodeOD.convert_and_rename_od_data(df_pivot, spark).cache()
display(df_pivot_renamed)
#df_pivot_renamed.count()

df_pivot_renamed_decoded = pivotAndDecodeOD.decode_eic_od_data(df_pivot_renamed, spark).cache()
display(df_pivot_renamed_decoded)
df_pivot_renamed_decoded.count()



# COMMAND ----------

# MAGIC %md
# MAGIC # Test one event 

# COMMAND ----------

test = df_pivot_renamed_decoded.filter(col("containerId")=="dfdfdc39-6825-427e-bd86-dfda59c9c27e")
display(test)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store decoded data

# COMMAND ----------

my_catalog_name = "ude_int_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "ODEventsDecodedCl6"

df_pivot_renamed_decoded.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
my_catalog_name = "ude_int_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "ODEventsDecodedCl6"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''

