# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %md
# MAGIC # Install packages

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, when, lit
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType
from pyspark.sql.window import Window
import importlib
import sys

# Set repo root path
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

import EICModules.decoding.decodingFunctions as decodingFunctions


# COMMAND ----------

# MAGIC %md
# MAGIC # Read preprocessed data from gold layer (Execute transform_common_od_ped_data first)

# COMMAND ----------


spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df_read = spark.read.table("ude_int_euno_fhum_adas_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_transformed_Appr").cache()


df_od_preprocced = (df_read        
        .withColumnRenamed("ObjectDetection_objects_Event", "Od_event")
        .cache()
)

display(df_od_preprocced)
df_od_preprocced.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Decode additional od data

# COMMAND ----------

def decode_od_data(input_df, spark):
        """
        Decode EIC_od data.
        input_df: pivoted dataframe
        output_df: pivoted dataframe with decoded signals 
        """
        # define windows
        window_spec = Window.partitionBy("containerId").orderBy("timestamp").rowsBetween(Window.unboundedPreceding, -1)
        
        window_container_relTime  = Window.partitionBy("containerId")            
        # for getting km driven
        window_vehicle_km = Window.partitionBy("vehicleId").orderBy("timestamp_unix").rowsBetween(Window.unboundedPreceding, Window.currentRow-1)
        # for getting last SW-Version
        window_vehicle_SW = Window.partitionBy("vehicleId").orderBy("timestamp_unix").rowsBetween(Window.unboundedPreceding, Window.currentRow)

        output_df = (input_df
                     
            # add driven kilometer
            .withColumn("driven_km", (col("DW_Kilometerstand") - F.last(col("DW_Kilometerstand"), ignorenulls=True).over(window_vehicle_km)))
            
            # decode SomeIP Object Detection
            .withColumn("confBitPrecedingL1", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL1_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitPrecedingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitPrecedingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitPrecedingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitOncomingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitOncomingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitOncomingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitOncomingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitCrossingL1", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL1_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitCrossingL2", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL2_udf(col("Od_event"))).otherwise(lit(None)))
            .withColumn("confBitCrossingL3", when(col("Od_event").isNotNull(), decodingFunctions.getConfBitCrossingL3_udf(col("Od_event"))).otherwise(lit(None)))

            .withColumn("confBitEgoTurningL3", when(col("Od_event").isNotNull(), decodingFunctions.confBitEgoTurningL3_udf(col("Od_event"))).otherwise(lit(None)))

            # extract timestamps, where L1/L2/L3 bits are set to true
            .withColumn("timestamp_unix_confBitsL1L2L3set", 
                        when((col("confBitPrecedingL1") == "Od_ConfirmationBit.set")
                             |(col("confBitPrecedingL2") == "Od_ConfirmationBit.set")
                             |(col("confBitPrecedingL3") == "Od_ConfirmationBit.set")
                             |(col("confBitOncomingL2") == "Od_ConfirmationBit.set")
                             |(col("confBitOncomingL3") == "Od_ConfirmationBit.set")
                             |(col("confBitCrossingL1") == "Od_ConfirmationBit.set")
                             |(col("confBitCrossingL2") == "Od_ConfirmationBit.set")
                             |(col("confBitCrossingL3") == "Od_ConfirmationBit.set")
                             |(col("confBitEgoTurningL3") == "Od_ConfirmationBit.set"), col("timestamp_unix"))
                        .otherwise(lit(None)))
            
            # add relative timestamp (0 = start of confBit = set)
            .withColumn("event_time_s", (col("timestamp_unix") - F.min(col("timestamp_unix_confBitsL1L2L3set")).over(window_container_relTime))/1000)
            
            # calc gps position at activation time 
            .withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("event_time_s")))
            .withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("event_time_s")))
            .withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_container_relTime), col("latitude")))
            .withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_container_relTime), col("longitude")))
            
            .withColumn("MFK5_SW_Version_decoded", 
                        when((col("MFK5_SW_Version")).isNotNull(), decodingFunctions.decodeBase64_udf(col("MFK5_SW_Version")))
                        .otherwise(lit(None)))
            .withColumn("MFK5_SW_Version_extract",
                        when((col("MFK5_SW_Version_decoded")).isNotNull(), decodingFunctions.extractMFK5Version_udf(col("MFK5_SW_Version_decoded")))
                        .otherwise(lit(None)))
            
            # add last reported MFK5-SW
            .withColumn("Last_MFK5_SW", (F.last(col("MFK5_SW_Version_extract"), ignorenulls=True).over(window_vehicle_SW)))


            #calculate SomeIP timestamp delta
            .withColumn("last_valid_SomeIP_timestamp_unix", 
                                when(col("Od_event").isNotNull(),
                                F.last(when(col("Od_event").isNotNull(), col("timestamp_unix")), ignorenulls=True).over(window_spec)
                                ))
            .withColumn("delta_time_someIP", col("timestamp_unix") - col("last_valid_SomeIP_timestamp_unix"))
                                   
            # order results
            .orderBy("timestamp_unix", ascending=True)

            # drop unneeded columns
            .drop("", "value", "outside humidity and temperature", "Outdoor temperature", "TTC_String_Array") # "Weather condition"
        )
        return output_df


df_od_decoded = decode_od_data(df_od_preprocced, spark).cache()
display(df_od_decoded)
df_od_decoded.count()



# COMMAND ----------

# MAGIC %md
# MAGIC # Test one event 

# COMMAND ----------

test = df_od_decoded.filter(col("containerId")=="dd15c2a1-d9a7-4ddf-8a47-d341f2dded08")
display(test)

# COMMAND ----------

print(df_od_decoded.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store decoded data

# COMMAND ----------

output_data = "ude_int_euno_fhum_adas_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_transformed_and_decoded_Appr"

df_od_decoded.write.format("delta").mode("overwrite").saveAsTable(f"{output_data}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
output_data = "ude_int_euno_fhum_adas_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_transformed_and_decoded_Appr"

spark.sql(
    f"DROP TABLE {output_data}"
)
'''

