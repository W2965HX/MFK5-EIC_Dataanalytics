# Databricks notebook source
# MAGIC %pip list

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2

# COMMAND ----------

# MAGIC %restart_python

# COMMAND ----------

from VLAN_FAS import cso_vehicle_pb2
from VLAN_FAS import extractBHEData
import base64

# COMMAND ----------

BHEdata = r"Cm8SCQgCEL/1w9vnMSIJCAIQv/XD2+cxKgkIAhC/9cPb5zEyCQgCEL/1w9vnMToJCAIQv/XD2+cxQgkIAhC/9cPb5zFKCQgCEL/1w9vnMVIJCAIQwPXD2+cxagkIARDA9cPb5zGSAQkIAhDA9cPb5zEKZBIJCAIQ1ffD2+cxIgkIAhDV98Pb5zEqCQgCENX3w9vnMTIJCAIQ1ffD2+cxOgkIAhDV98Pb5zFCCQgCENX3w9vnMUoJCAIQ1ffD2+cxUgkIAhDV98Pb5zGSAQkIAhDV98Pb5zE="

BHEdataBin = base64.b64decode(BHEdata) 

bheMessageClusters = cso_vehicle_pb2.MFK5ClustersBHE()  
bheMessageClusters.ParseFromString(BHEdataBin)

extractBHEData.printProtobufData(bheMessageClusters)


# COMMAND ----------

extractedTimeSeries = extractBHEData.extractTimeSeriesFromProtoBuf(bheMessageClusters)

timeSeriesFreesight = extractedTimeSeries.getSignalList(extractBHEData.SignalType_BHE.sig_BHE_FC1_Freesight)

for elem in timeSeriesFreesight:
    print("Timestamp: "+ str(elem.timestamp) + " Value: " + str(elem.value))

# COMMAND ----------

from pyspark.sql.functions import col, radians, year, when, substring, lit, unhex, array_contains
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import unbase64
from pyspark.sql.types import StringType,BooleanType,DateType,FloatType,IntegerType,BinaryType

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

# COMMAND ----------

# MAGIC %md
# MAGIC # Append BHE data colum to existing data

# COMMAND ----------

# Select UseCase
selectedUseCaseID = "UseCase-4d807fe5-93eb-4c53-a0f8-e446f151ba48" # Regular Image Upload Reliable - ADAS WB
#selectedUseCaseID = "UseCase-665e11af-e77a-4535-b1fa-43663c56622c" # WBA_ME_Ausloese_V0_1

df = spark.read.format("delta").table("default.deltalakesilver").limit(5)
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")



df = (df
        #.filter(F.array_contains(df.useCaseIds, selectedUseCaseID))
        .withColumn("BHE_FC1_Freesight_timestamps", lit(extractedTimeSeries.getSignalTimestamps(extractBHEData.SignalType_BHE.sig_BHE_FC1_Freesight)))
        .withColumn("BHE_FC1_Freesight_Values", lit(extractedTimeSeries.getSignalValues(extractBHEData.SignalType_BHE.sig_BHE_FC1_Freesight)))
        #.withColumn("BHE_FC1_Freesight_timestamps_exploded", F.explode("BHE_FC1_Freesight_timestamps"))
        .orderBy("timestamp", ascending=False)
        .cache()
)

display(df)