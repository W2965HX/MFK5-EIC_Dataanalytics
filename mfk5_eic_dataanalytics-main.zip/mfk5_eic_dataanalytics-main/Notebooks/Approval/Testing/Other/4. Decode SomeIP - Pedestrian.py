# Databricks notebook source
from pyspark.sql.functions import col, radians, year, when, substring, lit, unhex, array_contains
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import unbase64
from pyspark.sql.types import StringType,BooleanType,DateType,FloatType,IntegerType,BinaryType

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

# COMMAND ----------

# MAGIC %md
# MAGIC ## Decode functions for base 64 messages 

# COMMAND ----------

# Create a UDF (User Defined Function) for decoding base64 encoded data
decode_udf = spark.udf.register("decode", lambda x: base64.b64decode(x).hex())
float_udf = spark.udf.register("for_float", lambda x: struct.unpack('>f', bytes.fromhex(x))[0])
int16_udf = spark.udf.register("for_int16", lambda x: struct.unpack('>h', bytes.fromhex(x))[0])
uint16_udf = spark.udf.register("for_uint16", lambda x: struct.unpack('>H', bytes.fromhex(x))[0])
uint8_udf = spark.udf.register("for_uint8", lambda x: struct.unpack('>b', bytes.fromhex(x))[0])

# COMMAND ----------

# MAGIC %md
# MAGIC ## Define window over events 
# MAGIC

# COMMAND ----------

# Define window over events
window_events  = Window.partitionBy("userMessageId")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Data and select use case

# COMMAND ----------

# Select UseCase
selectedUseCaseID = "UseCase-4d807fe5-93eb-4c53-a0f8-e446f151ba48" # Regular Image Upload Reliable - ADAS WB
#selectedUseCaseID = "UseCase-665e11af-e77a-4535-b1fa-43663c56622c" # WBA_ME_Ausloese_V0_1

df = spark.read.format("delta").table("default.deltalakesilver")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df = (df
        .filter(F.array_contains(df.useCaseIds, selectedUseCaseID))
        # .withColumn("date", F.from_unixtime((col("timestamp")/1000)))
        .withColumn("date", col("timestamp"))        
        # .withColumn("ingestDate", F.from_unixtime((col("ingest_timestamp")/1000)))
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        # .select("userMessageId", "ingest_timestamp", "timestamp", "timestamp_unix", "name", "value", "unit", "vehicleId", "containerMsgCount")
        .orderBy("timestamp", ascending=False)
        .cache()
)

# df.printSchema()
# display(df.sort(col("ingestDate").desc(), col("timestamp").desc()))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Create pivot table for one event (select userMessageID)

# COMMAND ----------

messageID = "2036d6fb-5c8b-403e-b141-d3a792034435"

df_pivot = (
    df.filter(df.userMessageId == messageID)
    .groupBy("userMessageId", "vehicleId", "containerMsgCount", "timestamp_unix")
    .pivot("name")
    .agg(F.first("value"))
    .withColumn("event_time", (col("timestamp_unix") - F.min(col("timestamp_unix")).over(window_events))/1000)
)
display(df_pivot)

# Create column "pedestriansEvent_isNull" that marks rows, which does not contain pedestrian data
# Create column "pedestriansEvent_temp" that copys base64 message from the column "PedestrianDetection pedestrians Event". If no value exists, dummy value is created
# Create column "pedestriansEvent" that decodes the base64 message from the column "pedestriansEvent_temp". 
# Create column "PedestrianClass_Elem1" that decodes a substring of the full message  from "pedestriansEvent"
df_pivot_decoded = (
    df_pivot.withColumn(
        "pedestriansEvent_isNull",
        when(col("PedestrianDetection pedestrians Event").isNull(), lit(1)),
    )
    .withColumn(
        "pedestriansEvent_temp",
        when(
            col("PedestrianDetection pedestrians Event").isNull(),
            lit(
                "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA="
            ),
        ).otherwise(col("PedestrianDetection pedestrians Event")),
    )
    .withColumn("pedestriansEvent", decode_udf(col("pedestriansEvent_temp")))
    .withColumn("PedestrianClass_Elem1", uint8_udf(substring("pedestriansEvent", 1, 2)))
)
display(df_pivot_decoded)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Display time series for one column (PedestrianClass_Elem1)

# COMMAND ----------

plot_data = (df_pivot_decoded.
             where(col("pedestriansEvent_isNull").isNull())
            .toPandas())


# Plot velocity X
event_data_vx_ego = plot_data[["event_time", "PedestrianClass_Elem1"]].dropna()
fig_vx = go.Figure()
fig_vx.add_trace(go.Scatter(x=event_data_vx_ego["event_time"], y=(event_data_vx_ego["PedestrianClass_Elem1"]), mode='lines', name='Ego'))
fig_vx.update_layout(title='Pedestrian Class Elem 1', xaxis_title="Time in s", yaxis_title="Pedestrian Class", showlegend = True, width=600, height=280, legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99), margin=dict(l=20, r=70, b=10, t=50))
fig_vx.update_xaxes(range=[0, 11])
fig_vx.show()