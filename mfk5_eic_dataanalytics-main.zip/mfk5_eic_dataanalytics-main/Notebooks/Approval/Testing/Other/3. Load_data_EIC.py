# Databricks notebook source
# df = spark.read.format("delta").table("default.deltalakesilver")

# COMMAND ----------

#Needed for figure.write_image
%pip install -U kaleido
%restart_python

# COMMAND ----------

# MAGIC %md
# MAGIC ## Import libraries

# COMMAND ----------

from pyspark.sql.functions import col, radians, year, when, lit
from pyspark.sql import functions as F
from pyspark.sql.window import Window

import numpy as np
import pandas as pd

import base64

# COMMAND ----------

# MAGIC %md
# MAGIC ## Filter use case data

# COMMAND ----------

df = spark.read.format("delta").table("default.deltalakesilver").limit(1000000)
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df = (df
        #.filter(F.array_contains(df.useCaseIds,"UseCase-665e11af-e77a-4535-b1fa-43663c56622c")) # WBA_ME_Ausloese_V0_1
        .filter(F.array_contains(df.useCaseIds,"UseCase-4d807fe5-93eb-4c53-a0f8-e446f151ba48")) # Regular Image Upload Reliable - ADAS WB
        #.filter(F.array_contains(df.useCaseIds,"UseCase-b718d2c7-e8fb-4652-a857-cab23bb4a1d2")) 
        #.filter(F.array_contains(df.useCaseIds,"UseCase-2072e29c-b04f-418a-8e0a-3eb007980312"))        
        #.filter(F.array_contains(df.useCaseIds,"UseCase-c66c13b0-d5b0-4b84-8056-b3d34ceac631"))
        # .withColumn("date", F.from_unixtime((col("timestamp")/1000)))
        .withColumn("date", col("timestamp"))
        # .withColumn("ingestDate", F.from_unixtime((col("ingest_timestamp")/1000)))
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        # .select("userMessageId", "ingest_timestamp", "timestamp", "timestamp_unix", "name", "value", "unit", "vehicleId", "containerMsgCount")
        .orderBy("timestamp", ascending=False)
        .cache()
)

# df.printSchema()
# display(df.sort(col("ingestDate").desc(), col("timestamp").desc()))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## EIC responses
# MAGIC Filter for EIC responses and extract iamge, event_id and timestamp as separate colums

# COMMAND ----------

EIC_response = (df
                .filter(col("ingest_timestamp")>"2024-02-01")
                .filter(col("name") == "Event Image Collector - Response")
                .withColumn("image_string", F.substring_index("value", "image\":", -1))
                .withColumn("image_string", F.substring_index("image_string", ",\"e", 1))
                .withColumn("event_id", F.substring_index("value", "event_id\":", -1))
                .withColumn("event_id", F.substring_index("event_id", ",\"timestamp\":", 1))
                .withColumn("requested_timestamp", F.substring_index("value", "timestamp\":", -1))
                .withColumn("requested_timestamp", F.substring_index("requested_timestamp", "}]", 1))
                #.select("userMessageId", "ingest_timestamp", "value")
                .orderBy("ingest_timestamp").cache()
)
display(EIC_response)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Count EIC-Responses

# COMMAND ----------

print("Number of images:", EIC_response.count())

# COMMAND ----------

# MAGIC %md
# MAGIC ## Save Images to csv

# COMMAND ----------

'''
EIC_response_images = (EIC_response
                       .select("vehicleID", "mdc_id", "value", "event_id", "requested_timestamp", "timestamp_unix")
                       .withColumn("timestamp", col("timestamp_unix"))
                       )
display(EIC_response_images)
#EIC_response_images.write.mode("overwrite").csv('./Images.csv')
EIC_response_images.toPandas().to_csv('ExtractedImages/Images.csv')
'''

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select last image from list

# COMMAND ----------

# Get the last image string from the DataFrame
last_image_df = EIC_response.agg(F.last("image_string").alias("last_image"))
display(last_image_df)

# Collect the last image string value for further processing or display
last_image_value = last_image_df.collect()[0]["last_image"]
display(last_image_value)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Select single image based on userMessageId

# COMMAND ----------

userMessageIDImage = "6bb1ffe3-8777-4e51-a164-a24aafc63d81"
#userMessageIDImage = "5e53bd82-f728-4eac-a421-84a0b3fec067"
#userMessageIDImage = "32778eab-a06e-4da2-8f2a-b199ce19b913"
#userMessageIDImage = "4a4b7090-06d2-4027-9f33-3a238e46b23b"
#userMessageIDImage = "bf307512-8fbf-4206-a5e6-3c82e3ba389f"

# Get specific message
selected_message = EIC_response.filter(col("userMessageId") == userMessageIDImage)

#Extract image
selected_image = selected_message.select("image_string")
selected_image = selected_image.collect()[0][0]
display(selected_image)

#Extract Metadata
selected_eventId = selected_message.select("event_id")
selected_requested_timestamp = selected_message.select("requested_timestamp")
selected_vehicleId = selected_message.select("vehicleId")

display(selected_eventId)
display(selected_requested_timestamp)
display(selected_vehicleId)



# COMMAND ----------

# MAGIC %md
# MAGIC ##Display image: 
# MAGIC Set input_image if you want to see last image or specific image based on userMessageId (see above)

# COMMAND ----------



# COMMAND ----------

import plotly.graph_objects as go
import base64
import numpy as np

input_image = last_image 
#input_image = selected_image 


decoded_value = base64.b64decode(input_image)
image = np.frombuffer(decoded_value, np.uint8)#[9:]
encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
prefix = "data:image/jpg;base64,"
fig = go.Figure(go.Image(source=prefix+encoded_image))
fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
#plotly_obj = fig.to_json()
#result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
fig.show()
#fig.write_image(path)

'''
cnt = 0
for row in EIC_response.rdd.collect():
    image = row['image_string']
    print(image[0:100])    
    writeImage(image, "./ExtractedImages/test" + str(cnt) + ".png")
    cnt += 1
'''






# COMMAND ----------

# MAGIC %md
# MAGIC ## Get additional meta data for image

# COMMAND ----------

eventid_image = selected_eventId.collect()[0]
requested_timestamp_image= int(selected_requested_timestamp.collect()[0][0])
vehicleId_image= selected_vehicleId.collect()[0][0]

#requested_timestamp_image = 1713513902906 
display(requested_timestamp_image)

# get userMessageId from meta data
df_messageID = (df
                        .filter(col("vehicleId") == vehicleId_image)
                        .filter(col("timestamp_unix") > requested_timestamp_image-1000)
                        .filter(col("timestamp_unix") < requested_timestamp_image+1000)
                        .filter(col("name") == "EIC_ID")
)
display(df_messageID)

# get all meta data with messageID
userMessageId = df_messageID.select("userMessageId").collect()[0][0]
display(userMessageId)
df_metadata_messageID = (df
                        .filter(col("userMessageId") == userMessageId)                        
)
display(df_metadata_messageID)