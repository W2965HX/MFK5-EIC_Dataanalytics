# Databricks notebook source
from pyspark.sql.functions import col, radians, year, when, lit
from pyspark.sql import functions as F
from pyspark.sql.window import Window

import numpy as np
import pandas as pd
import base64
import struct

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

# COMMAND ----------

# MAGIC %md
# MAGIC # Number of Images from different Usecases over time

# COMMAND ----------

df_allImages = spark.read.format("delta").table("default.deltalakesilver")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df_allImages = (df_allImages
    .filter(col("timestamp")>=lit("2024-11-24T00:00:00.000+0000"))
    .filter(col("name").contains("Image"))
    .select("timestamp", "name", "useCaseIds")
    
)
display(df_allImages)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Read Data and select use case

# COMMAND ----------

df = spark.read.format("delta").table("default.deltalakesilver")
# Set correct time zone
spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

# Filter for last X days
lastDays = 10

# Filter for use case
useCaseID = "UseCase-75c7e965-b657-4d94-92a4-e026e9119cd6" # EIC_MFK5_Perception_PED_ConfBit

df = (df
        .filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        .filter(F.array_contains(df.useCaseIds, useCaseID)) 
        # .withColumn("date", F.from_unixtime((col("timestamp")/1000)))
        .withColumn("date", col("timestamp"))
        # .withColumn("ingestDate", F.from_unixtime((col("ingest_timestamp")/1000)))
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        # .select("userMessageId", "ingest_timestamp", "timestamp", "timestamp_unix", "name", "value", "unit", "vehicleId", "containerMsgCount")
        .orderBy("timestamp", ascending=False)
        .cache()
)

# df.printSchema()
# display(df.sort(col("ingestDate").desc(), col("timestamp").desc()))
display(df)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview which car sent data (Reports per hour)

# COMMAND ----------


df_distinct = df.select(df.vehicleId, df.containerId, df.date).distinct()

# Eindeutige Container IDs -> Visualisierung wie viele Reports über Zeit gesendet wurden und von welchem Fahrzeug 
# df_distinct.select(df.VehicleId, df.ContainerId, df.Time).distinct().display()
display(df_distinct)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview how much image data / eic ids data is sent her hour 

# COMMAND ----------


df_useCase_EIC_Data = df.filter((df.name == 'Event Image Collector - Response') | (df.name == 'EIC_ID')) \
                    .select(df.vehicleId, df.containerId, df.date, df.name)

display(df_useCase_EIC_Data)


# COMMAND ----------

# MAGIC %md
# MAGIC ## Overview over locations of events

# COMMAND ----------

# DBTITLE 1,Create window
# To calculate event times of multiple elements within one report
window_events  = Window.partitionBy("userMessageId")

# COMMAND ----------

# DBTITLE 1,Pivot to create columns from name elements
df_pivot = (df
            .groupBy("userMessageId", "vehicleId", "containerMsgCount", "timestamp_unix")
            .pivot("name")
            .agg(F.first("value"))
            .withColumn("event_time", (col("timestamp_unix") - F.min(col("timestamp_unix")).over(window_events))/1000)
            )
plot_data = df_pivot.toPandas()
display(df_pivot)


# COMMAND ----------

# Plot gps map

event_data_gps = plot_data[["latitude", "longitude", "event_time"]].dropna()

display(event_data_gps)

customdata = np.stack((event_data_gps['event_time'], event_data_gps['latitude']), axis=-1)
fig_map = go.Figure()

fig_map.add_trace(go.Scattermapbox(
                lat=event_data_gps["latitude"],
                lon=event_data_gps["longitude"],
                name="GPS position",
                mode='markers',
                marker=go.scattermapbox.Marker(
                    symbol = "circle",
                    size=7,
                    color='rgb(255, 0, 0)',
                    # opacity=0.7
                ),
                # text=(event_data_gps.event_time).to_numpy(),
                # hoverinfo='text',
            ))
fig_map.update_layout(
            title = "Map",
            mapbox = {
                # 'accesstoken': token,
                'style': 'open-street-map',
                'zoom': 5,
                "center" : dict(
                    lat=event_data_gps["latitude"].median(),
                    lon=event_data_gps["longitude"].median())
                },
                showlegend = True,
                width=800, height=600,
                legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99), 
                margin=dict(l=20, r=70, b=10, t=50))
hovertemplate="time:%{customdata[0]:.2f} s"
fig_map.update_traces(customdata=customdata, hovertemplate=hovertemplate)
fig_map.show()