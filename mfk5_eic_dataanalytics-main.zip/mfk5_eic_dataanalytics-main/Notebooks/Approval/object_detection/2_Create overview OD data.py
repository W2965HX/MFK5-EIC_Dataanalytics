# Databricks notebook source
# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at, date_sub, current_date, unix_millis, date_format, min as min_, max as max_, get_json_object, last, array_min, array_max

from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, LongType, DoubleType

#from EICModules.decodeHighlevelData import decodeHumidityAndTemperature, decodeWeatherCondition


import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# COMMAND ----------

# MAGIC %md
# MAGIC # Read decoded data from gold layer

# COMMAND ----------


input_data ="ude_int_euwe_datajedi_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_transformed_and_decoded_Appr"

df = spark.read.table(f"{input_data}").cache()

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

min_max_df = df.agg(min_("timestamp").alias("min_timestamp"), max_("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Remove separate kilometer + MFK5-SW reports (otherwise they are listed as referenced EIC Images)

# COMMAND ----------

df_wo_km_report = (df
                    .filter(~((df.containerMsgCount == 1) & (df.DW_Kilometerstand.isNotNull()) ))
                    .filter(~((df.containerMsgCount == 1) & (df.MFK5_SW_Version.isNotNull()) ))
)

display(df_wo_km_report)
df_wo_km_report.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Define functions for od event summary

# COMMAND ----------


def calculate_relativeTimestamps(activationTimestamp, absoluteTimestampImages_list):
  if activationTimestamp is None or absoluteTimestampImages_list is None:
    return None
  return sorted([timstampImage - activationTimestamp for timstampImage in absoluteTimestampImages_list])

calculate_relativeTimestamps_udf = udf(calculate_relativeTimestamps, ArrayType(DoubleType()))

def eic_od_event_summary(input_df):
    
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")                        
                        #.orderBy("unix_time_at_activation")
                        .orderBy("min_timestamp_unix_trigger")
                        .rangeBetween(-1666, 2500)
    )
    # define window for referencing metadata for the image
    window_metadatasearch = (Window.partitionBy("vehicleId")                        
                        #.orderBy("unix_time_at_activation")
                        .orderBy("min_timestamp_unix_trigger")
                        .rangeBetween(-2500, 1666)
    )
    time_signal = "timestamp_unix"

    output_df = (input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Od to EIC_ID
        #.withColumn("time_after_activation", when(col("EIC_ID").isNotNull(), col(time_signal)))
        #.withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)


        .groupBy("containerId", "vehicleId", "containerMsgCount")
        .agg(
            F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),            
            #F.min("unix_time_at_activation").alias("min_unix_time_at_activation"),
            F.min("timestamp_unix_confBitsL1L2L3set").alias("min_timestamp_unix_confBitsL1L2L3set"),
            F.min("timestamp_unix_confBitsL1L2L3set").alias("min_timestamp_unix_trigger"),

            F.min(F.when(col("confBitPrecedingL2") == "Od_ConfirmationBit.set", col("timestamp_unix"))).alias("min_timestamp_unix_confBitL2PrecedingSet"),
            F.min(F.when(col("confBitPrecedingL3") == "Od_ConfirmationBit.set", col("timestamp_unix"))).alias("min_timestamp_unix_confBitL3PrecedingSet"),
            F.max(F.when(col("confBitPrecedingL2") == "Od_ConfirmationBit.set", col("timestamp_unix"))).alias("max_timestamp_unix_confBitL2PrecedingSet"),
            F.max(F.when(col("confBitPrecedingL3") == "Od_ConfirmationBit.set", col("timestamp_unix"))).alias("max_timestamp_unix_confBitL3PrecedingSet"),

            F.min("VDSO_ALgtOfsCmp").alias("min_VDSO_ALgtOfsCmp"),
            F.min("delta_time_someIP").alias("min_delta_time_someIP"),
            F.max("delta_time_someIP").alias("max_delta_time_someIP"),
            F.mean("delta_time_someIP").alias("mean_delta_time_someIP"),
            F.variance("delta_time_someIP").alias("variance_delta_time_someIP"),
            F.max("VDSO_Vx3dGNSS").alias("max_VDSO_Vx3dGNSS"),
            F.first(time_signal).alias("first_unix_timestamp"),            
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_image_string").alias("count_EIC_image_string"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            #F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Od_event").alias("count_Od_event"),
            F.count("RG_RA_CountryCode").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            #F.count("weather_cond_json").alias("count_weather_cond_json"),
            #F.count("env_brightness").alias("count_env_brightness"),
            #F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            #F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            #F.count("low_beam_state").alias("count_low_beam_state"),
            #F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            #F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).cast("double").alias("act_lat"),
            F.first("act_long", ignorenulls=True).cast("double").alias("act_long"),

            F.first("MFK5_SW_Version_extract", ignorenulls=True).alias("MFK5_SW_Version_extract"),
            F.first("Last_MFK5_SW", ignorenulls=True).alias("Last_MFK5_SW"),

            F.collect_set("EIC_image_event_id").alias("EIC_image_event_id_Values"),   
            F.collect_set("EIC_ID").alias("EIC_ID_values"),
                  
            F.collect_set("WBA_Warnung").alias("WBA_Warnung_Values"),
            
            F.collect_set("confBitPrecedingL1").alias("confBitPrecedingL1_Values"),
            F.collect_set("confBitPrecedingL2").alias("confBitPrecedingL2_Values"),
            F.collect_set("confBitPrecedingL3").alias("confBitPrecedingL3_Values"),

            F.collect_set("confBitOncomingL2").alias("confBitOncomingL2_Values"),
            F.collect_set("confBitOncomingL3").alias("confBitOncomingL3_Values"),

            F.collect_set("confBitCrossingL1").alias("confBitCrossingL1_Values"),
            F.collect_set("confBitCrossingL2").alias("confBitCrossingL2_Values"),
            F.collect_set("confBitCrossingL3").alias("confBitCrossingL3_Values"),
            F.collect_set("confBitEgoTurningL3").alias("confBitEgoTurningL3_Values")
        )
        # set activation time of eic images to their unix timestamp
        #.withColumn("unix_time_at_activation",
        #           when(col("count_EIC_image_string")==1 , col("first_unix_timestamp"))
        #           .otherwise(col("min_unix_time_at_activation")))
        
        .withColumn("min_timestamp_unix_trigger", 
                    when(col("count_EIC_image_string")==1 , col("first_unix_timestamp"))
                    .otherwise(col("min_timestamp_unix_trigger")))      

        
        # Collect for each meta data report the containerIds for corresponding EIC-Images
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))    

        # Collect for each EIC-Image the containerIds for corresponding meta data reports
        .withColumn("containerIds_metaData",
                    when(col("containerMsgCount") == 1, F.collect_set(when(col("containerMsgCount") >1,col("containerId"))).over(window_metadatasearch))
                    .otherwise(F.array()))
        .withColumn("containerIds_metaData", F.expr("filter(containerIds_metaData, x -> x != containerId)"))       
        
        # Get timestamps of all EIC images
        .withColumn("timestamps_EIC_Images",
                    #when(col("containerMsgCount") > 1, F.collect_set(col("unix_time_at_activation")).over(window_EIC))
                    when(col("containerMsgCount") > 1, F.collect_set(col("min_timestamp_unix_trigger")).over(window_EIC))
                    .otherwise(F.array()))
        #.withColumn("timestamps_EIC_Images", F.expr("filter(timestamps_EIC_Images, x -> x != unix_time_at_activation)"))        
        .withColumn("timestamps_EIC_Images", F.expr("filter(timestamps_EIC_Images, x -> x != min_timestamp_unix_trigger)"))        

        # Calculate relative times between EIC images and the activation time of the event
        #.withColumn("rel_timestamps_EIC_Images", calculate_relativeTimestamps_udf(col("unix_time_at_activation"), col("timestamps_EIC_Images")))
        .withColumn("rel_timestamps_EIC_Images", calculate_relativeTimestamps_udf(col("min_timestamp_unix_trigger"), col("timestamps_EIC_Images")))

        # Extract minimum and maximum relative time between EIC images and the activation time of the event
        .withColumn("min_reL_timestamp_EIC_Images", array_min(col("rel_timestamps_EIC_Images")))
        .withColumn("max_reL_timestamp_EIC_Images", array_max(col("rel_timestamps_EIC_Images")))
        
        # Count relative timestamps that are bigger, smaller than expected
        .withColumn("count_reL_timestamp_less_than_min", F.size(F.expr("filter(rel_timestamps_EIC_Images, x -> x < -833)")))
        .withColumn("count_reL_timestamp_bigger_than_max", F.size(F.expr("filter(rel_timestamps_EIC_Images, x -> x > 2167)")))

        # count images with relative timestamp between -833 and -499
        .withColumn("count_rel_timestamp_1", F.expr("""size(filter(rel_timestamps_EIC_Images, x -> x >= -833 AND x <= -499))"""))
        .withColumn("count_rel_timestamp_2", F.expr("""size(filter(rel_timestamps_EIC_Images, x -> x >  -499 AND x <= -166))"""))
        .withColumn("count_rel_timestamp_3", F.expr("""size(filter(rel_timestamps_EIC_Images, x -> x >  -166 AND x <=  166))"""))
        .withColumn("count_rel_timestamp_4", F.expr("""size(filter(rel_timestamps_EIC_Images, x -> x >   833 AND x <= 1167))"""))
        .withColumn("count_rel_timestamp_5", F.expr("""size(filter(rel_timestamps_EIC_Images, x -> x >= 1833 AND x <= 2167))"""))


        # Activation timestamp based on eventID - deprecated
        #.withColumn("timestamp_activation",F.timestamp_millis(col("unix_time_at_activation").cast("long")))

        # trigger timestamp based on confBits
        .withColumn("timestamp_trigger", F.timestamp_millis(col("min_timestamp_unix_confBitsL1L2L3set").cast("long")))

        # WBA values: Vorwarnung, Eingriff 
        .withColumn("contains_Vorwarnung", F.array_contains(col("WBA_Warnung_values"), "Vorwarnung"))
        .withColumn("contains_Eingriff", F.array_contains(col("WBA_Warnung_values"), "Eingriff"))

        # Conf bits        
        .withColumn("contains_PrecedingL1_set", F.array_contains(col("confBitPrecedingL1_Values"), "Od_ConfirmationBit.set"))
        .withColumn("contains_PrecedingL2_set", F.array_contains(col("confBitPrecedingL2_Values"), "Od_ConfirmationBit.set"))
        .withColumn("contains_PrecedingL3_set", F.array_contains(col("confBitPrecedingL3_Values"), "Od_ConfirmationBit.set"))

        .withColumn("contains_OncomingL2_set", F.array_contains(col("confBitOncomingL2_Values"), "Od_ConfirmationBit.set"))
        .withColumn("contains_OncomingL3_set", F.array_contains(col("confBitOncomingL3_Values"), "Od_ConfirmationBit.set"))

        .withColumn("contains_CrossingL1_set", F.array_contains(col("confBitCrossingL1_Values"), "Od_ConfirmationBit.set"))
        .withColumn("contains_CrossingL2_set", F.array_contains(col("confBitCrossingL2_Values"), "Od_ConfirmationBit.set"))
        .withColumn("contains_CrossingL3_set", F.array_contains(col("confBitCrossingL3_Values"), "Od_ConfirmationBit.set"))

        .withColumn("contains_EgoTurningL3_set", F.array_contains(col("confBitEgoTurningL3_values"), "Od_ConfirmationBit.set"))

        .withColumn("contains_min_1_L2L3_set", 
                    col("contains_PrecedingL2_set") | col("contains_PrecedingL3_set") |
                    col("contains_OncomingL2_set") | col("contains_OncomingL3_set") | 
                    col("contains_CrossingL2_set") | col("contains_CrossingL3_set") | 
                    col("contains_EgoTurningL3_set"))
        

        # Conf bit duration
        .withColumn("duration_PrecedingL2_set", col("max_timestamp_unix_confBitL2PrecedingSet") - col("min_timestamp_unix_confBitL2PrecedingSet"))
        .withColumn("duration_PrecedingL3_set", col("max_timestamp_unix_confBitL3PrecedingSet") - col("min_timestamp_unix_confBitL3PrecedingSet"))

        # Geofence PGN
        .withColumn("insidePGN", when((col("act_long") > 11.70475) 
                                      & (col("act_long") < 11.74852)
                                      & (col("act_lat") > 48.76083)
                                      & (col("act_lat") < 48.78029), True).otherwise(False))
        
        #& (col("act_long").cast("long") < 11.74)

        .orderBy("ingestDate_wo_ms", ascending=False)
    )
    return output_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Event summary

# COMMAND ----------

df_data_summary = eic_od_event_summary(df_wo_km_report)
display(df_data_summary)

# Display only meta data reports
df_data_summary_wo_eicImages = df_data_summary.filter(~(col("count_EIC_image_string") == 1))

display(df_data_summary_wo_eicImages)
df_data_summary_wo_eicImages.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Check how many EIC-images have no corresponding metadata report

# COMMAND ----------

df_data_summary_eic_images_wo_metadata = (df_data_summary
                                          #.filter(col("containerMsgCount") == 1)
                                          #.filter(F.size(col("containerIds_metaData")) == 0)
                                          .select(#"timestamp_activation", 
                                                  "min_timestamp_unix_trigger", 
                                                  "ingestDate_wo_ms",
                                                 "containerId",                                     
                                                 #"userMessageId", 
                                                 "containerMsgCount",                                                  
                                                 "vehicleId",
                                                 "containerIds_metaData",
                                                 "containerIds_EIC_Images")
                                          )
display(df_data_summary_eic_images_wo_metadata)

# COMMAND ----------

print(df_data_summary_wo_eicImages.columns)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store event summary

# COMMAND ----------

output_data ="ude_int_euwe_datajedi_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_summary_Appr"

df_data_summary_wo_eicImages.write.format("delta").mode("overwrite").saveAsTable(f"{output_data}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
output_data ="ude_int_euwe_datajedi_cariad.eicmfk_gold.EIC_MFK5_Perception_OD_ConfBit_V0_1_summary_Appr"

spark.sql(
    f"DROP TABLE {output_data}"
)
'''
