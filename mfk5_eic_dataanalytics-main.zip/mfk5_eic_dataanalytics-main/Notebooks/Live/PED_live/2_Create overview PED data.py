# Databricks notebook source
# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at, date_sub, current_date, unix_millis, date_format, min as min_, max as max_, get_json_object, last

from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, LongType, DoubleType

#from EICModules.decodeHighlevelData import decodeHumidityAndTemperature, decodeWeatherCondition


import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# COMMAND ----------

# MAGIC %md
# MAGIC # Read decoded data from gold layer

# COMMAND ----------


input_data ="ude_prod_euwe_datajedi_audi.eicmfk_gold.eic_mfk5_perception_ped_confbit_v0_3_transformed_and_decoded_live_cl3_kd1"

df = spark.read.table(f"{input_data}").cache()

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

min_max_df = df.agg(min_("timestamp").alias("min_timestamp"), max_("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Define functions for od event summary

# COMMAND ----------


def calculate_relativeTimestamps(activationTimestamp, absoluteTimestampImages_list):
  if activationTimestamp is None or absoluteTimestampImages_list is None:
    return None
  return sorted([timstampImage - activationTimestamp for timstampImage in absoluteTimestampImages_list])

calculate_relativeTimestamps_udf = udf(calculate_relativeTimestamps, ArrayType(DoubleType()))

def eic_ped_event_summary(input_df):
    
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")                        
                        #.orderBy("unix_time_at_activation")
                        #.orderBy("first_unix_timestamp")
                        .orderBy("min_timestamp_unix_trigger")
                        .rangeBetween(-10000, 10000)
    )
    time_signal = "timestamp_unix"

    output_df = (input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Od to EIC_ID
        #.withColumn("time_after_activation", when(col("EIC_ID").isNotNull(), col(time_signal)))
        #.withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)


        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),            
            #F.min("unix_time_at_activation").alias("min_unix_time_at_activation"),
            F.min("timestamp_unix_confBitsL2L3set").alias("min_timestamp_unix_confBitsL2L3set"),
            F.min("timestamp_unix_confBitsL2L3set").alias("min_timestamp_unix_trigger"),
            F.min("VDSO_ALgtOfsCmp").alias("min_VDSO_ALgtOfsCmp"),
            F.min("delta_time_someIP").alias("min_delta_time_someIP"),      
            F.min("TTC_min").alias("TTC_min"),
            F.min("RadialDistance_min").alias("RadialDistance_min"),   

            F.max("bicycle_count").alias("max_bicycle_count"),
            F.max("pedestrian_count").alias("max_pedestrian_count"),

            F.max("delta_time_someIP").alias("max_delta_time_someIP"),
            F.mean("delta_time_someIP").alias("mean_delta_time_someIP"),
            F.variance("delta_time_someIP").alias("variance_delta_time_someIP"),
            F.max("VDSO_Vx3dGNSS").alias("max_VDSO_Vx3dGNSS"),
            F.first(time_signal).alias("first_unix_timestamp"),            
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),            
            F.count("EIC_image_string").alias("count_EIC_image_string"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Ped_event").alias("count_Ped_event"),
            F.count("RG_RA_CountryCode_1073741824").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            F.count("weather_cond_json").alias("count_weather_cond_json"),
            F.count("env_brightness").alias("count_env_brightness"),
            F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            F.count("low_beam_state").alias("count_low_beam_state"),
            F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).alias("act_lat"),
            F.first("act_long", ignorenulls=True).alias("act_long"),

            F.collect_set("WBA_Warnung").alias("WBA_Warnung_values"),

            F.collect_set("EIC_ID").alias("EIC_ID_values"),
            F.collect_set("EIC_image_event_id").alias("image_event_id_values"),
            
            F.collect_set("confBitL2").alias("confBitL2_values"),
            F.collect_set("confBitL3").alias("confBitL3_values"),
            F.collect_set("confBitEgoTurningL3").alias("confBitEgoTurningL3_values"),

            # values at activation time
            F.first("pedID_at_activation", ignorenulls=True).alias("pedID_at_activation"),
            F.first("pedID_index_at_activation", ignorenulls=True).alias("pedID_index_at_activation"),
            F.first("pedestrianClass_at_activation", ignorenulls=True).alias("pedestrianClass_at_activation"),
            F.first("TTC_at_activation", ignorenulls=True).alias("TTC_at_activation"),
            F.first("radialDistance_at_activation", ignorenulls=True).alias("radialDistance_at_activation"),
            F.first("azimuthAngle_at_activation", ignorenulls=True).alias("azimuthAngle_at_activation"),

        )
        # set activation time of eic images to their unix timestamp
        #.withColumn("unix_time_at_activation",
        #           when(col("count_EIC_image_string")==1 , col("first_unix_timestamp"))
        #           .otherwise(col("min_unix_time_at_activation")))       
        .withColumn("min_timestamp_unix_trigger", 
                    when(col("count_EIC_image_string")==1 , col("first_unix_timestamp"))
                    .otherwise(col("min_timestamp_unix_trigger")))    
        
        # Collect for each meta data report the containerIds for corresponding EIC-Images
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))     

        # Collect for each EIC-Image the containerIds for corresponding meta data reports
        .withColumn("containerIds_metaData",
                    when(col("containerMsgCount") == 1, F.collect_set(when(col("containerMsgCount") >1,col("containerId"))).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_metaData", F.expr("filter(containerIds_metaData, x -> x != containerId)"))     
        
        # Get timestamps of all EIC images
        .withColumn("timestamps_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("min_timestamp_unix_trigger")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("timestamps_EIC_Images", F.expr("filter(timestamps_EIC_Images, x -> x != min_timestamp_unix_trigger)"))        

        # Calculate relative times between EIC images and the activation time of the event
        .withColumn("rel_timestamps_EIC_Images", calculate_relativeTimestamps_udf(col("min_timestamp_unix_trigger"), col("timestamps_EIC_Images")))

        # Activation timestamp
      #  .withColumn("timestamp_activation",F.timestamp_millis(col("unix_time_at_activation").cast("long")))
        # trigger timestamp based on confBits
        .withColumn("timestamp_trigger", F.timestamp_millis(col("min_timestamp_unix_trigger").cast("long")))

        # WBA values: Vorwarnung, Eingriff 
        .withColumn("contains_Vorwarnung", F.array_contains(col("WBA_Warnung_values"), "Vorwarnung"))
        .withColumn("contains_Eingriff", F.array_contains(col("WBA_Warnung_values"), "Eingriff"))

        # Conf bits        
        .withColumn("contains_L2_set", F.array_contains(col("confBitL2_values"), "Ped_ConfirmationBit.set"))
        .withColumn("contains_L3_set", F.array_contains(col("confBitL3_values"), "Ped_ConfirmationBit.set"))
        .withColumn("contains_L3EgoTurning_set", F.array_contains(col("confBitEgoTurningL3_values"), "Ped_ConfirmationBit.set"))

        .orderBy("ingestDate_wo_ms", ascending=False)
    )
    return output_df
  

# COMMAND ----------

# MAGIC %md
# MAGIC # Event summary

# COMMAND ----------

df_data_summary = eic_ped_event_summary(df)
display(df_data_summary)

# Display only meta data reports
df_data_summary_wo_eicImages = df_data_summary.filter(~(col("count_EIC_image_string") == 1))
display(df_data_summary_wo_eicImages)

# COMMAND ----------

# MAGIC %md
# MAGIC # Check how many EIC-images have no corresponding metadata report

# COMMAND ----------

df_data_summary_eic_images_wo_metadata = (df_data_summary
                                          .filter((col("containerMsgCount") == 1))
                                          .select(#"timestamp_activation", 
                                                  "min_timestamp_unix_trigger",
                                                 "containerId", 
                                                # "userMessageId", 
                                                 "vehicleId",
                                                 "containerIds_metaData")
                                          )
display(df_data_summary_eic_images_wo_metadata)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store event summary

# COMMAND ----------

output_data ="ude_prod_euwe_datajedi_audi.eicmfk_gold.EIC_MFK5_Perception_PED_ConfBit_V0_3_summary_live_Cl3_KD1"

df_data_summary_wo_eicImages.write.format("delta").mode("overwrite").saveAsTable(f"{output_data}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
output_data ="ude_prod_euno_fhum_adas_cariad.eicmfk_gold.EIC_MFK5_Perception_PED_ConfBit_V0_3_summary_live_Cl3_KD1"

spark.sql(
    f"DROP TABLE {output_data}"
)
'''
