# Databricks notebook source
# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, explode, posexplode, element_at, date_sub, current_date, unix_millis, date_format, min as min_, max as max_, get_json_object, last

from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, LongType, DoubleType

#from EICModules.decodeHighlevelData import decodeHumidityAndTemperature, decodeWeatherCondition


import numpy as np
import pandas as pd
import base64
import struct
import json

import plotly.graph_objects as go
import plotly.offline as py
from plotly.offline import plot

import matplotlib.pyplot as plt

# COMMAND ----------

# MAGIC %md
# MAGIC # Read decoded data from gold layer

# COMMAND ----------


my_catalog_name = "ude_prod_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "Live_PedEventsDecodedCl3"

df = spark.read.table(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}").cache()

spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

min_max_df = df.agg(min_("timestamp").alias("min_timestamp"), max_("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df)
df.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Define functions for od event summary

# COMMAND ----------


def calculate_relativeTimestamps(activationTimestamp, absoluteTimestampImages_list):
  if activationTimestamp is None or absoluteTimestampImages_list is None:
    return None
  return sorted([timstampImage - activationTimestamp for timstampImage in absoluteTimestampImages_list])

calculate_relativeTimestamps_udf = udf(calculate_relativeTimestamps, ArrayType(DoubleType()))

def eic_ped_event_summary(input_df):
    
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")                        
                        .orderBy("unix_time_at_activation")
                        #.orderBy("first_unix_timestamp")
                        .rangeBetween(-10000, 10000)
    )
    time_signal = "timestamp_unix"

    output_df = (input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Od to EIC_ID
        #.withColumn("time_after_activation", when(col("EIC_ID").isNotNull(), col(time_signal)))
        #.withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)


        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            #F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),            
            F.min("unix_time_at_activation").alias("min_unix_time_at_activation"),
            F.min("VDSO_ALgtOfsCmp").alias("min_VDSO_ALgtOfsCmp"),
            F.min("delta_time_someIP").alias("min_delta_time_someIP"),
            F.max("delta_time_someIP").alias("max_delta_time_someIP"),
            F.mean("delta_time_someIP").alias("mean_delta_time_someIP"),
            F.variance("delta_time_someIP").alias("variance_delta_time_someIP"),
            F.max("VDSO_Vx3dGNSS").alias("max_VDSO_Vx3dGNSS"),
            F.first(time_signal).alias("first_unix_timestamp"),            
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_Response").alias("count_EIC_Response"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Ped_event").alias("count_Ped_event"),
            F.count("RG_RA_CountryCode_1073741824").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            F.count("weather_cond_json").alias("count_weather_cond_json"),
            F.count("env_brightness").alias("count_env_brightness"),
            F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            F.count("low_beam_state").alias("count_low_beam_state"),
            F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).alias("act_lat"),
            F.first("act_long", ignorenulls=True).alias("act_long"),

            F.collect_set("WBA_Warnung").alias("WBA_Warnung_Values"),
            
            F.collect_set("confBitL2").alias("confBitL2_Values"),
            F.collect_set("confBitL3").alias("confBitL3_Values"),
            F.collect_set("confBitEgoTurningL3").alias("confBitEgoTurningL3_Values"),

        )
        # set activation time of eic images to their unix timestamp
        .withColumn("unix_time_at_activation",
                   when(col("count_EIC_Response")==1 , col("first_unix_timestamp"))
                   .otherwise(col("min_unix_time_at_activation")))
        .select(
            "containerId",
            "userMessageId",
            "vehicleId",
            "containerMsgCount",
            #"ingestDate_wo_ms",
            "unix_time_at_activation",
            "first_unix_timestamp",
            "min_VDSO_ALgtOfsCmp",
            "max_VDSO_Vx3dGNSS",
            "min_delta_time_someIP",
            "max_delta_time_someIP",
            "mean_delta_time_someIP",
            "variance_delta_time_someIP",
            "count_DW_Kilometerstand",
            "count_EIC_ID",
            "count_EIC_Response",
            "count_LWI_AgStgWhl",
            "count_Ped_event",
            "count_RG_RA_CountryCode",
            "count_Streetclass",
            "count_VDSO_AgvYawRateOfsCmp",
            "count_VDSO_Vx3dGNSS",
            "count_high_beam_state",
            "count_latitude",
            "count_longitude",  
            "act_lat",
            "act_long",
            "WBA_Warnung_Values",
            "confBitL2_Values",
            "confBitL3_Values",
            "confBitEgoTurningL3_Values",
            "count_Outdoor_temp_C",
            "count_outside_temp_hum_json",
            "count_outside_dewpoint",             
            "count_weather_cond_json",
            "count_env_brightness",
            "count_env_field_and_forward_brightness"      
        )
        
        # Collect for each meta data report the containerIds for corresponding EIC-Images
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))        
        
        # Get timestamps of all EIC images
        .withColumn("timestamps_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("unix_time_at_activation")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("timestamps_EIC_Images", F.expr("filter(timestamps_EIC_Images, x -> x != unix_time_at_activation)"))        

        # Calculate relative times between EIC images and the activation time of the event
        .withColumn("rel_timestamps_EIC_Images", calculate_relativeTimestamps_udf(col("unix_time_at_activation"), col("timestamps_EIC_Images")))
        
        .orderBy("first_unix_timestamp", ascending=False)
    )
    return output_df

# COMMAND ----------

# MAGIC %md
# MAGIC # Event summary

# COMMAND ----------

df_data_summary = eic_ped_event_summary(df)
display(df_data_summary)

df_data_summary_wo_eicImages = df_data_summary.filter(~(col("count_EIC_Response") == 1))

display(df_data_summary_wo_eicImages)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store event summary

# COMMAND ----------

my_catalog_name = "ude_prod_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "Live_PedEventsSummaryCl3"

df_data_summary_wo_eicImages.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
my_catalog_name = "ude_prod_euno_fhum_adas_cariad"   # REPLACE WITH YOUR CATALOG
my_project_name = "eicmfk"                        # REPLACE WITH YOUR PROJECT
my_gold_layer_table_name = "Live_PedEventsSummaryCl3"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''
