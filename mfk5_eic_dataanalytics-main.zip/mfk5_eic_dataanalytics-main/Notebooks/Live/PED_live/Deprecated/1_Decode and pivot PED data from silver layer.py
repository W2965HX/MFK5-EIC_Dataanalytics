# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %md
# MAGIC # Install packages

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col
import importlib
import sys

import pivotAndDecodePED

importlib.reload(pivotAndDecodePED)


# COMMAND ----------

# MAGIC %md
# MAGIC # Read raw data from silver layer

# COMMAND ----------


spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df_read = spark.read.table("ude_prod_euno_fhum_adas_cariad.eicmfk_silver.`usecase-04a41308-4022-4db0-8aa9-36b769c9d360`")

# Filter for last X days
lastDays = 50

df_silver = (df_read        
        .filter(col("timestamp") > F.date_sub(F.current_date(), lastDays))  # filter for data of last X days
        #.filter(col("name")!= "PedestrianDetection pedestrians Event")
        #filter(col("name") == "Event Image Collector - Response")
        .withColumn("timestamp_unix", F.unix_millis(col("timestamp")))
        .withColumn("timestamp_date", F.date_format(col("timestamp"),"yyyy-MM-dd"))
        .withColumn("ingestDate_wo_ms", F.date_format(col("ingest_timestamp"),"yyyy-MM-dd HH:mm:ss"))
        .orderBy("ingest_timestamp", "timestamp", ascending=False)
        .cache()
)

min_max_df = df_silver.agg(F.min("timestamp").alias("min_timestamp"), F.max("timestamp").alias("max_timestamp"))
display(min_max_df)

display(df_silver)
df_silver.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Clean data

# COMMAND ----------

df_silver_cleaned = df_silver
'''
df_silver_cleaned = (df_silver
        .filter(col("value") != "Init")
        .filter(col("value") != "Fehler")
)
display(df_silver_cleaned)

__dw_df_0 = df_silver_cleaned.filter("(name in ('DW_Kilometerstand'))")

display(__dw_df_0)
'''

# COMMAND ----------

# MAGIC %md
# MAGIC # Pivot and decode data

# COMMAND ----------

df_pivot = pivotAndDecodePED.pivot_eic_ped_data(df_silver_cleaned, spark).cache()
#display(df_pivot)
#df_pivot.count()

df_pivot_renamed = pivotAndDecodePED.convert_and_rename_ped_data(df_pivot, spark).cache()
#display(df_pivot_renamed)
#df_pivot_renamed.count()

df_pivot_renamed_decoded = pivotAndDecodePED.decode_eic_ped_data(df_pivot_renamed, spark).cache()
display(df_pivot_renamed_decoded)
df_pivot_renamed_decoded.count()



# COMMAND ----------

# MAGIC %md
# MAGIC # Calculate delta time for SomeIP signal

# COMMAND ----------

df_pivot_renamed_decoded_delta_time = pivotAndDecodePED.eic_ped_delta_time_SomeIP(df_pivot_renamed_decoded, spark).cache()

df_deltatime_sel = df_pivot_renamed_decoded_delta_time.select("containerId", "timestamp_unix", "last_valid_SomeIP_timestamp_unix", "delta_time_someIP","Ped_event")
display(df_deltatime_sel)

# COMMAND ----------

# MAGIC %md
# MAGIC # Test one event 

# COMMAND ----------

test = df_pivot_renamed_decoded_delta_time.filter(col("containerId")=="5d9872ba-d222-48ef-9c9f-e5ed30fe6d75")
display(test)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store decoded data

# COMMAND ----------

my_catalog_name = "ude_prod_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                       
my_gold_layer_table_name = "Live_PedEventsDecodedCl3"

df_pivot_renamed_decoded_delta_time.write.format("delta").mode("overwrite").saveAsTable(f"{my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
my_catalog_name = "ude_prod_euno_fhum_adas_cariad"   
my_project_name = "eicmfk"                        
my_gold_layer_table_name = "Live_PedEventsDecodedCl3"

spark.sql(
    f"DROP TABLE {my_catalog_name}.{my_project_name}_gold.{my_gold_layer_table_name}"
)
'''
