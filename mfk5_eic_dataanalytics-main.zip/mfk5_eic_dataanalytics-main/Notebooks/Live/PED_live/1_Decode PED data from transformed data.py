# Databricks notebook source
# MAGIC %load_ext autoreload
# MAGIC %autoreload 2
# MAGIC # Enables autoreload; learn more at https://docs.databricks.com/en/files/workspace-modules.html#autoreload-for-python-modules
# MAGIC # To disable autoreload; run %autoreload 0

# COMMAND ----------

# MAGIC %md
# MAGIC # Install packages

# COMMAND ----------

# MAGIC %pip install protobuf==5.27.2
# MAGIC

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %md
# MAGIC # Imports

# COMMAND ----------

from pyspark.sql import functions as F
from pyspark.sql.functions import col, when, lit
from pyspark.sql.types import StructType, StructField, StringType, ArrayType, IntegerType, FloatType
from pyspark.sql.window import Window
import importlib
import sys

# Set repo root path
repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
if repo_root_path not in sys.path:
    sys.path.append(repo_root_path)

import EICModules.decoding.decodingFunctions as decodingFunctions


# COMMAND ----------

# MAGIC %md
# MAGIC # Read preprocessed data from gold layer (Execute transform_common_od_ped_data first)

# COMMAND ----------


spark.conf.set("spark.sql.session.timeZone", "Europe/Berlin")

df_read = spark.read.table("ude_prod_euwe_datajedi_audi.eicmfk_gold.eic_mfk5_perception_ped_confbit_v0_3_transformed_live_cl3_kd1").cache()


df_ped_preprocced = (df_read        
        .withColumnRenamed("PedestrianDetection_pedestrians_Event", "Ped_event")
        .cache()
)

display(df_ped_preprocced)
df_ped_preprocced.count()

# COMMAND ----------

# MAGIC %md
# MAGIC # Decode additional ped data

# COMMAND ----------


import re

# extract relevant pedestrian class string from ped_event
def extract_pedestrianClass(s):
    if s is None:
        return []
    s = s.replace("&lt;", "<").replace("&gt;", ">")
    return re.findall(r'Ped_PedestrianClass\.(\w+)', s)

extract_pedestrianClass_udf = udf(extract_pedestrianClass, ArrayType(StringType()))


# get minimum value from array
def get_min_from_array(arr):
    if arr:
        return min(arr)
    return None

get_min_from_array_udf = udf(get_min_from_array, IntegerType())






def decode_ped_data(input_df, spark):
        """
        Decode EIC_ped data.
        input_df: pivoted dataframe
        output_df: pivoted dataframe with decoded signals 
        """
        
        # window to determine the last valid SomeIP-Element 
        window_spec = Window.partitionBy("containerId").orderBy("timestamp").rowsBetween(Window.unboundedPreceding, -1)

        window_container_relTime  = Window.partitionBy("containerId")

        # window to determine the next valid SomeIP-Element 
        window_spec_next = Window.partitionBy("containerId").orderBy("timestamp").rowsBetween(Window.currentRow, Window.unboundedFollowing)

        output_df = (input_df
            
            # decode SomeIP Pedestrian Detection
            .withColumn("ConfBitL1", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL1_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL2", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL2_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL3", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL3_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitEgoTurningL3", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitEgoTurningL3_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL1PedID", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL1PedID_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL2PedID", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL2PedID_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL3PedID", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitL3PedID_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitEgoTurningL3PedID", when(col("Ped_event").isNotNull(), decodingFunctions.getConfBitEgoTurningL3PedID_udf(col("Ped_event"))).otherwise(lit(None)))
            
            # extract timestamps, where L2/L3 bits are set to true
            .withColumn("timestamp_unix_confBitsL2L3set", 
                        when((col("ConfBitL2") == "Ped_ConfirmationBit.set")
                             |(col("ConfBitL3") == "Ped_ConfirmationBit.set")
                             |(col("ConfBitEgoTurningL3") == "Ped_ConfirmationBit.set"), col("timestamp_unix"))
                        .otherwise(lit(None)))

            # add relative timestamp (0 = start of confBit = set)
            .withColumn("event_time_s", (col("timestamp_unix") - F.min(col("timestamp_unix_confBitsL2L3set")).over(window_container_relTime))/1000)
            
            # calc gps position at activation time 
            .withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("event_time_s")))
            .withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("event_time_s")))
            .withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_container_relTime), col("latitude")))
            .withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_container_relTime), col("longitude")))

            # timestamp from Ped-Event
            .withColumn("TimeStampSeconds", when(col("Ped_event").isNotNull(), decodingFunctions.getTimeStampSeconds_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("TimeStampNanoseconds", when(col("Ped_event").isNotNull(), decodingFunctions.getTimeStampNanoseconds_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("TimestampStatus", when(col("Ped_event").isNotNull(), decodingFunctions.getTimestampStatus_udf(col("Ped_event"))).otherwise(lit(None)))

            # extract string data from Ped_event
            .withColumn("PedestrianClass_String", when(col("Ped_event").isNotNull(), decodingFunctions.getPedestrianClass_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("PedestrianID_String", when(col("Ped_event").isNotNull(), decodingFunctions.getPedestrianID_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ExistenceProbability_String", when(col("Ped_event").isNotNull(), decodingFunctions.getExistenceProbability_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("Age_String", when(col("Ped_event").isNotNull(), decodingFunctions.getAge_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("PedestrianClassProbability_String", when(col("Ped_event").isNotNull(), decodingFunctions.getPedestrianClassProbability_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("AzimuthAngle_String", when(col("Ped_event").isNotNull(), decodingFunctions.getAzimuthAngle_udf(col("Ped_event"))).otherwise(lit(None)))                                                                                                                                        
            .withColumn("RadialDistance_String", when(col("Ped_event").isNotNull(), decodingFunctions.getRadialDistance_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("TTC_String", when(col("Ped_event").isNotNull(), decodingFunctions.getTTC_udf(col("Ped_event"))).otherwise(lit(None)))

            # convert relevant string 
            .withColumn("PedestrianClass", extract_pedestrianClass_udf(col("PedestrianClass_String")))

            # convert types
            #.withColumn("PedestrianClass", when(col("PedestrianClass_String").isNotNull(),F.from_json("PedestrianClass_String", ArrayType(StringType()))))
            .withColumn("PedestrianID", when(col("PedestrianID_String").isNotNull(),F.from_json("PedestrianID_String", ArrayType(IntegerType()))))
            .withColumn("ExistenceProbability", when(col("ExistenceProbability_String").isNotNull(),F.from_json("ExistenceProbability_String", ArrayType(IntegerType()))))
            .withColumn("Age", when(col("Age_String").isNotNull(),F.from_json("Age_String", ArrayType(IntegerType()))))
            .withColumn("PedestrianClassProbability", when(col("PedestrianClassProbability_String").isNotNull(),F.from_json("PedestrianClassProbability_String", ArrayType(IntegerType()))))
            .withColumn("AzimuthAngle", when(col("AzimuthAngle_String").isNotNull(),F.from_json("AzimuthAngle_String", ArrayType(IntegerType()))))            
            .withColumn("RadialDistance", when(col("RadialDistance_String").isNotNull(),F.from_json("RadialDistance_String", ArrayType(IntegerType()))))
            .withColumn("TTC", when(col("TTC_String").isNotNull(),F.from_json("TTC_String", ArrayType(IntegerType()))))

            # extract minium value from array
            .withColumn("TTC_min", when(col("TTC").isNotNull(), get_min_from_array_udf(col("TTC"))).otherwise(lit(None)))
            .withColumn("RadialDistance_min", when(col("RadialDistance").isNotNull(), get_min_from_array_udf(col("RadialDistance"))).otherwise(lit(None)))

            # get number of bycicles from array
            .withColumn("bicycle_count", when(col("PedestrianClass").isNotNull(), F.expr("size(filter(PedestrianClass, x -> x = 'bicycle'))")).otherwise(lit(None)))
            .withColumn("pedestrian_count", when(col("PedestrianClass").isNotNull(), F.expr("size(filter(PedestrianClass, x -> x = 'pedestrian'))")).otherwise(lit(None)))          

            #calculate SomeIP timestamp delta
            .withColumn("last_valid_SomeIP_timestamp_unix", 
                                when(col("Ped_event").isNotNull(),
                                F.last(when(col("Ped_event").isNotNull(), col("timestamp_unix")), ignorenulls=True).over(window_spec)
                                ))
            .withColumn("delta_time_someIP", col("timestamp_unix") - col("last_valid_SomeIP_timestamp_unix"))

            # get first SomeIP element after activation and extract pedID
            .withColumn("pedID_at_activation", 
                                when(col("timestamp_unix_confBitsL2L3set").isNotNull(),
                                F.first(when(col("Ped_event").isNotNull(), col("ConfBitL1PedID")), ignorenulls=True).over(window_spec_next)
                                ))
            
            # get array index of pedID
            .withColumn("pedID_index_at_activation", 
                                when(col("pedID_at_activation").isNotNull(),
                                F.array_position(col("PedestrianID"), col("pedID_at_activation").cast(IntegerType()))
                                ))
            
            # get PedestrianClass at activation
            .withColumn("pedestrianClass_at_activation", 
                                when(col("pedID_index_at_activation").isNotNull() & (col("pedID_index_at_activation") > 0), 
                                F.element_at(col("PedestrianClass"), (col("pedID_index_at_activation").cast(IntegerType())))
                                ))

            # get TTC at activation
            .withColumn("TTC_at_activation", 
                                when(col("pedID_index_at_activation").isNotNull() & (col("pedID_index_at_activation") > 0), 
                                F.element_at(col("TTC"), (col("pedID_index_at_activation").cast(IntegerType())))
                                ))            
            
            # get radial distance at activation
            .withColumn("radialDistance_at_activation", 
                                when(col("pedID_index_at_activation").isNotNull() & (col("pedID_index_at_activation") > 0), 
                                F.element_at(col("RadialDistance"), (col("pedID_index_at_activation").cast(IntegerType())))
                                ))
            
            # get azimuth angle at activation
            .withColumn("azimuthAngle_at_activation", 
                                when(col("pedID_index_at_activation").isNotNull() & (col("pedID_index_at_activation") > 0), 
                                F.element_at(col("AzimuthAngle"), (col("pedID_index_at_activation").cast(IntegerType())))
                                ))
                                        
            # order results
            .orderBy("timestamp_unix", ascending=True)

            # drop unneeded columns
            .drop("", "value", "outside humidity and temperature", "Outdoor temperature", "PedestrianClass_String","PedestrianID_String", "ExistenceProbability_String", "Age_String", "PedestrianClassProbability_String", "AzimuthAngle_String", "RadialDistance_String", "TTC_String") # , Weather condition"
        )
        return output_df


df_ped_decoded = decode_ped_data(df_ped_preprocced, spark).cache()
display(df_ped_decoded)
df_ped_decoded.count()



# COMMAND ----------

# MAGIC %md
# MAGIC # Test one event 

# COMMAND ----------

test = df_ped_decoded.filter(col("containerId")=="485e020e-248e-42ca-a1c6-9d5826e7aa64")
display(test)

# COMMAND ----------

# MAGIC %md
# MAGIC # Store decoded data

# COMMAND ----------

output_data = "ude_prod_euwe_datajedi_audi.eicmfk_gold.EIC_MFK5_Perception_PED_ConfBit_V0_3_transformed_and_decoded_live_Cl3_KD1"

df_ped_decoded.write.format("delta").mode("overwrite").saveAsTable(f"{output_data}")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Optional: Delete table

# COMMAND ----------

'''
output_data = "ude_prod_euno_fhum_adas_cariad.eicmfk_gold.EIC_MFK5_Perception_PED_ConfBit_V0_3_transformed_and_decoded_live_Cl3_KD1"

spark.sql(
    f"DROP TABLE {output_data}"
)
'''
