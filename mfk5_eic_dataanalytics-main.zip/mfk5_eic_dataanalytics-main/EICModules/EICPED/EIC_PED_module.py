import base64
import struct

from pyspark.sql import functions as F
from pyspark.sql.functions import udf, col, radians, year, when, substring, lit, unhex, array_contains, row_number, get_json_object
from pyspark.sql.functions import unbase64
from pyspark.sql.window import Window
from pyspark.sql.types import StringType,BooleanType,DateType,FloatType,IntegerType,BinaryType
from EICModules.decodeSomeIP.linux import someIPpythonlib
from EICModules.decodeHighlevelData import decodeHumidityAndTemperature, decodeWeatherCondition

#SomeIP decoding
def decodePedValue(ped_b64_string):
    if ped_b64_string is None:
        return None
    byte_array      = base64.b64decode(ped_b64_string)
    ped = someIPpythonlib.Ped_pedestrians()
    dec = someIPpythonlib.decoder.decoderCreate(byte_array) 

    ped.parse_from(dec)
    return ped.value

def mapConfBitStringToNumber(confbitString):
    mapping = {
        "ConfirmationBit.notSet" : 0,
        "ConfirmationBit.set" : 1,
        "ConfirmationBit.init" : 2,
        "ConfirmationBit.error" : 3                        
    }
    return mapping.get(confbitString, -1)

getConfBitL1_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL1) if ped_b64_string else None, StringType())
getConfBitL2_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL2) if ped_b64_string else None, StringType())
getConfBitL3_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL3) if ped_b64_string else None, StringType())


mapConfBitStringToNumber_udf = udf(mapConfBitStringToNumber, IntegerType())

# CSO decoding
def decodeHumidtyAndTemp(humString):
    if humString is None:
        return None
    return decodeHumidityAndTemperature.decodeHumidityAndTemperatureData(humString)

def decodeWeatherCondation(weatherString):
    if weatherString is None:
        return None
    return decodeWeatherCondition.decodeWeatherConditionData(weatherString)


decodeHumidity_udf = udf(decodeHumidtyAndTemp, StringType())
decodeWeather_udf = udf(decodeWeatherCondation, StringType())
decodeWeather_udf = udf(decodeWeatherCondation, StringType())

def pivot_eic_ped_data(input_df, spark):
        """
        Pivoting and cleaning EIC_PED data.
        input_df: standard gdc dataframe (each row is one data point)
        output_df: pivoted dataframe decoded signals 
        """
        # define time signal
        time_signal = "timestamp_unix"
        # define windows
        window_events  = Window.partitionBy("userMessageId")
        #window_from_start = Window.partitionBy("userMessageId").orderBy("timestamp_unix").rangeBetween(Window.unboundedPreceding, -1)

        # Pivot table
        output_df = (input_df
            .groupBy("containerId", "userMessageId", "vehicleId", "ingestDate_wo_ms", "containerMsgCount", 
                    "timestamp_unix", "timestamp")
            .pivot("name")
            .agg(F.first("value"))
        )

        # If no EIC_ID in data, create empty column
        if "EIC_ID" in output_df.columns:
            output_df = output_df.withColumn("EIC_ID", col("EIC_ID").cast("int"))
        else:
            output_df = output_df.withColumn("EIC_ID", lit(None))
        

        output_df = (output_df
                     
            # convert data types 
            .withColumn("DW_Kilometerstand", col("DW_Kilometerstand").cast("int"))
            .withColumn("EIC_ID", col("EIC_ID").cast("int"))
            .withColumn("timestamp_unix", col("timestamp_unix").cast("double"))        
            .withColumn("VDSO_Vx3dGNSS", col("VDSO_Vx3dGNSS").cast("double"))    

            # rename cols 
            .withColumnRenamed("Event Image Collector - Response", "EIC_Response")
            .withColumnRenamed("PedestrianDetection pedestrians Event", "Ped_event")
            .withColumnRenamed("environmental brightness", "env_brightness")
            .withColumnRenamed("environmental field and forward brightness", "env_field_and_forward_brightness")
            .withColumnRenamed("high beam light state", "high_beam_state")
            .withColumnRenamed("low beam light state", "low_beam_state")
            .withColumnRenamed("outside dewpoint", "outside_dewpoint")
            .withColumnRenamed("Weather condition", "Weather_condition")

            # convert outdoor temp_kelvin to celsius
            .withColumn("Outdoor_temp_C", (col("Outdoor temperature").cast("double") - 273.15))   

            # add relative timestamp
            .withColumn("event_time", (col("timestamp_unix") - F.min(col("timestamp_unix")).over(window_events))/1000)
            .withColumn("unix_time_at_activation", when((col("EIC_ID").isNotNull()), col(time_signal)))

            # decode CSO Data to json 
            .withColumn("outside_temp_hum_json", when((col("outside humidity and temperature").isNotNull()), decodeHumidity_udf(col("outside humidity and temperature"))).otherwise(lit(None)))
            .withColumn("weather_cond_json", when((col("Weather_condition").isNotNull()), decodeWeather_udf(col("Weather_condition"))).otherwise(lit(None)))
            # Todo: decode dewpoint, brightness, brightness forward
            #.withColumn("outside dewpoint_json", when((col("outside dewpoint").isNotNull()), decodeWeather_udf(col("outside dewpoint"))).otherwise(lit(None)))
            
            # extract json fields
            .withColumn("outside_temp", when((col("outside_temp_hum_json").isNotNull()), get_json_object(col("outside_temp_hum_json"), '$.temperature')).otherwise(lit(None)))
            .withColumn("outside_hum", when((col("outside_temp_hum_json").isNotNull()), get_json_object(col("outside_temp_hum_json"), '$.humidity')).otherwise(lit(None)))            
            .withColumn("outside_hum_temp_status", when((col("outside_temp_hum_json").isNotNull()), get_json_object(col("outside_temp_hum_json"), '$.status')).otherwise(lit(None)))
            .withColumn("weather_cond_clearWeather", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.clearWeather')).otherwise(lit(None)))
            .withColumn("weather_cond_fog", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.fog')).otherwise(lit(None)))
            .withColumn("weather_cond_fogHeavy", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.fogHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_rain", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.rain')).otherwise(lit(None)))
            .withColumn("weather_cond_rainHeavy", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.rainHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_snow", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.snow')).otherwise(lit(None)))
            .withColumn("weather_cond_snowHeavy", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.snowHeavy')).otherwise(lit(None)))
            .withColumn("weather_cond_status", when((col("weather_cond_json").isNotNull()), get_json_object(col("weather_cond_json"), '$.status')).otherwise(lit(None)))
            
            # decode SomeIP Pedestrian Detection
            .withColumn("ConfBitL1", when(col("Ped_event").isNotNull(), getConfBitL1_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL2", when(col("Ped_event").isNotNull(), getConfBitL2_udf(col("Ped_event"))).otherwise(lit(None)))
            .withColumn("ConfBitL3", when(col("Ped_event").isNotNull(), getConfBitL3_udf(col("Ped_event"))).otherwise(lit(None)))
            .orderBy("timestamp_unix", ascending=True)

            # drop unneeded columns
            .drop("value", "outside humidity and temperature", "Outdoor temperature") # "Weather condition"
        )
        return output_df

def eic_ped_event_summary(input_df):
    # Define windows
    window_events = Window.partitionBy("userMessageId")
    # define window for extracting all EIC images for one event
    window_EIC = (Window.partitionBy("vehicleId")
                        .orderBy("unix_time_at_activation")
                        .rangeBetween(-10000, 10000)
    )
    time_signal = "timestamp_unix"

    output_df = (
        input_df
        # calculate activation time --> t_0 = 0 at EIC Trigger / Timestamp of EIC_ID 
        # Todo: change Ped_event to EIC_ID
        .withColumn("time_after_activation", when(col("Ped_event").isNotNull(), col(time_signal)))
        .withColumn("activation_time", (col(time_signal)-F.min("time_after_activation").over(window_events))/1000)

        # calc gps position at activation time
        .withColumn("GPS_lat_act_time", when(col("latitude").isNotNull(), col("activation_time")))
        .withColumn("GPS_long_act_time", when(col("longitude").isNotNull(), col("activation_time")))
        .withColumn("act_lat", when(F.abs(col("GPS_lat_act_time")) == F.min(F.abs(col("GPS_lat_act_time"))).over(window_events), col("latitude")))
        .withColumn("act_long", when(F.abs(col("GPS_long_act_time")) == F.min(F.abs(col("GPS_long_act_time"))).over(window_events), col("longitude")))
        .groupBy("containerId", "userMessageId", "vehicleId", "containerMsgCount")
        .agg(
            F.min("ingestDate_wo_ms").alias("ingestDate_wo_ms"),
            F.min("time_after_activation").alias("unix_time_at_activation"),
            F.first(time_signal).alias("first_unix_timestamp"),
            F.count("DW_Kilometerstand").alias("count_DW_Kilometerstand"),            
            F.count("EIC_ID").alias("count_EIC_ID"),
            F.count("EIC_Response").alias("count_EIC_Response"),
            F.count("LWI_AgStgWhl").alias("count_LWI_AgStgWhl"),
            F.count("Outdoor_temp_C").alias("count_Outdoor_temp_C"),
            F.count("Ped_event").alias("count_Ped_event"),
            F.count("RG_RA_CountryCode").alias("count_RG_RA_CountryCode"),
            F.count("Streetclass").alias("count_Streetclass"),
            F.count("VDSO_AgvYawRateOfsCmp").alias("count_VDSO_AgvYawRateOfsCmp"),
            F.count("VDSO_Vx3dGNSS").alias("count_VDSO_Vx3dGNSS"),

            F.count("weather_cond_json").alias("count_weather_cond_json"),
            F.count("env_brightness").alias("count_env_brightness"),
            F.count("env_field_and_forward_brightness").alias("count_env_field_and_forward_brightness"),
            F.count("high_beam_state").alias("count_high_beam_state"),
            F.count("latitude").alias("count_latitude"),
            F.count("longitude").alias("count_longitude"),
            F.count("low_beam_state").alias("count_low_beam_state"),
            F.count("outside_dewpoint").alias("count_outside_dewpoint"),
            F.count("outside_temp_hum_json").alias("count_outside_temp_hum_json"),
            
            F.first("act_lat", ignorenulls=True).alias("act_lat"),
            F.first("act_long", ignorenulls=True).alias("act_long"),
            F.collect_set("ConfBitL1").alias("ConfBit1_Values"),
            F.collect_set("ConfBitL2").alias("ConfBit2_Values"),
            F.collect_set("ConfBitL3").alias("ConfBit3_Values")
        )
        # set activation time of eic images to their unix timestamp
        .withColumn("unix_time_at_activation",
                    when(col("unix_time_at_activation").isNotNull(), col("unix_time_at_activation"))
                    .otherwise(col("first_unix_timestamp")))
        .select(
            "containerId",
            "userMessageId",
            "vehicleId",
            "containerMsgCount",
            "ingestDate_wo_ms",
            "unix_time_at_activation",
            "first_unix_timestamp",
            "count_DW_Kilometerstand",
            "count_EIC_ID",
            "count_EIC_Response",
            "count_LWI_AgStgWhl",
            "count_Ped_event",
            "count_RG_RA_CountryCode",
            "count_Streetclass",
            "count_VDSO_AgvYawRateOfsCmp",
            "count_VDSO_Vx3dGNSS",
            "count_high_beam_state",
            "count_latitude",
            "count_longitude",  
            "act_lat",
            "act_long",
            "ConfBit1_Values",
            "ConfBit2_Values",
            "ConfBit3_Values",  
            "count_Outdoor_temp_C",
            "count_outside_temp_hum_json",
            "count_outside_dewpoint",             
            "count_weather_cond_json",
            "count_env_brightness",
            "count_env_field_and_forward_brightness"      
        )
        .withColumn("containerIds_EIC_Images",
                    when(col("containerMsgCount") > 1, F.collect_set(col("containerId")).over(window_EIC))
                    .otherwise(F.array()))
        .withColumn("containerIds_EIC_Images", F.expr("filter(containerIds_EIC_Images, x -> x != containerId)"))
        .orderBy("ingestDate_wo_ms", ascending=False)
    )
    return output_df