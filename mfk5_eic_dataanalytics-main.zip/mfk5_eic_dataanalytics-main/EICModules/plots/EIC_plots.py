import plotly.graph_objects as go
import pandas as pd
import numpy as np
import base64

def map_plot(plot_data, timebase):
    # Plot gps map
    event_data_gps = plot_data[["latitude", "longitude", timebase]].dropna()
    customdata = np.stack((event_data_gps[timebase], event_data_gps['latitude']), axis=-1)
    fig_map = go.Figure()
    fig_map.add_trace(go.Scattermapbox(
                    lat=event_data_gps["latitude"],
                    lon=event_data_gps["longitude"],
                    name="GPS position",
                    mode='markers',
                    marker=go.scattermapbox.Marker(
                        symbol = "circle",
                        size=7,
                        color='rgb(255, 0, 0)',
                        # opacity=0.7
                    ),
                ))
    fig_map.update_layout(
                title = "Map",
                mapbox = {
                    # 'accesstoken': token,
                    'style': 'open-street-map',
                    'zoom': 15,
                    "center" : dict(
                        lat=event_data_gps["latitude"].median(),
                        lon=event_data_gps["longitude"].median())
                    },
                    showlegend = True,
                    width=600, height=280,
                    legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99), 
                    margin=dict(l=20, r=70, b=10, t=50))
    hovertemplate="time:%{customdata[0]:.2f} s"
    fig_map.update_traces(customdata=customdata, hovertemplate=hovertemplate)
    fig_map.show()

def generic_time_plot(plot_data, timebase, column_name, top_title, y_title, zoom_start, zoom_end, highlight_time=None, abs_timestamps_EIC_Images=None, drawmode='lines'):
    
    event_data = plot_data[[timebase, column_name]].dropna()

    # Create a Plotly figure
    fig = go.Figure()

    # Update layout of the figure
    fig.update_layout(
        title = top_title,
        xaxis_range= [zoom_start, zoom_end],                
        xaxis_title="Time in s",    
        yaxis_title=y_title,
        #showlegend=True,
        width=600, height=280,
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
        margin=dict(l=20, r=70, b=10, t=50)
    )
    # Add a scatter plot trace to the figure
    fig.add_trace(go.Scatter(x=event_data[timebase], y=event_data[column_name], mode=drawmode, name=column_name))

    # Add Event time as a red vertical line
    if highlight_time is not None:     
        fig.add_vline(x=highlight_time, line=dict(color='red', width=2, dash='dash'),  annotation_text='Event', annotation_position='top')

    # print image times if available as green vertical lines
    if abs_timestamps_EIC_Images is not None: 
        for time in abs_timestamps_EIC_Images:
            fig.add_vline(x=time, line=dict(color='green', width=2, dash='dash'),  annotation_text='Img', annotation_position='top')    


    # Display the figure
    fig.show()

def plot_eic_images(eic_images_pd):
    for row in range(0, len(eic_images_pd)):
        if(eic_images_pd['EIC_image_string'].iloc[row] == None):
            continue            
        single_image = eic_images_pd['EIC_image_string'].iloc[row] + '=='
        decoded_value = base64.b64decode(single_image)
        image = np.frombuffer(decoded_value, np.uint8)#[9:]
        encoded_image = base64.b64encode(image.tobytes()).decode("utf-8")
        prefix = "data:image/jpg;base64,"
        fig = go.Figure(go.Image(source=prefix+encoded_image))
        fig.update_layout(width=960, height=540, margin=dict(l=0, r=0, b=0, t=0))
        fig.update_xaxes(showticklabels=False).update_yaxes(showticklabels=True)
        plotly_obj = fig.to_json()
        result = pd.DataFrame(data = [plotly_obj], columns = ["plotly"])
        fig.show()
