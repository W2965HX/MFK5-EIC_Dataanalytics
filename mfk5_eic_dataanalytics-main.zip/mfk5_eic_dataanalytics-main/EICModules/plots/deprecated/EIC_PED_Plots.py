import plotly.graph_objects as go
import pandas as pd
import numpy as np
import base64

def map_plot(plot_data, timebase):
    # Plot gps map
    event_data_gps = plot_data[["latitude", "longitude", timebase]].dropna()
    customdata = np.stack((event_data_gps[timebase], event_data_gps['latitude']), axis=-1)
    fig_map = go.Figure()
    fig_map.add_trace(go.Scattermapbox(
                    lat=event_data_gps["latitude"],
                    lon=event_data_gps["longitude"],
                    name="GPS position",
                    mode='markers',
                    marker=go.scattermapbox.Marker(
                        symbol = "circle",
                        size=7,
                        color='rgb(255, 0, 0)',
                        # opacity=0.7
                    ),
                ))
    fig_map.update_layout(
                title = "Map",
                mapbox = {
                    # 'accesstoken': token,
                    'style': 'open-street-map',
                    'zoom': 15,
                    "center" : dict(
                        lat=event_data_gps["latitude"].median(),
                        lon=event_data_gps["longitude"].median())
                    },
                    showlegend = True,
                    width=600, height=280,
                    legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99), 
                    margin=dict(l=20, r=70, b=10, t=50))
    hovertemplate="time:%{customdata[0]:.2f} s"
    fig_map.update_traces(customdata=customdata, hovertemplate=hovertemplate)
    fig_map.show()

def confbit_plot(plot_data, timebase, confBitString):
    
    # Select relevant columns and drop rows with missing values
    event_data = plot_data[[timebase, confBitString]].dropna()

    # Create a Plotly figure
    fig = go.Figure()

    # Update layout of the figure
    fig.update_layout(
        xaxis_title="Time in s",    
        showlegend=True,
        width=600, height=280,
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
        margin=dict(l=20, r=70, b=10, t=50)
    )
    # Add a scatter plot trace to the figure
    fig.add_trace(go.Scatter(x=event_data[timebase], y=event_data[confBitString], mode='lines', name='ConfBitL1'))

    # Update layout with title and y-axis label
    fig.update_layout(title=confBitString)

    # Display the figure
    fig.show()

def velocity_plot(plot_data, timebase):
    # Select relevant columns and drop rows with missing values
    event_data_vx_ego = plot_data[[timebase, "VDSO_Vx3dGNSS"]].dropna()

    # Create a Plotly figure
    fig = go.Figure()

    # Update layout of the figure
    fig.update_layout(
        xaxis_title="Time in s",    
        showlegend=True,
        width=600, height=280,
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
        margin=dict(l=20, r=70, b=10, t=50)
    )

    # Add a scatter plot trace to the figure
    fig.add_trace(go.Scatter(x=event_data_vx_ego[timebase], y=event_data_vx_ego["VDSO_Vx3dGNSS"], mode='lines', name='Ego_velocity'))

    # Update layout with title and y-axis label
    fig.update_layout(title='Velocity X', yaxis_title="Velocity in km/h")

    #fig.update_yaxes(tickformat=',d')

    # Display the figure
    fig.show()

def generic_time_plot(plot_data, timebase, column_name, drawmode='lines'):
    
    event_data = plot_data[[timebase, column_name]].dropna()

    # Create a Plotly figure
    fig = go.Figure()

    # Update layout of the figure
    fig.update_layout(
        xaxis_title="Time in s",    
        #showlegend=True,
        width=600, height=280,
        legend=dict(yanchor="top", y=0.99, xanchor="right", x=0.99),
        margin=dict(l=20, r=70, b=10, t=50)
    )
    # Add a scatter plot trace to the figure
    fig.add_trace(go.Scatter(x=event_data[timebase], y=event_data[column_name], mode=drawmode, name=column_name))

    # Update layout with title and y-axis label
    fig.update_layout(title=column_name)

    # Display the figure
    fig.show()