import base64, re

def decodeBase64(b64_string):
    if b64_string is None:
        return None
    return base64.b64decode(b64_string).decode('utf-8')

def extractString(text, pattern, length, additionalOffset):
    match = re.search(pattern, text)
    if match:
        start = match.end()
        return text[start+additionalOffset:start+additionalOffset+length]
    return None

def extractMFK5Version(MFK5VersionString):
    pattern = "Param_VWAppliSoftwVersiNumbe\","
    length = 4
    additionalOffset = 29
    if MFK5VersionString is None:
        return None
    return extractString(MFK5VersionString, pattern, length, additionalOffset)     

def extractHCP5PDVersion(HCP5PDVersionString):
    pattern = "Param_VWAppliSoftwVersiNumbe\","
    length = 4
    additionalOffset = 29
    if HCP5PDVersionString is None:
        return None
    return extractString(HCP5PDVersionString, pattern, length, additionalOffset)

'''
# No SW-Versions in the VD version string
def extractHCP5VDVersion(HCP5VDVersionString):
    pattern = "Param_VWAppliSoftwVersiNumbe\","
    length = 4
    additionalOffset = 29
    if HCP5VDVersionString is None:
        return None
    return extractString(HCP5VDVersionString, pattern, length, additionalOffset)
'''