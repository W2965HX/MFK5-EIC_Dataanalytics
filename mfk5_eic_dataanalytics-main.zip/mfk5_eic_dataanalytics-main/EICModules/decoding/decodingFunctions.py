from pyspark.sql.functions import udf
from pyspark.sql.types import StringType
import sys
import base64
import importlib

# Set repo root path
#repo_root_path = "/Workspace/Users/volker.kippelt@cariad.technology/mfk5_eic_dataanalytics/"
#if repo_root_path not in sys.path:
#    sys.path.append(repo_root_path)


from EICModules.decoding.decodeDiagnostics import decodeSWVersions
from EICModules.decoding.decodeSomeIP.linux import someIPpythonlib
from EICModules.decoding.decodeHighlevelData import decodeBHE, decodeHumidityAndTemperature, decodeWeatherCondition
#from decodeDiagnostics import decodeSWVersions


importlib.reload(someIPpythonlib)
#importlib.reload(decodeSWVersions)
importlib.reload(decodeBHE)
importlib.reload(decodeHumidityAndTemperature)
importlib.reload(decodeWeatherCondition)


#SomeIP decoding pedestrian detection
def decodePedValue(ped_b64_string):
    if ped_b64_string is None:
        return None
    byte_array      = base64.b64decode(ped_b64_string)
    ped = someIPpythonlib.Ped_pedestrians()
    dec = someIPpythonlib.decoder.decoderCreate(byte_array) 

    ped.parse_from(dec)
    return ped.value

# CSO decoding
def decodeHumidtyAndTemp(humString):
    if humString is None:
        return None
    return decodeHumidityAndTemperature.decodeHumidityAndTemperatureData(humString)

def decodeWeatherCondation(weatherString):
    if weatherString is None:
        return None
    return decodeWeatherCondition.decodeWeatherConditionData(weatherString)

#SomeIP decoding object detection
def decodeOdValue(od_b64_string):
    if od_b64_string is None:
        return None
    byte_array      = base64.b64decode(od_b64_string)
    od = someIPpythonlib.Od_objects()
    dec = someIPpythonlib.decoder.decoderCreate(byte_array) 

    od.parse_from(dec)
    return od.value

# Pedestrian detection udf
getConfBitL1_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL1) if ped_b64_string else None, StringType())
getConfBitL2_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL2) if ped_b64_string else None, StringType())
getConfBitL3_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL3) if ped_b64_string else None, StringType())
getConfBitEgoTurningL3_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitEgoTurningL3) if ped_b64_string else None, StringType())

getConfBitL1PedID_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL1PedID) if ped_b64_string else None, StringType())
getConfBitL2PedID_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL2PedID) if ped_b64_string else None, StringType())
getConfBitL3PedID_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitL3PedID) if ped_b64_string else None, StringType())
getConfBitEgoTurningL3PedID_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).confirmationBits.confBitEgoTurningL3PedID) if ped_b64_string else None, StringType())

getTimeStampSeconds_udf     = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).timeStampSeconds) if ped_b64_string else None, StringType())
getTimeStampNanoseconds_udf = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).timeStampNanoseconds) if ped_b64_string else None, StringType())
getTimestampStatus_udf       = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).timestampStatus) if ped_b64_string else None, StringType())


getPedestrianClass_udf              = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.pedestrianClass) if ped_b64_string else None, StringType())
getPedestrianID_udf                 = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.pedestrianID) if ped_b64_string else None, StringType())
getExistenceProbability_udf         = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.existenceProbability) if ped_b64_string else None, StringType())
getAge_udf                          = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.age) if ped_b64_string else None, StringType())
getPedestrianClassProbability_udf   = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.pedestrianClassProbability) if ped_b64_string else None, StringType())
getTTC_udf                          = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.timeToCollisionFront) if ped_b64_string else None, StringType())
getAzimuthAngle_udf                 = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.azimuthAngle) if ped_b64_string else None, StringType())
getRadialDistance_udf               = udf(lambda ped_b64_string: str(decodePedValue(ped_b64_string).pedestrians.radialDistance) if ped_b64_string else None, StringType())

# Object detection udf - functions
getConfBitPrecedingL1_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitPrecedingL1) if od_b64_string else None, StringType())
getConfBitPrecedingL2_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitPrecedingL2) if od_b64_string else None, StringType())
getConfBitPrecedingL3_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitPrecedingL3) if od_b64_string else None, StringType())

getConfBitOncomingL2_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitOncomingL2) if od_b64_string else None, StringType())
getConfBitOncomingL3_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitOncomingL3) if od_b64_string else None, StringType())

getConfBitCrossingL1_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitCrossingL1) if od_b64_string else None, StringType())
getConfBitCrossingL2_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitCrossingL2) if od_b64_string else None, StringType())
getConfBitCrossingL3_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitCrossingL3) if od_b64_string else None, StringType())

confBitEgoTurningL3_udf = udf(lambda od_b64_string: str(decodeOdValue(od_b64_string).confirmationBits.confBitEgoTurningL3) if od_b64_string else None, StringType())

# CSO decoding udf
decodeHumidity_udf = udf(decodeHumidtyAndTemp, StringType())
decodeWeather_udf = udf(decodeWeatherCondation, StringType())

# Decode SW-Versions
decodeBase64_udf = udf(decodeSWVersions.decodeBase64, StringType())
extractMFK5Version_udf = udf(decodeSWVersions.extractMFK5Version, StringType())