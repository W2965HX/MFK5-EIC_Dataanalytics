Install protobuf for python
https://github.com/protocolbuffers/protobuf/tree/v27.2/python
pip install protobuf

Get protoc binary
https://github.com/protocolbuffers/protobuf/releases/tag/v27.2

Compile protocol buffer 
https://protobuf.dev/getting-started/pythontutorial/
protoc -I=$SRC_DIR --python_out=$DST_DIR $SRC_DIR/protofile.proto
