import base64
from EICModules.decoding.decodeHighlevelData import cso_vehicle_pb2 as cso_vehicle
import json

def decodeHumidityAndTemperatureData(humidityAndTemperaturData: str) -> str:
    humidityAndTemperaturDataBin = base64.b64decode(humidityAndTemperaturData)     
    cso_HumidityOutside = cso_vehicle.HumidityOutside()  
    cso_HumidityOutside.ParseFromString(humidityAndTemperaturDataBin)

    humidityAndTemperaturDataDict = {
        "status": cso_HumidityOutside.status,            
        "humidity": cso_HumidityOutside.humidity,            
        "temperature": cso_HumidityOutside.temperature,            
        "statusTimestamp": cso_HumidityOutside.statusTimestamp,            
        "humidityTimestamp": cso_HumidityOutside.humidityTimestamp,            
        "temperatureTimestamp": cso_HumidityOutside.temperatureTimestamp,            
    }
    return json.dumps(humidityAndTemperaturDataDict, sort_keys=True)