import base64
from EICModules.decoding.decodeHighlevelData import cso_vehicle_pb2 as cso_vehicle
import json

def decodeWeatherConditionData(weatherConditionData: str) -> str:
    weatherConditionDataBin = base64.b64decode(weatherConditionData)     
    cso_WeatherCondition = cso_vehicle.WeatherCondition()  
    cso_WeatherCondition.ParseFromString(weatherConditionDataBin)

    weatherConditionDataDict = {
        "status": str(cso_WeatherCondition.status),            
        "clearWeather": cso_WeatherCondition.clearWeather, 
        "rain" : cso_WeatherCondition.rain,
        "rainHeavy" : cso_WeatherCondition.rainHeavy,
        "rain" : cso_WeatherCondition.rain,
        "snow" : cso_WeatherCondition.snow,
        "snowHeavy" : cso_WeatherCondition.snowHeavy,
        "fog" : cso_WeatherCondition.fog,
        "fogHeavy" : cso_WeatherCondition.fogHeavy
    }

    return json.dumps(weatherConditionDataDict, sort_keys=True)