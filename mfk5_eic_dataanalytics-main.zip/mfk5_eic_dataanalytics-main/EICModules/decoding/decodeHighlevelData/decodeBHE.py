import base64
from EICModules.decoding.decodeHighlevelData import cso_vehicle_pb2 as cso_vehicle
import pandas as pd
from enum import Enum

class SignalType_BHE(Enum):
    sig_BHE_FC1_FSFrozenWindshield = 1;
    sig_BHE_FC1_ImpairmentLightAssist = 2;
    sig_BHE_FC1_SelfGlareIntensity = 3;
    sig_BHE_FC1_ImpairmentSHPS = 4;
    sig_BHE_FC1_ImpairmentOD = 5;
    sig_BHE_FC1_ImpairmentLDA = 6;
    sig_BHE_FC1_ImpairmentPED = 7;
    sig_BHE_FC1_Freesight = 8;
    sig_BHE_FC1_ImpairmentTSR = 9;
    sig_BHE_FC1_ImpairmentODACC = 10;
    sig_BHE_FC1_FSRain = 11;
    sig_BHE_FC1_FSBlur = 12;
    sig_BHE_FC1_FSLowSun = 13;
    sig_BHE_FC1_FSBlockage = 14;
    sig_BHE_FC1_FSPartialBlockage = 15;
    sig_BHE_FC1_FSFog = 16;
    sig_BHE_FC1_FSSplashes = 17;
    sig_BHE_FC1_HeatingRequest = 18;

def decodeBHEBase64data(BHEBase64data: str) -> cso_vehicle.MFK5ClustersBHE:
    BHEdataBin = base64.b64decode(BHEBase64data)     
    bheMessageClusters = cso_vehicle.MFK5ClustersBHE()  
    bheMessageClusters.ParseFromString(BHEdataBin)
    return bheMessageClusters

def convertProtobufToDataFrame(ProtobufMessage: cso_vehicle.MFK5ClustersBHE) -> pd.DataFrame:    
    dataFrame = pd.DataFrame(columns=['Signalname', 'Timestamp', 'Value'], )

    for bheMessage in ProtobufMessage.mfk5ClustersBHE: 
        # Check which signal types are included in message 
        for sigType in SignalType_BHE:
            sigNameStr = str(sigType.name)
            if bheMessage.HasField(sigNameStr):                
                #get timestamp / value pair from message
                mfk5_val = cso_vehicle.MFK5_Value_Timestamp() 
                mfk5_val = getattr(bheMessage, sigNameStr)                                
                timestamp = mfk5_val.timestamp
                value = mfk5_val.value

                df_row = pd.DataFrame([{'Signalname': sigNameStr,  'Timestamp': timestamp, 'Value': value}])                
                dataFrame= pd.concat([dataFrame, df_row], ignore_index=True)
    return dataFrame    

def convertBHEDataToDataFrame(BHEdata: str) -> pd.DataFrame:   
    bheMessageClusters = decodeBHEBase64data(BHEdata) 
    dataframe = convertProtobufToDataFrame(bheMessageClusters)        
    return dataframe

def convertBHEDataListToDataFrame(BHEdataList: list[str]) -> pd.DataFrame:
    dataFrames = pd.DataFrame(columns=['Signalname', 'Timestamp', 'Value'])
    for BHEdata in BHEdataList:        
        dataframe = convertBHEDataToDataFrame(BHEdata) 
        dataFrames= pd.concat([dataFrames, dataframe], ignore_index=True)
    return dataFrames

