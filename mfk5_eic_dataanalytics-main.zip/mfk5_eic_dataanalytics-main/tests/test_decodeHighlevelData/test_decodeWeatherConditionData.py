import pytest
from EICModules.decoding.decodeHighlevelData import decodeWeatherCondition

def test_decodeWeatherConditionData():   
    weatherConditionData = r"CAEQAQ=="
    expectedResult = r'{"clearWeather": true, "fog": false, "fogHeavy": false, "rain": false, "rainHeavy": false, "snow": false, "snowHeavy": false, "status": "1"}'
    weatherConditionDatadecoded = decodeWeatherCondition.decodeWeatherConditionData(weatherConditionData) 
    assert(weatherConditionDatadecoded == expectedResult)