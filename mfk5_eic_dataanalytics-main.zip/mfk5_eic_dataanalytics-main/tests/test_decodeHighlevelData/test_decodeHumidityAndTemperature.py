import pytest
from EICModules.decoding.decodeHighlevelData import decodeHumidityAndTemperature

def test_decodeHumidityAndTemperatureData():   
    humTempdata = r"CAEVAAAaQh1mZppB"
    expectedResult = r'{"humidity": 38.5, "humidityTimestamp": 0, "status": 1, "statusTimestamp": 0, "temperature": 19.299999237060547, "temperatureTimestamp": 0}'
    humTempdatadecoded = decodeHumidityAndTemperature.decodeHumidityAndTemperatureData(humTempdata) 
    assert(humTempdatadecoded == expectedResult)