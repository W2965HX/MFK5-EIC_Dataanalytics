import pytest
from EICModules.decoding.decodeHighlevelData import decodeBHE


def test_convertBHEDataToDataFrame():   
    BHEdata = r"Cm8SCQgCEL/1w9vnMSIJCAIQv/XD2+cxKgkIAhC/9cPb5zEyCQgCEL/1w9vnMToJCAIQv/XD2+cxQgkIAhC/9cPb5zFKCQgCEL/1w9vnMVIJCAIQwPXD2+cxagkIARDA9cPb5zGSAQkIAhDA9cPb5zEKZBIJCAIQ1ffD2+cxIgkIAhDV98Pb5zEqCQgCENX3w9vnMTIJCAIQ1ffD2+cxOgkIAhDV98Pb5zFCCQgCENX3w9vnMUoJCAIQ1ffD2+cxUgkIAhDV98Pb5zGSAQkIAhDV98Pb5zE="
    bheMessageClusters = decodeBHE.convertBHEDataToDataFrame(BHEdata) 
    print(bheMessageClusters)

    assert(bheMessageClusters.at[0, "Signalname"] == "sig_BHE_FC1_ImpairmentLightAssist")
    assert(bheMessageClusters.at[0, "Timestamp"] == 1711467985599)
    assert(bheMessageClusters.at[0, "Value"] == 2)


def test_convertBHEDataListToDataFrame():
    
    BHEdata1 = r"Cm8SCQgCEL/1w9vnMSIJCAIQv/XD2+cxKgkIAhC/9cPb5zEyCQgCEL/1w9vnMToJCAIQv/XD2+cxQgkIAhC/9cPb5zFKCQgCEL/1w9vnMVIJCAIQwPXD2+cxagkIARDA9cPb5zGSAQkIAhDA9cPb5zEKZBIJCAIQ1ffD2+cxIgkIAhDV98Pb5zEqCQgCENX3w9vnMTIJCAIQ1ffD2+cxOgkIAhDV98Pb5zFCCQgCENX3w9vnMUoJCAIQ1ffD2+cxUgkIAhDV98Pb5zGSAQkIAhDV98Pb5zE="
    BHEdata2 = r"CqUBCgcQganb2+cxEgcQganb2+cxGgcQganb2+cxIgcQganb2+cxKgcQganb2+cxMgcQganb2+cxOgcQganb2+cxQgcQganb2+cxSgcQganb2+cxUgcQganb2+cxWgcQganb2+cxYgcQganb2+cxagcQganb2+cxcgcQganb2+cxegcQganb2+cxggEHEIGp29vnMYoBBxCBqdvb5zGSAQcQganb2+cx"
    BHEdata3 = r"CmQSCQgCEMim89rnMSIJCAIQyKbz2ucxKgkIAhDIpvPa5zEyCQgCEMim89rnMToJCAIQyKbz2ucxQgkIAhDIpvPa5zFKCQgCEMim89rnMVIJCAIQyKbz2ucxkgEJCAIQyKbz2ucx"
        
    BHEMessageList =[BHEdata1, BHEdata2, BHEdata3]
    dataFrames = decodeBHE.convertBHEDataListToDataFrame(BHEMessageList)
    dataFrames = dataFrames.sort_values(['Timestamp', 'Signalname'])
    print(dataFrames)

    assert(dataFrames.at[43, "Signalname"] == "sig_BHE_FC1_ImpairmentTSR")
    assert(dataFrames.at[43, "Timestamp"] == 1711466664776)
    assert(dataFrames.at[43, "Value"] == 2)

    

    
    
