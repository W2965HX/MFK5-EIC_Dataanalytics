from Scripts.export_dashboards import export_dashboards
import pytest
import shutil
import os

TESTDATA_OUTPUT_PATH = "tests/testdata/export_dashboards/output/"
RUN_ID = 455166899597329


@pytest.fixture
def setup_data():
    print("Setup")
    if os.path.exists(TESTDATA_OUTPUT_PATH):
        shutil.rmtree(TESTDATA_OUTPUT_PATH)
        print(f"Removed test data output: '{TESTDATA_OUTPUT_PATH}'.")
    yield
    print("Teardown")


def test_execute_notebook():
    params = {
        "param_containerId": "5d46a57d-1ad5-4bed-b58c-38cb854b8d3b"
    }
    run_id = export_dashboards.execute_notebook(params)
    assert isinstance(run_id, int)


def test_execute_notebook_unkown_container_id_fails():
    params = {
        "param_containerId": "14d084c5-32a9-45d6-a6fe-051ad039e509"
    }
    with pytest.raises(RuntimeError, match="Notebook could not be executed with parameter"):
        export_dashboards.execute_notebook(params)


def test_extract_and_store_html_dashboard(setup_data):
    filename = os.path.join(TESTDATA_OUTPUT_PATH, "analyse_event.html")
    export_dashboards.extract_and_store_html_dashboard(RUN_ID, filename)
    assert os.path.exists(filename)


def test_export_multiple_dashboards(setup_data):
    export_dashboards.run_jobs_and_export_from_containerId_list(["d64de475-3c4a-4cfd-bbe0-06be3355f5c1", "6ab9a0a9-6957-4fb0-acdc-bb546488ec81"], TESTDATA_OUTPUT_PATH)
    assert os.path.exists(os.path.join(TESTDATA_OUTPUT_PATH, "Analyse_event_cont_id_6ab9a0a9-6957-4fb0-acdc-bb546488ec81.html"))
    assert os.path.exists(os.path.join(TESTDATA_OUTPUT_PATH, "Analyse_event_cont_id_d64de475-3c4a-4cfd-bbe0-06be3355f5c1.html"))


def test_export_multiple_dashboards_with_one_unkown_container_one_is_created(setup_data):
    export_dashboards.run_jobs_and_export_from_containerId_list(["d64de475-3c4a-4cfd-bbe0-06be3355f5c1", "14d084c5-32a9-45d6-a6fe-051ad039e509"], TESTDATA_OUTPUT_PATH)
    assert os.path.exists(os.path.join(TESTDATA_OUTPUT_PATH, "Analyse_event_cont_id_d64de475-3c4a-4cfd-bbe0-06be3355f5c1.html"))


def test_run_jobs_and_export_from_containerId_file(setup_data):
    export_dashboards.run_jobs_and_export_from_containerId_file("./tests/testdata/export_dashboards/containerIds.txt", TESTDATA_OUTPUT_PATH)
    assert os.path.exists(os.path.join(TESTDATA_OUTPUT_PATH, "Analyse_Event_cont_id_f78a6754-98d6-4b91-bd9e-2204f065afe8.html"))
    assert os.path.exists(os.path.join(TESTDATA_OUTPUT_PATH, "Analyse_Event_cont_id_5af025bd-0b03-40ab-b699-a0c203250557.html"))
